package com.breadwinner.wavelink

/** The page the PC sees in its browser. */
const val PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WaveLink</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#0C1318;color:#E6ECEF;font-family:system-ui,Segoe UI,Roboto,sans-serif}
.wrap{max-width:760px;margin:0 auto;padding:20px 16px 60px}
h1{font-size:28px;margin:8px 0 2px;letter-spacing:-.5px}
.sub{color:#8394A0;margin:0 0 22px}
.card{background:#141D24;border-radius:10px;padding:16px;margin-bottom:14px}
h2{font-size:15px;margin:0 0 12px}
#drop{border-radius:10px;background:#1C2830;padding:28px 16px;text-align:center;color:#8394A0}
#drop.over{background:#16303A;color:#E6ECEF}
label.btn,a.btn{display:inline-block;background:#3A8EA8;color:#071318;font-weight:700;padding:9px 16px;border-radius:10px;text-decoration:none;cursor:pointer;font-size:14px}
.row{display:flex;align-items:center;gap:12px;padding:10px 0;border-top:1px solid #1C2830}
.row:first-child{border-top:0}
.tag{font-size:11px;font-weight:700;background:#1C2830;color:#DDB77B;border-radius:6px;padding:3px 7px}
.name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.meta{color:#8394A0;font-size:12px;margin-top:2px}
.bar{height:5px;border-radius:5px;background:#1C2830;margin-top:6px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:#3BA793}
.empty{color:#8394A0;font-size:14px}
</style></head><body><div class="wrap">
<h1>WaveLink</h1><p class="sub" id="sub">Connected to the phone</p>
<div class="card"><h2>Send to the phone</h2>
<div id="drop">Drop files here, or<br><br><label class="btn">Choose files<input id="pick" type="file" multiple hidden></label></div>
<div id="ups"></div></div>
<div class="card"><h2>On the phone</h2><div id="list"><div class="empty">Loading...</div></div></div>
<script>
var queue=[],busy=false,lastP=-1,lastT=0;
function ping(p,n,force){var t=Date.now();if(!force&&(p===lastP||t-lastT<250))return;lastP=p;lastT=t;fetch('/api/progress?p='+p+'&n='+encodeURIComponent(n),{cache:'no-store'}).catch(function(){})}
function fmt(b){if(b<0)return '?';if(b>=1e9)return (b/1e9).toFixed(2)+' GB';if(b>=1e6)return (b/1e6).toFixed(1)+' MB';if(b>=1e3)return Math.round(b/1e3)+' KB';return b+' B'}
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e}
function load(){
 fetch('/api/items',{cache:'no-store'}).then(function(r){return r.json()}).then(function(d){
  document.getElementById('sub').textContent='Connected to the phone';
  var box=document.getElementById('list');box.innerHTML='';
  if(!d.items.length){box.appendChild(el('div','empty','Nothing shared yet. On the phone, open the Share tab and add files or apps.'));return}
  d.items.forEach(function(it){
   var r=el('div','row');
   r.appendChild(el('span','tag',it.kind==='app'?'APP':'FILE'));
   var w=el('div');w.style.flex='1';w.style.minWidth='0';
   w.appendChild(el('div','name',it.name));
   w.appendChild(el('div','meta',fmt(it.size)));
   r.appendChild(w);
   var a=el('a','btn','Download');a.href='/dl/'+it.id;a.setAttribute('download',it.name);
   r.appendChild(a);box.appendChild(r);
  });
 }).catch(function(){document.getElementById('sub').textContent='Lost connection to the phone...'});
}
function enqueue(files){for(var i=0;i<files.length;i++)queue.push(files[i]);next()}
function next(){
 if(busy||!queue.length)return;busy=true;
 var f=queue.shift();
 var row=el('div','row');var w=el('div');w.style.flex='1';w.style.minWidth='0';
 var m=el('div','meta','Sending... 0%');var b=el('div','bar');var i=el('i');
 b.appendChild(i);w.appendChild(el('div','name',f.name));w.appendChild(m);w.appendChild(b);row.appendChild(w);
 document.getElementById('ups').insertBefore(row,document.getElementById('ups').firstChild);
 lastP=-1;var x=new XMLHttpRequest();x.open('POST','/upload');
 x.upload.onprogress=function(e){if(e.lengthComputable){var p=Math.round(e.loaded/e.total*100);i.style.width=p+'%';m.textContent='Sending... '+p+'%';ping(p,f.name,false)}};
 x.onload=function(){i.style.width='100%';m.textContent=x.status===200?'Sent. Saved on the phone in Downloads/WaveLink':'Failed';busy=false;next()};
 x.onerror=function(){m.textContent='Failed. Check the connection.';busy=false;next()};
 var fd=new FormData();fd.append('file',f,f.name);x.send(fd);
}
var pick=document.getElementById('pick'),drop=document.getElementById('drop');
pick.onchange=function(){enqueue(pick.files);pick.value=''};
drop.ondragover=function(e){e.preventDefault();drop.className='over'};
drop.ondragleave=function(){drop.className=''};
drop.ondrop=function(e){e.preventDefault();drop.className='';enqueue(e.dataTransfer.files)};
load();setInterval(load,3000);
</script></div></body></html>"""
