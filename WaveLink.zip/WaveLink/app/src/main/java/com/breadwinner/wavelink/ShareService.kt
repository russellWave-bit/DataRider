package com.breadwinner.wavelink

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Keeps the web server (and the optional temporary hotspot) alive while sharing. */
class ShareService : Service() {
    private var server: ShareServer? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var lock: PowerManager.WakeLock? = null

    companion object {
        const val STOP = "wavelink.stop"
        const val CH = "share"
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Sharing", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (server == null) startServer()
        if (lock == null) {
            val pm = getSystemService(PowerManager::class.java)
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavelink:transfer").apply { acquire() }
        }
        Hub.running = server != null
        if (server == null) {
            Hub.hotspotMsg = "Could not start the sharing server."
            stopSelf()
            return START_NOT_STICKY
        }
        Hub.mode = i?.getIntExtra("mode", 0) ?: 0
        if (Hub.mode == 1 && reservation == null) startHotspot()
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ShareService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveLink is on")
            .setContentText("Open the address on your PC")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stop).build())
            .build()
    }

    private fun startServer() {
        for (p in 8080..8090) {
            try {
                val s = ShareServer(p, applicationContext)
                s.start()
                server = s
                Hub.port = p
                return
            } catch (e: Exception) {
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun startHotspot() {
        Hub.hotspotMsg = "Starting the hotspot..."
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        Hub.ssid = c.ssid ?: ""
                        Hub.pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        Hub.ssid = (c?.SSID ?: "").trim('"')
                        Hub.pass = c?.preSharedKey ?: ""
                    }
                    Hub.hotspotMsg = ""
                }

                override fun onStopped() {
                    Hub.ssid = ""
                    Hub.pass = ""
                    Hub.hotspotMsg = "The hotspot stopped."
                }

                override fun onFailed(reason: Int) {
                    Hub.hotspotMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "No Wi-Fi channel is free right now. Try again."
                        ERROR_INCOMPATIBLE_MODE -> "Turn off your normal hotspot first, then try again."
                        ERROR_TETHERING_DISALLOWED -> "This phone does not allow apps to start a hotspot."
                        else -> "The hotspot could not start. Make sure Location is switched on."
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            Hub.hotspotMsg = "Allow the permission and switch Location on, then try again."
        } catch (e: Exception) {
            Hub.hotspotMsg = "The hotspot could not start on this phone."
        }
    }

    override fun onDestroy() {
        try { reservation?.close() } catch (e: Exception) { }
        reservation = null
        try { server?.stop() } catch (e: Exception) { }
        server = null
        try { lock?.release() } catch (e: Exception) { }
        lock = null
        Hub.running = false
        Hub.ssid = ""
        Hub.pass = ""
        Hub.clearSeen()
        super.onDestroy()
    }
}
