package com.breadwinner.wavelink

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Hub.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Acc)) {
                WaveLinkApp()
            }
        }
    }
}
