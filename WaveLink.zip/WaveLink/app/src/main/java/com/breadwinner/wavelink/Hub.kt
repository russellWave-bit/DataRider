package com.breadwinner.wavelink

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Something the phone is offering to the PC. kind is "file" or "app". */
data class Item(val id: Int, val name: String, val size: Long, val kind: String, val uri: Uri?, val path: String?)

/** Something the PC sent to the phone. */
data class Got(val name: String, val size: Long, val time: Long, val uri: Uri?)

/** Shared state between the service, the web server and the screens. */
object Hub {
    var running by mutableStateOf(false)
    /** 0 = my hotspot, 1 = auto hotspot, 2 = USB cable */
    var mode by mutableStateOf(0)
    var ssid by mutableStateOf("")
    var pass by mutableStateOf("")
    var hotspotMsg by mutableStateOf("")
    var port by mutableStateOf(8080)
    var devices by mutableStateOf(0)
    val items = mutableStateListOf<Item>()
    val received = mutableStateListOf<Got>()

    private val ids = AtomicInteger(1)
    private val seen = ConcurrentHashMap<String, Long>()

    fun nextId(): Int = ids.getAndIncrement()

    fun init(c: Context) {
        mode = c.getSharedPreferences("wl", Context.MODE_PRIVATE).getInt("mode", 0)
    }

    fun setMode(c: Context, m: Int) {
        mode = m
        c.getSharedPreferences("wl", Context.MODE_PRIVATE).edit().putInt("mode", m).apply()
    }

    fun touch(ip: String) {
        seen[ip] = System.currentTimeMillis()
        recount()
    }

    fun recount() {
        val now = System.currentTimeMillis()
        devices = seen.values.count { now - it < 15_000 }
    }

    fun clearSeen() {
        seen.clear()
        devices = 0
    }
}

fun fmtSize(b: Long): String {
    if (b < 0) return "?"
    val d = b.toDouble()
    return when {
        d >= 1e9 -> String.format(Locale.US, "%.2f GB", d / 1e9)
        d >= 1e6 -> String.format(Locale.US, "%.1f MB", d / 1e6)
        d >= 1e3 -> String.format(Locale.US, "%.0f KB", d / 1e3)
        else -> "$b B"
    }
}

/** Finds the phone's address on the hotspot, USB cable or Wi-Fi. Returns (address, interface name). */
fun findIp(mode: Int): Pair<String, String>? {
    val found = ArrayList<Pair<String, String>>()
    try {
        val all = NetworkInterface.getNetworkInterfaces() ?: return null
        for (ni in all) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.inetAddresses) {
                if (a is Inet4Address && a.isSiteLocalAddress) {
                    val host = a.hostAddress ?: continue
                    found.add(host to ni.name)
                }
            }
        }
    } catch (e: Exception) {
        return null
    }
    fun rank(n: String): Int {
        val usb = n.startsWith("rndis") || n.startsWith("usb") || n.startsWith("eth")
        val hot = n.startsWith("ap") || n.startsWith("swlan")
        val wifi = n.startsWith("wlan")
        return if (mode == 2) {
            when { usb -> 0; hot -> 1; wifi -> 2; else -> 3 }
        } else {
            when { hot -> 0; wifi -> 1; usb -> 2; else -> 3 }
        }
    }
    return found.minByOrNull { rank(it.second) }
}
