package com.breadwinner.wavelink

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.net.URLEncoder

/** The little web server on the phone. The PC just opens its address in a browser. */
class ShareServer(port: Int, private val ctx: Context) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        Hub.touch(session.remoteIpAddress ?: "?")
        val uri = session.uri
        return try {
            when {
                uri == "/" -> page()
                uri == "/api/items" -> listItems()
                uri.startsWith("/dl/") -> download(uri.removePrefix("/dl/").toIntOrNull(), session.method == Method.GET)
                uri == "/api/progress" -> progress(session)
                uri == "/upload" && session.method == Method.POST -> upload(session)
                else -> text(Status.NOT_FOUND, "Not found")
            }
        } catch (e: Exception) {
            text(Status.INTERNAL_ERROR, "Something went wrong on the phone")
        }
    }

    private fun text(status: Status, msg: String): Response =
        newFixedLengthResponse(status, "text/plain", msg)

    private fun page(): Response {
        val r = newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", PAGE)
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun listItems(): Response {
        val arr = JSONArray()
        for (f in Hub.items.toList()) {
            arr.put(JSONObject().put("id", f.id).put("name", f.name).put("size", f.size).put("kind", f.kind))
        }
        val r = newFixedLengthResponse(Status.OK, "application/json", JSONObject().put("items", arr).toString())
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun progress(session: IHTTPSession): Response {
        val p = session.parameters["p"]?.firstOrNull()?.toIntOrNull() ?: 0
        val n = session.parameters["n"]?.firstOrNull() ?: "file"
        Hub.recvUpdate(n, p / 100f)
        return text(Status.OK, "ok")
    }

    /** Counts the bytes going out so the phone can show a progress pie. */
    private inner class Counting(val src: InputStream, val total: Long) : InputStream() {
        private var n = 0L
        private var last = 0L
        private var ended = false

        override fun read(): Int {
            val b = src.read()
            if (b >= 0) bump(1) else finish(true)
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val k = src.read(b, off, len)
            if (k > 0) bump(k.toLong()) else if (k < 0) finish(true)
            return k
        }

        override fun available(): Int = src.available()

        override fun close() {
            try { src.close() } catch (e: Exception) { }
            finish(total < 0 || n >= total)
        }

        private fun bump(k: Long) {
            n += k
            if (total > 0) {
                val t = System.currentTimeMillis()
                if (t - last > 100) {
                    last = t
                    Hub.sendUpdate(n.toFloat() / total)
                }
            }
        }

        private fun finish(ok: Boolean) {
            if (!ended) {
                ended = true
                Hub.sendEnd(ok)
            }
        }
    }

    private fun download(id: Int?, track: Boolean): Response {
        if (id == null) return text(Status.NOT_FOUND, "Not found")
        val item = Hub.items.toList().firstOrNull { it.id == id } ?: return text(Status.NOT_FOUND, "Not found")
        val raw: InputStream = if (item.path != null) {
            FileInputStream(item.path)
        } else {
            val u = item.uri ?: return text(Status.NOT_FOUND, "Not found")
            ctx.contentResolver.openInputStream(u) ?: return text(Status.NOT_FOUND, "Not found")
        }
        val stream: InputStream = if (track) {
            Hub.sendStart(item.name)
            Counting(raw, item.size)
        } else {
            raw
        }
        val mime = if (item.kind == "app") "application/vnd.android.package-archive" else mimeOf(item.name)
        val r = if (item.size >= 0) {
            newFixedLengthResponse(Status.OK, mime, stream, item.size)
        } else {
            newChunkedResponse(Status.OK, mime, stream)
        }
        val enc = URLEncoder.encode(item.name, "UTF-8").replace("+", "%20")
        r.addHeader("Content-Disposition", "attachment; filename*=UTF-8''$enc")
        return r
    }

    private fun upload(session: IHTTPSession): Response {
        return try {
            val r = doUpload(session)
            Hub.recvEnd(true)
            r
        } catch (e: Exception) {
            Hub.recvEnd(false)
            throw e
        }
    }

    private fun doUpload(session: IHTTPSession): Response {
        val files = HashMap<String, String>()
        session.parseBody(files)
        val tmp = files["file"] ?: return text(Status.BAD_REQUEST, "No file")
        val raw = session.parameters["file"]?.firstOrNull() ?: "file"
        val name = raw.substringAfterLast('/').substringAfterLast('\\').ifBlank { "file" }
        val size = File(tmp).length()
        val saved = save(name, tmp)
        Hub.received.add(0, Got(name, size, System.currentTimeMillis(), saved))
        return text(Status.OK, "ok")
    }

    /** Puts the received file in Downloads/WaveLink. */
    private fun save(name: String, tmp: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/WaveLink")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create the file")
        resolver.openOutputStream(uri)!!.use { out ->
            FileInputStream(tmp).use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        File(tmp).delete()
        return uri
    }
}
