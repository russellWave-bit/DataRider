package com.breadwinner.wavelink

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFF0C1318)
val CardC = Color(0xFF141D24)
val TextC = Color(0xFFE6ECEF)
val Muted = Color(0xFF8394A0)
val Acc = Color(0xFF3A8EA8)
val Track = Color(0xFF1C2830)
val Orange = Color(0xFFD9772B)
val OnAcc = Color(0xFF071318)
val Sand = Color(0xFFDDB77B)
val Teal = Color(0xFF3BA793)
val DiscOn = Color(0xFF16313B)

enum class Pg { Home, Mode, Share, Received, Tips }

@Composable
fun T(
    text: String, size: Int = 13, color: Color = TextC,
    weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun RCard(modifier: Modifier = Modifier, bg: Color = CardC, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    var m = modifier.clip(RoundedCornerShape(10.dp)).background(bg)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(16.dp)) { content() }
}

@Composable
fun Pill(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (filled) Acc else Track)
            .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, if (filled) OnAcc else TextC) }
}

@Composable
fun Qr(text: String, dp: Dp) {
    val m = remember(text) {
        try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 1))
        } catch (e: Exception) {
            null
        }
    }
    Canvas(Modifier.size(dp).clip(RoundedCornerShape(6.dp)).background(Color.White)) {
        if (m != null) {
            val cell = this.size.width / m.width
            for (y in 0 until m.height) {
                for (x in 0 until m.width) {
                    if (m.get(x, y)) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
                }
            }
        }
    }
}

private fun wifiEsc(s: String): String =
    s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")

fun openTethering(c: Context) {
    val tries = listOf(
        Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
        Intent(Settings.ACTION_WIRELESS_SETTINGS)
    )
    for (i in tries) {
        try {
            c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
        }
    }
}

private fun addUri(c: Context, u: android.net.Uri) {
    try {
        c.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (e: Exception) {
    }
    var name = "file"
    var size = -1L
    c.contentResolver.query(u, null, null, null, null)?.use { cur ->
        if (cur.moveToFirst()) {
            val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = cur.getColumnIndex(OpenableColumns.SIZE)
            if (ni >= 0) name = cur.getString(ni) ?: "file"
            if (si >= 0 && !cur.isNull(si)) size = cur.getLong(si)
        }
    }
    Hub.items.add(Item(Hub.nextId(), name, size, "file", u, null))
}

data class AppRow(val label: String, val path: String, val size: Long, val split: Boolean)

// ───────────────────────── ROOT ─────────────────────────

@Composable
fun WaveLinkApp() {
    var pg by remember { mutableStateOf(Pg.Home) }
    var showApps by remember { mutableStateOf(false) }

    BackHandler(showApps || pg != Pg.Home) {
        if (showApps) showApps = false else pg = Pg.Home
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        when (pg) {
            Pg.Home -> HomePage { pg = it }
            Pg.Mode -> ModePage { pg = Pg.Home }
            Pg.Share -> SharePage({ pg = Pg.Home }, { showApps = true })
            Pg.Received -> ReceivedPage { pg = Pg.Home }
            Pg.Tips -> TipsPage { pg = Pg.Home }
        }
        if (showApps) AppPicker { showApps = false }
    }
}

@Composable
fun SubHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(CardC).clickable { onBack() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = 2.5.dp.toPx()
                drawLine(TextC, Offset(size.width * 0.62f, size.height * 0.2f), Offset(size.width * 0.32f, size.height * 0.5f), w, StrokeCap.Round)
                drawLine(TextC, Offset(size.width * 0.32f, size.height * 0.5f), Offset(size.width * 0.62f, size.height * 0.8f), w, StrokeCap.Round)
            }
        }
        Spacer(Modifier.width(12.dp))
        T(title, 22, weight = FontWeight.ExtraBold)
    }
}

// ───────────────────────── HOME ─────────────────────────

/** The big round button. Sending fills clockwise, receiving fills anticlockwise. */
@Composable
fun PieButton(
    running: Boolean, sendP: Float, recvP: Float, sendOn: Boolean, recvOn: Boolean,
    flash: Float, onClick: () -> Unit
) {
    val drift by rememberInfiniteTransition(label = "drift").animateFloat(
        0f, 6.2831855f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "d"
    )
    Box(Modifier.size(320.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = 105.dp.toPx()
            val phase = if (running) drift else 0f

            // faint waves behind the button
            for (k in 0..3) {
                val base = r + (23 + k * 9).dp.toPx()
                val amp = 2.5.dp.toPx()
                val path = Path()
                var i = 0
                while (i <= 360) {
                    val a = Math.toRadians(i.toDouble())
                    val rr = base + amp * sin(a * 7.0 + phase + k).toFloat()
                    val x = c.x + rr * cos(a).toFloat()
                    val y = c.y + rr * sin(a).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    i += 4
                }
                path.close()
                drawPath(path, Acc.copy(alpha = 0.12f - 0.025f * k), style = Stroke(1.dp.toPx()))
            }

            // thin ring
            drawCircle(Acc.copy(alpha = if (running) 0.55f else 0.35f), r + 11.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))

            // the disc
            drawCircle(if (running) DiscOn else Acc, r, c)

            // the pie
            val cap = if (sendOn && recvOn) 180f else 360f
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)
            if (sendP > 0f) drawArc(Acc, -90f, cap * sendP, true, tl, sz)
            if (recvP > 0f) drawArc(Teal, -90f, -cap * recvP, true, tl, sz)

            // sand flash when a file finishes
            if (flash > 0f) drawCircle(Sand.copy(alpha = flash * 0.85f), r, c)

            // symbol
            val w = 6.dp.toPx()
            val s = 60.dp.toPx()
            val x0 = c.x - s / 2
            val y0 = c.y - s / 2
            if (running) {
                drawRoundRect(TextC, Offset(x0 + s * 0.2f, y0 + s * 0.2f), Size(s * 0.6f, s * 0.6f), CornerRadius(4.dp.toPx()))
            } else {
                drawLine(OnAcc, Offset(c.x, y0 + s * 0.08f), Offset(c.x, y0 + s * 0.86f), w, StrokeCap.Round)
                drawLine(OnAcc, Offset(x0 + s * 0.18f, y0 + s * 0.56f), Offset(c.x, y0 + s * 0.88f), w, StrokeCap.Round)
                drawLine(OnAcc, Offset(x0 + s * 0.82f, y0 + s * 0.56f), Offset(c.x, y0 + s * 0.88f), w, StrokeCap.Round)
            }
        }
        Box(Modifier.size(210.dp).clip(CircleShape).clickable { onClick() })
    }
}

@Composable
fun HomePage(go: (Pg) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var ip by remember { mutableStateOf<Pair<String, String>?>(null) }

    LaunchedEffect(Hub.running, Hub.mode) {
        while (Hub.running) {
            ip = withContext(Dispatchers.Default) { findIp(Hub.mode) }
            Hub.recount()
            delay(2000)
        }
        ip = null
    }

    // pie animation
    val sendA = remember { Animatable(0f) }
    val recvA = remember { Animatable(0f) }
    val flash = remember { Animatable(0f) }
    LaunchedEffect(Hub.sendP) { if (Hub.sendOn) sendA.animateTo(Hub.sendP, tween(180)) }
    LaunchedEffect(Hub.recvP) { if (Hub.recvOn) recvA.animateTo(Hub.recvP, tween(180)) }
    LaunchedEffect(Hub.sendEndAt) {
        if (Hub.sendEndAt > 0 && System.currentTimeMillis() - Hub.sendEndAt < 1500) {
            if (Hub.sendOk) {
                sendA.animateTo(1f, tween(150))
                flash.snapTo(1f)
                flash.animateTo(0f, tween(800))
            }
            if (!Hub.sendOn) sendA.snapTo(0f)
        }
    }
    LaunchedEffect(Hub.recvEndAt) {
        if (Hub.recvEndAt > 0 && System.currentTimeMillis() - Hub.recvEndAt < 1500) {
            if (Hub.recvOk) {
                recvA.animateTo(1f, tween(150))
                flash.snapTo(1f)
                flash.animateTo(0f, tween(800))
            }
            if (!Hub.recvOn) recvA.snapTo(0f)
        }
    }

    val doStart: () -> Unit = {
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, ShareService::class.java).putExtra("mode", Hub.mode)
        )
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { doStart() }
    val toggle: () -> Unit = {
        if (Hub.running) {
            ctx.stopService(Intent(ctx, ShareService::class.java))
        } else {
            val need = ArrayList<String>()
            if (Build.VERSION.SDK_INT >= 33) {
                need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (Hub.mode == 1) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            } else if (Hub.mode == 1) {
                need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            val missing = need.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) doStart() else perms.launch(missing.toTypedArray())
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // top: name on the left, three-dot menu on the right
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            T("WaveLink", 24, weight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Box {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(CardC).clickable { menu = true },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.size(22.dp)) {
                        for (k in 0..2) drawCircle(TextC, 2.2.dp.toPx(), Offset(size.width / 2, size.height * (0.15f + 0.35f * k)))
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Connection mode") }, onClick = { menu = false; go(Pg.Mode) })
                    DropdownMenuItem(text = { Text("Shared files and apps") }, onClick = { menu = false; go(Pg.Share) })
                    DropdownMenuItem(text = { Text("Received from PC") }, onClick = { menu = false; go(Pg.Received) })
                    DropdownMenuItem(text = { Text("Tips") }, onClick = { menu = false; go(Pg.Tips) })
                }
            }
        }

        val body = Modifier.weight(1f).fillMaxWidth().navigationBarsPadding()
        Column(
            if (Hub.running) body.verticalScroll(rememberScrollState()) else body,
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = if (Hub.running) Arrangement.Top else Arrangement.Center
        ) {
            PieButton(Hub.running, sendA.value, recvA.value, Hub.sendOn, Hub.recvOn, flash.value, toggle)

            // "Share file" as plain text under the button
            Column(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable { go(Pg.Share) }.padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                T("Share file", 22, weight = FontWeight.ExtraBold)
                T(
                    if (Hub.items.isEmpty()) "Add files or apps" else "${Hub.items.size} ready for the PC",
                    12, Muted, FontWeight.Medium
                )
            }

            if (Hub.sendOn) {
                T("Sending " + (Hub.sendP * 100).toInt() + "%  " + Hub.sendName, 12, Acc, maxLines = 1,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
            }
            if (Hub.recvOn) {
                T("Receiving " + (Hub.recvP * 100).toInt() + "%  " + Hub.recvName, 12, Teal, maxLines = 1,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
            }
            if (!Hub.running) {
                Spacer(Modifier.height(2.dp))
                T("Tap the button to start", 12, Muted, FontWeight.Medium)
            }

            if (Hub.running && Hub.mode == 1 && Hub.hotspotMsg.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                T(Hub.hotspotMsg, 13, Orange, modifier = Modifier.padding(horizontal = 24.dp))
            }
            if (!Hub.running && Hub.hotspotMsg.isNotEmpty() && Hub.mode == 1) {
                Spacer(Modifier.height(8.dp))
                T(Hub.hotspotMsg, 13, Orange, modifier = Modifier.padding(horizontal = 24.dp))
            }

            if (Hub.running) {
                Spacer(Modifier.height(14.dp))
                AddressCard(ip)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun AddressCard(ip: Pair<String, String>?) {
    Column(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardC).padding(18.dp)
    ) {
        if (Hub.mode == 1) {
            T("Wi-Fi name", 11, Muted, FontWeight.Medium)
            T(if (Hub.ssid.isNotEmpty()) Hub.ssid else "Starting...", 22, weight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            T("Password", 11, Muted, FontWeight.Medium)
            T(if (Hub.pass.isNotEmpty()) Hub.pass else "...", 22, Acc, FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
        }
        T("Address", 11, Muted, FontWeight.Medium)
        if (ip != null) {
            T("http://" + ip.first + ":" + Hub.port, 22, weight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            T(
                if (Hub.devices > 0) Hub.devices.toString() + (if (Hub.devices == 1) " device connected" else " devices connected")
                else "Waiting for the PC",
                12, if (Hub.devices > 0) Sand else Muted, FontWeight.Medium
            )
        } else {
            T("Waiting for the network...", 16, weight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            T(
                when (Hub.mode) {
                    0 -> "Turn on your phone hotspot first. Connection mode has a shortcut."
                    1 -> "Starting the hotspot. This can take a few seconds."
                    else -> "Plug the cable into the PC and turn on USB tethering."
                },
                12, Muted, FontWeight.Medium
            )
        }
    }
}

// ───────────────────────── TIPS ─────────────────────────

@Composable
fun TipsPage(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Tips", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                T("Mobile data", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Transfers never use your bundle. Switch mobile data off while sharing so the PC cannot use it either.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Speed", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Stay close to the phone. With My hotspot, set the band to 5 GHz. A USB cable is the steadiest.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Progress pie", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Blue fills clockwise while the PC downloads from the phone. Green fills anticlockwise while the PC sends to the phone. Sand flashes when a file is done. Sending progress is close, not exact.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Auto hotspot", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Android picks the Wi-Fi name and password. The app shows them on the home screen once sharing starts.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ───────────────────────── CONNECTION MODE ─────────────────────────

@Composable
fun ModePage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Connection mode", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (Hub.running) T("Stop sharing on the home screen to change this.", 12, Orange, FontWeight.Medium)

            ModeCard(
                1, "Auto hotspot", "Default. The app makes a temporary hotspot for you.",
                listOf(
                    "1. Switch Location on (Android needs it for this).",
                    "2. Tap the big button and allow the permission.",
                    "3. Join the Wi-Fi shown on screen. Android picks the name and password, the app cannot choose them.",
                    "4. Turn off any normal hotspot first."
                ),
                null
            ) { }

            ModeCard(
                0, "My hotspot", "Fastest Wi-Fi option. Recommended.",
                listOf(
                    "1. Turn on your phone hotspot. Swipe down and hold Mobile Hotspot.",
                    "2. Set an easy password such as 12345678 under Configure.",
                    "3. Set the band to 5 GHz for speed.",
                    "4. Join that Wi-Fi on the PC, come back and tap the big button."
                ),
                "Open hotspot settings"
            ) { openTethering(ctx) }

            ModeCard(
                2, "USB cable", "Wired and steady. No Wi-Fi needed.",
                listOf(
                    "1. Plug the phone into the PC with a cable.",
                    "2. Turn on USB tethering in the phone's hotspot settings.",
                    "3. Come back and tap the big button. The address appears by itself."
                ),
                "Open tethering settings"
            ) { openTethering(ctx) }

            RCard(Modifier.fillMaxWidth()) {
                T("Always", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Switch mobile data off while sharing. Transfers never use data, but the PC could.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ModeCard(
    id: Int, title: String, sub: String, steps: List<String>, action: String?, onAction: () -> Unit
) {
    val ctx = LocalContext.current
    val sel = Hub.mode == id
    RCard(
        Modifier.fillMaxWidth(), bg = if (sel) Color(0xFF16303A) else CardC,
        onClick = { if (!Hub.running) Hub.setMode(ctx, id) }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 17, weight = FontWeight.ExtraBold)
                T(sub, 12, Muted, FontWeight.Medium)
            }
            if (sel) T("Selected", 12, Sand)
        }
        if (sel) {
            Spacer(Modifier.height(10.dp))
            steps.forEach {
                T(it, 12, TextC, FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
            }
            if (action != null) {
                Spacer(Modifier.height(8.dp))
                Pill(action, false) { onAction() }
            }
        }
    }
}

// ───────────────────────── SHARE FILE ─────────────────────────

@Composable
fun SharePage(onBack: () -> Unit, openApps: () -> Unit) {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) addUri(ctx, u)
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Share file", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Add files") { pick.launch(arrayOf("*/*")) }
                Pill("Add apps", false) { openApps() }
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Ready for the PC", 15)
                Spacer(Modifier.height(8.dp))
                if (Hub.items.isEmpty()) T("Nothing yet. Add files or apps above.", 13, Muted, FontWeight.Medium)
                for (it in Hub.items.toList()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        T(if (it.kind == "app") "APP" else "FILE", 11, Acc, modifier = Modifier.width(44.dp))
                        Column(Modifier.weight(1f)) {
                            T(it.name, 13)
                            T(fmtSize(it.size), 11, Muted, FontWeight.Medium)
                        }
                        T("Remove", 12, Orange, modifier = Modifier.clickable { Hub.items.remove(it) }.padding(8.dp))
                    }
                }
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Good to know", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Some apps are made of several files. Sharing one of those may not install on its own on another phone.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun AppPicker(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val apps by produceState<List<AppRow>>(emptyList()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(0)
                .filter {
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                }
                .map {
                    AppRow(
                        it.loadLabel(pm).toString(), it.sourceDir, File(it.sourceDir).length(),
                        (it.splitSourceDirs?.size ?: 0) > 0
                    )
                }
                .sortedBy { it.label.lowercase() }
        }
    }
    val shown = apps.filter { it.label.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            T("Add apps", 22, weight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Pill("Done") { onClose() }
        }
        BasicTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            textStyle = TextStyle(color = TextC, fontSize = 16.sp),
            cursorBrush = SolidColor(Acc),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) T("Search apps", 16, Muted, FontWeight.Medium)
                    inner()
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(10.dp)).background(CardC).padding(14.dp)
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            items(shown) { a ->
                val on = Hub.items.any { it.path == a.path }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(a.label, 14)
                        T(fmtSize(a.size) + if (a.split) "  (several files)" else "", 11, Muted, FontWeight.Medium)
                    }
                    Checkbox(
                        checked = on,
                        onCheckedChange = { v ->
                            if (v && !on) {
                                Hub.items.add(Item(Hub.nextId(), a.label + ".apk", a.size, "app", null, a.path))
                            } else if (!v) {
                                Hub.items.removeAll { it.path == a.path }
                            }
                        },
                        colors = CheckboxDefaults.colors(checkedColor = Acc, checkmarkColor = OnAcc, uncheckedColor = Muted)
                    )
                }
            }
        }
    }
}

// ───────────────────────── RECEIVED ─────────────────────────

@Composable
fun ReceivedPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val f = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Received from PC", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                if (Hub.received.isEmpty()) T("Nothing yet. Files you send from the PC page appear here.", 13, Muted, FontWeight.Medium)
                for (g in Hub.received.toList()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            T(g.name, 13)
                            T(fmtSize(g.size) + "  " + f.format(Date(g.time)), 11, Muted, FontWeight.Medium)
                        }
                        if (g.uri != null) {
                            T("Open", 13, Acc, modifier = Modifier.clickable {
                                try {
                                    val type = ctx.contentResolver.getType(g.uri) ?: "*/*"
                                    ctx.startActivity(
                                        Intent(Intent.ACTION_VIEW).setDataAndType(g.uri, type)
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                } catch (e: Exception) {
                                }
                            }.padding(8.dp))
                        }
                    }
                }
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Saved in Downloads/WaveLink on this phone.", 12, Muted, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
