# Data Rider

A personal data usage tracker for the Samsung Galaxy Note 10 Plus (Android 10 and up).
Kotlin + Jetpack Compose. Dark and light themes, custom accent colour, a Hill Climb style car that rides your live data flow.

## Build and install

1. Install **Android Studio** (free) on a computer.
2. Unzip this folder, then in Android Studio choose **Open** and pick the `DataRider` folder.
   Let it finish the Gradle sync (it downloads what it needs; the first time takes a few minutes).
3. On the phone: Settings > About phone > Software information > tap **Build number** 7 times,
   then Settings > Developer options > turn on **USB debugging**.
4. Plug the phone in with a cable, accept the "Allow USB debugging" prompt, pick the phone at the top of
   Android Studio and press the green **Run** button. The app installs and opens.

To get a plain APK file instead: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The file lands in
`app/build/outputs/apk/debug/app-debug.apk`. Copy it to the phone and tap it to install
(allow "Install unknown apps" for your file manager when asked).

## First launch

The setup screen walks you through, one tap each:
- **Usage access** (required) - reads Android's data history.
- **Display over other apps** - for the floating Network Traffic panel.
- **Notifications** - for the 75% chime and limit alerts.
- **No battery restriction** - so Samsung doesn't put the tracker to sleep.
- **Location** (optional) - Android needs it to show Wi-Fi names, nearby networks and cell towers.

On Samsung also set: Settings > Apps > Data Rider > Battery > **Unrestricted**.

## What is in it

- Home: live flow band with the car, today's usage, top apps, cycle total, speed test, daily limit, streak, devices.
- Usage: All / Wi-Fi / Mobile, 30 min to 1 year, screen-off usage, insights, 30 day bar chart (tap a bar), usage by Wi-Fi network.
- Apps, Limits (daily limit, billing cycle day, alert sounds), Speed test, Settings (themes, accent colour, overlay opacity).
- Tools: Network Traffic overlay, Device Discovery, Connection Log, Wi-Fi Analyzer, Cell Towers, Network Connections, Ping Test.
- Always-on notification showing live speed.

## Known limits (Android, not the app)

- Android keeps usage history for a limited time, usually weeks. The app starts saving its own history from the day you install.
- Per-app speed in the overlay updates in chunks, not second by second.
- Android 10+ blocks apps from listing other apps' open sockets, so Network Connections shows recent per-app activity instead.
- Device Discovery matches by IP and name because Android hides device hardware addresses.
- Alert sounds use your phone's default notification, alarm and ringtone sounds. Change them in Android's channel settings (Limits > Change alert sounds).

## Rename or re-icon

App name: `AndroidManifest.xml` (`android:label`). Icon: `res/drawable/ic_launcher_foreground.xml`.
