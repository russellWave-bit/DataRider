package com.breadwinner.datarider

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager

object Alerts {
    const val CH_LIVE = "live"
    const val CH_CHIME = "chime"
    const val CH_WARN = "warn"
    const val CH_OUT = "out"

    /** Three alert channels, each with its own sound. You can change the sounds in Android's channel settings. */
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LIVE, "Live speed", NotificationManager.IMPORTANCE_LOW))

        fun ch(id: String, name: String, soundType: Int, usage: Int, pattern: LongArray) {
            val n = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH)
            n.setSound(RingtoneManager.getDefaultUri(soundType), AudioAttributes.Builder().setUsage(usage).build())
            n.vibrationPattern = pattern
            n.enableVibration(true)
            nm.createNotificationChannel(n)
        }
        ch(CH_CHIME, "75% chime", RingtoneManager.TYPE_NOTIFICATION, AudioAttributes.USAGE_NOTIFICATION, longArrayOf(0, 200))
        ch(CH_WARN, "Almost out of data", RingtoneManager.TYPE_ALARM, AudioAttributes.USAGE_ALARM, longArrayOf(0, 300, 150, 300))
        ch(CH_OUT, "Out of data", RingtoneManager.TYPE_RINGTONE, AudioAttributes.USAGE_NOTIFICATION_RINGTONE, longArrayOf(0, 600, 200, 600, 200, 600))
    }

    fun post(c: Context, channel: String, id: Int, title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n: Notification = Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: SecurityException) {
        }
    }

    /** Called with today's total; fires each level once per day. */
    fun check(c: Context, todayBytes: Long) {
        val limit = Prefs.dailyLimitMb * 1_000_000.0
        if (limit <= 0) return
        val pct = todayBytes / limit
        val day = dayStart()
        var last = Prefs.alertLevel()
        if (Prefs.alertDay() != day) {
            last = 0
            Prefs.setAlert(day, 0)
        }
        val level = when {
            pct >= 1.0 -> 3
            pct >= 0.9 -> 2
            pct >= 0.75 -> 1
            else -> 0
        }
        if (level > last) {
            Prefs.setAlert(day, level)
            val used = fmtBytes(todayBytes)
            when (level) {
                1 -> if (Prefs.alert75) post(c, CH_CHIME, 11, "75% of today's data used", "$used so far. Easy does it.")
                2 -> if (Prefs.alertLimit) post(c, CH_WARN, 12, "Almost out for today", "$used used, close to your limit.")
                3 -> if (Prefs.alertLimit) post(c, CH_OUT, 13, "Daily limit reached", "$used used. You're out for today.")
            }
        }
    }
}
