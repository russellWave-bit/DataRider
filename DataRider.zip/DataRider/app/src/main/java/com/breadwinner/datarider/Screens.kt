package com.breadwinner.datarider

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ln

// ───────────────────────── HOME ─────────────────────────

data class HomeData(
    val m: Long, val w: Long, val apps: List<AppUse>, val month: Long,
    val week: List<Long>, val streak: Int, val speed: SpeedRow?
)

private fun loadHome(repo: UsageRepo): HomeData {
    val now = System.currentTimeMillis()
    val (m, w) = repo.range(dayStart(now), now)
    val (cm, cw) = repo.range(cycleStart(Prefs.billingDay), now)
    val days = repo.daily(60)
    val limit = (Prefs.dailyLimitMb * 1_000_000.0).toLong()
    var streak = 0
    for (d in days.reversed()) {
        val t = d.mobile + d.wifi
        if (t in 1..limit) streak++ else break
    }
    Live.today = m + w
    return HomeData(m, w, repo.apps(dayStart(now), now).take(3), cm + cw, days.takeLast(7).map { it.mobile + it.wifi }, streak, Store.db.recentSpeeds(1).firstOrNull())
}

@Composable
fun HomeScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val repo = remember { UsageRepo(ctx) }
    val data by produceState<HomeData?>(null) {
        while (true) {
            value = withContext(Dispatchers.IO) { loadHome(repo) }
            delay(8000)
        }
    }
    val d = data
    val m = d?.m ?: 0L
    val w = d?.w ?: 0L
    val total = m + w
    val limit = Prefs.dailyLimitMb * 1_000_000.0
    val pct = if (limit > 0) (total / limit).toFloat() else 0f
    val v = Live.down + Live.up
    val inten = (ln(1.0 + v / 20_000.0) / ln(251.0)).toFloat().coerceIn(0f, 1f)
    val (sv, su) = speedParts(Live.down + Live.up)
    val (tv, tu) = bytesParts(total)
    val date = remember { SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()) }

    Column(Modifier.fillMaxSize().background(p.bg)) {
        // live-flow band: square corners, edge to edge, in the accent colour
        Box(Modifier.fillMaxWidth().background(p.accent)) {
            Column(Modifier.statusBarsPadding().fillMaxWidth().height(196.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    MenuButton(nav.menuP, p.onAccent.copy(alpha = 0.16f), p.onAccent, nav.open)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        T(date.uppercase(), 11, p.onAccent.copy(alpha = 0.8f))
                        T("Home", 18, p.onAccent, FontWeight.ExtraBold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        T("Down ${speedStr(Live.down)}", 12, p.onAccent)
                        T("Up ${speedStr(Live.up)}", 12, p.onAccent)
                    }
                }
                Column(Modifier.padding(start = 20.dp)) {
                    T("LIVE FLOW", 11, p.onAccent.copy(alpha = 0.75f))
                    Row(verticalAlignment = Alignment.Bottom) {
                        T(sv, 60, p.onAccent, FontWeight.ExtraBold)
                        T(su, 22, p.onAccent, FontWeight.ExtraBold, Modifier.padding(start = 8.dp, bottom = 10.dp))
                    }
                }
            }
            HillsCanvas(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(80.dp), inten, p.onAccent)
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // today's usage
            RCard(Modifier.fillMaxWidth(), onClick = { nav.go(Screen.Usage) }) {
                T("Today's usage", 13, p.muted)
                Row(verticalAlignment = Alignment.Bottom) {
                    T(tv, 36, weight = FontWeight.ExtraBold)
                    T(tu, 16, p.muted, modifier = Modifier.padding(start = 6.dp, bottom = 5.dp))
                    Spacer(Modifier.weight(1f))
                    T("${(pct * 100).toInt()}% of ${fmtBytes((limit).toLong())} limit", 12, p.muted, modifier = Modifier.padding(bottom = 5.dp))
                }
                Spacer(Modifier.height(10.dp))
                val mFrac = if (total > 0) m.toFloat() / total else 0.5f
                Row(Modifier.fillMaxWidth().height(9.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(Modifier.weight(mFrac.coerceIn(0.05f, 0.95f)).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(p.accent))
                    Box(Modifier.weight((1f - mFrac).coerceIn(0.05f, 0.95f)).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(p.muted.copy(alpha = 0.6f)))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    T("Mobile ${fmtBytes(m)}", 12, p.accText)
                    T("Wi-Fi ${fmtBytes(w)}", 12, p.muted)
                }
            }

            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RCard(Modifier.weight(1f).fillMaxHeight(), onClick = { nav.go(Screen.Apps) }) {
                    T("Top apps today", 13, p.muted)
                    Spacer(Modifier.height(10.dp))
                    val apps = d?.apps ?: emptyList()
                    val mx = (apps.firstOrNull()?.total ?: 1L).toFloat()
                    if (apps.isEmpty()) T("No data yet", 12, p.muted)
                    apps.forEach {
                        UseRow(it.label, fmtBytes(it.total), it.total / mx)
                        Spacer(Modifier.height(9.dp))
                    }
                }
                RCard(Modifier.weight(1f).fillMaxHeight(), onClick = { nav.go(Screen.Usage) }) {
                    T("This cycle", 13, p.muted)
                    Row(verticalAlignment = Alignment.Bottom) {
                        val (a, b) = bytesParts(d?.month ?: 0L)
                        T(a, 28, weight = FontWeight.ExtraBold)
                        T(b, 14, p.muted, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    val week = d?.week ?: emptyList()
                    val wmx = (week.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
                    Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Bottom) {
                        week.forEachIndexed { i, x ->
                            Box(
                                Modifier.weight(1f).fillMaxHeight((x / wmx).coerceAtLeast(0.06f)).clip(RoundedCornerShape(3.dp))
                                    .background(if (i == week.lastIndex) p.accent else p.muted.copy(alpha = 0.38f))
                            )
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RCard(Modifier.weight(1f), onClick = { nav.go(Screen.Usage) }) {
                    T("Mobile", 13, p.muted)
                    val (a, b) = bytesParts(m)
                    Row(verticalAlignment = Alignment.Bottom) {
                        T(a, 24, weight = FontWeight.ExtraBold)
                        T("$b today", 12, p.muted, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp))
                    }
                    T("4G · Connected", 12, p.accText)
                }
                RCard(Modifier.weight(1f), onClick = { nav.go(Screen.Usage) }) {
                    T("Wi-Fi", 13, p.muted)
                    val (a, b) = bytesParts(w)
                    Row(verticalAlignment = Alignment.Bottom) {
                        T(a, 24, weight = FontWeight.ExtraBold)
                        T("$b today", 12, p.muted, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp))
                    }
                    T("Tap for details", 12, p.muted)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RCard(Modifier.weight(1f), onClick = { nav.go(Screen.SpeedTest) }) {
                    T("Speed test", 13, p.muted)
                    val s = d?.speed
                    T(if (s != null) "${f1(s.down)} Mbps down" else "Not run yet", 15)
                    T(if (s != null) "${f1(s.up)} Mbps up" else "Tap to test", 12, p.muted)
                }
                RCard(Modifier.weight(1f), onClick = { nav.go(Screen.Limits) }) {
                    T("Daily limit", 13, p.muted)
                    T("${fmtBytes(total)} of ${fmtBytes(limit.toLong())}", 14)
                    Spacer(Modifier.height(8.dp))
                    LimitBar(pct)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RCard(Modifier.weight(1f), onClick = { nav.go(Screen.Limits) }) {
                    T("Achievements", 13, p.muted)
                    Row(verticalAlignment = Alignment.Bottom) {
                        T("${d?.streak ?: 0}", 28, weight = FontWeight.ExtraBold)
                        T("days under limit", 12, p.muted, modifier = Modifier.padding(start = 5.dp, bottom = 4.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    val s = (d?.streak ?: 0) % 7
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (i in 0 until 7) {
                            Box(Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(4.dp)).background(if (i < s || (d?.streak ?: 0) >= 7 && s == 0) p.accent else p.track))
                        }
                    }
                }
                RCard(Modifier.weight(1f), onClick = { nav.go(Screen.Devices) }) {
                    T("Devices found", 13, p.muted)
                    Row(verticalAlignment = Alignment.Bottom) {
                        T("${Prefs.lastDevices}", 28, weight = FontWeight.ExtraBold)
                        T("on your Wi-Fi", 12, p.muted, modifier = Modifier.padding(start = 5.dp, bottom = 4.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    T("Tap to scan", 12, p.accText)
                }
            }
        }
    }
}

/** Bar that turns orange past 75% and red near the limit. */
@Composable
fun LimitBar(pct: Float) {
    val p = LocalPal.current
    val col = when { pct >= 0.9f -> Red; pct >= 0.75f -> Orange; else -> p.accent }
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.track)) {
        Box(Modifier.fillMaxWidth(pct.coerceIn(0.02f, 1f)).fillMaxHeight().background(col))
    }
}

// ───────────────────────── USAGE ─────────────────────────

data class UsageData(
    val m: Long, val w: Long, val offM: Long, val offW: Long,
    val apps: List<AppUse>, val days: List<DayUse>, val nets: List<Pair<String, Long>>
)

private val RANGE_LABELS = listOf("30 min", "1 hour", "1 day", "1 week", "30 days", "Cycle", "1 year")

private fun rangeFrom(i: Int, now: Long): Long = when (i) {
    0 -> now - 30 * 60_000L
    1 -> now - 3_600_000L
    2 -> now - 86_400_000L
    3 -> now - 7 * 86_400_000L
    4 -> now - 30 * 86_400_000L
    5 -> cycleStart(Prefs.billingDay, now)
    else -> now - 365 * 86_400_000L
}

private fun loadUsage(repo: UsageRepo, i: Int): UsageData {
    val now = System.currentTimeMillis()
    val from = rangeFrom(i, now)
    val (m, w) = repo.range(from, now)
    val s = Store.db.sums(from, now)
    return UsageData(
        m, w, s[2], s[3], repo.apps(from, now), repo.daily(30),
        Store.db.wifiByNet(dayStart(now) - 30 * 86_400_000L)
    )
}

private fun insights(d: UsageData, src: Int): List<String> {
    val out = mutableListOf<String>()
    val total = pick(d.m, d.w, src)
    d.apps.filter { it.bg > 30_000_000 && it.bg > it.total * 0.6 }.take(3).forEach {
        out.add("${it.label} used ${fmtBytes(it.bg)} in the background, ${100 * it.bg / it.total}% of its data.")
    }
    d.apps.firstOrNull()?.let {
        val mine = pick(it.mobile, it.wifi, src)
        if (total > 0 && mine > total * 0.4) out.add("${it.label} alone is ${100 * mine / total}% of your data.")
    }
    val off = pick(d.offM, d.offW, src)
    if (total > 0 && off > total * 0.15) out.add("${100 * off / total}% of your data moved while the screen was off.")
    if (out.isEmpty()) out.add("Nothing is wasting data right now.")
    return out
}

@Composable
fun UsageScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val repo = remember { UsageRepo(ctx) }
    var src by remember { mutableStateOf(0) }
    var range by remember { mutableStateOf(4) }
    var tab by remember { mutableStateOf(0) }
    var sel by remember { mutableStateOf(29) }
    val data by produceState<UsageData?>(null, range) { value = withContext(Dispatchers.IO) { loadUsage(repo, range) } }
    val d = data

    Page("Usage", nav) {
        Seg(listOf("All", "Wi-Fi", "Mobile"), src) { src = it }
        Chips(RANGE_LABELS, range) { range = it }

        RCard(Modifier.fillMaxWidth()) {
            T("Last ${RANGE_LABELS[range].lowercase()}", 13, p.muted)
            val (a, b) = bytesParts(if (d != null) pick(d.m, d.w, src) else 0L)
            Row(verticalAlignment = Alignment.Bottom) {
                T(a, 40, weight = FontWeight.ExtraBold)
                T(b, 17, p.muted, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
            }
            if (d != null) Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                T("Mobile ${fmtBytes(d.m)}", 12, p.accText)
                T("Wi-Fi ${fmtBytes(d.w)}", 12, p.muted)
            }
        }

        // two tabs side by side
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val offBytes = if (d != null) pick(d.offM, d.offW, src) else 0L
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (tab == 0) p.accent.copy(alpha = 0.22f) else p.card)
                    .clickable { tab = 0 }.padding(14.dp)
            ) {
                T("Screen-off usage", 12, if (tab == 0) p.accText else p.muted)
                T(fmtBytes(offBytes), 22, weight = FontWeight.ExtraBold)
                T("while screen was off", 11, p.muted, FontWeight.Medium)
            }
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (tab == 1) p.accent.copy(alpha = 0.22f) else p.card)
                    .clickable { tab = 1 }.padding(14.dp)
            ) {
                T("Insights", 12, if (tab == 1) p.accText else p.muted)
                T("${if (d != null) insights(d, src).size else 0} found", 22, Orange, FontWeight.ExtraBold)
                T("what's draining data", 11, p.muted, FontWeight.Medium)
            }
        }
        if (tab == 1 && d != null) {
            RCard(Modifier.fillMaxWidth()) {
                insights(d, src).forEach {
                    T(it, 13, p.text, FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        // daily trend: 30 grey bars, tap one
        RCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T("Daily trend", 15)
                T("per day", 11, p.muted)
            }
            Spacer(Modifier.height(12.dp))
            val days = d?.days ?: emptyList()
            val vals = days.map { pick(it.mobile, it.wifi, src) }
            val mx = (vals.maxOrNull() ?: 1L).coerceAtLeast(1L)
            Row {
                Column(Modifier.width(52.dp).height(140.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    T(fmtBytes(mx), 10, p.muted)
                    T(fmtBytes(mx / 2), 10, p.muted)
                    T("0", 10, p.muted)
                }
                Row(Modifier.weight(1f).height(140.dp), verticalAlignment = Alignment.Bottom) {
                    vals.forEachIndexed { i, v ->
                        Box(Modifier.weight(1f).fillMaxHeight().clickable { sel = i }.padding(horizontal = 1.dp), contentAlignment = Alignment.BottomCenter) {
                            Box(
                                Modifier.fillMaxWidth().fillMaxHeight((v.toFloat() / mx).coerceAtLeast(0.02f))
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (i == sel) p.accent else p.muted.copy(alpha = 0.38f))
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (days.isNotEmpty()) {
                val f = SimpleDateFormat("d MMM", Locale.getDefault())
                Row(Modifier.fillMaxWidth().padding(start = 52.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T(f.format(Date(days.first().start)), 10, p.muted)
                    T(f.format(Date(days[days.size / 2].start)), 10, p.muted)
                    T("Today", 10, p.muted)
                }
            }
            // tapped day slides up
            val day = days.getOrNull(sel)
            if (day != null) {
                Spacer(Modifier.height(12.dp))
                AnimatedContent(
                    targetState = day,
                    transitionSpec = { (slideInVertically { it / 2 } + fadeIn()) togetherWith fadeOut() },
                    label = "day"
                ) { dd ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.accent.copy(alpha = 0.16f)).padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            T(SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(dd.start)), 11, p.accText)
                            T(fmtBytes(pick(dd.mobile, dd.wifi, src)), 20, weight = FontWeight.ExtraBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            T("Mobile ${fmtBytes(dd.mobile)}", 12, p.accText)
                            T("Wi-Fi ${fmtBytes(dd.wifi)}", 12, p.muted)
                        }
                    }
                }
            }
        }

        // by Wi-Fi network (the app's own log)
        if (d != null && d.nets.isNotEmpty() && src != 2) {
            RCard(Modifier.fillMaxWidth()) {
                T("Usage by Wi-Fi network (30 days)", 15)
                Spacer(Modifier.height(10.dp))
                val mx = d.nets.first().second.toFloat().coerceAtLeast(1f)
                d.nets.take(6).forEach {
                    UseRow(it.first, fmtBytes(it.second), it.second / mx)
                    Spacer(Modifier.height(9.dp))
                }
            }
        }
    }
}

// ───────────────────────── APPS ─────────────────────────

@Composable
fun AppsScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val repo = remember { UsageRepo(ctx) }
    var src by remember { mutableStateOf(0) }
    var range by remember { mutableStateOf(2) }
    val labels = listOf("1 hour", "1 day", "1 week", "30 days", "Cycle")
    val apps by produceState<List<AppUse>>(emptyList(), range) {
        value = withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val from = when (range) {
                0 -> now - 3_600_000L
                1 -> now - 86_400_000L
                2 -> now - 7 * 86_400_000L
                3 -> now - 30 * 86_400_000L
                else -> cycleStart(Prefs.billingDay, now)
            }
            repo.apps(from, now)
        }
    }
    Page("Apps", nav) {
        Seg(listOf("All", "Wi-Fi", "Mobile"), src) { src = it }
        Chips(labels, range) { range = it }
        val rows = apps.map { it to pick(it.mobile, it.wifi, src) }.filter { it.second > 0 }.sortedByDescending { it.second }
        val mx = (rows.firstOrNull()?.second ?: 1L).toFloat()
        RCard(Modifier.fillMaxWidth()) {
            if (rows.isEmpty()) T("No app data for this range yet.", 13, p.muted)
            rows.take(40).forEach { (a, v) ->
                UseRow(a.label, fmtBytes(v), v / mx)
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

// ───────────────────────── LIMITS ─────────────────────────

@Composable
fun LimitsScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val limit = Prefs.dailyLimitMb * 1_000_000.0
    val pct = if (limit > 0) (Live.today / limit).toFloat() else 0f

    Page("Limits", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Daily limit", 15)
            Spacer(Modifier.height(4.dp))
            T(fmtBytes(limit.toLong()), 30, p.accText, FontWeight.ExtraBold)
            Slider(
                value = Prefs.dailyLimitMb, onValueChange = { Prefs.dailyLimitMb = it },
                valueRange = 100f..20000f, onValueChangeFinished = { Prefs.save() },
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.track)
            )
            Spacer(Modifier.height(6.dp))
            T("Today: ${fmtBytes(Live.today)}  (${(pct * 100).toInt()}%)", 13, p.muted)
            Spacer(Modifier.height(8.dp))
            LimitBar(pct)
            Spacer(Modifier.height(6.dp))
            T("Blue while you're fine, orange past 75%, red near the limit.", 11, p.muted, FontWeight.Medium)
        }

        RCard(Modifier.fillMaxWidth()) {
            T("Billing cycle", 15)
            T("The day your data bundle renews, so the month matches your plan.", 12, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                PillButton("-", false) { Prefs.billingDay = (Prefs.billingDay - 1).coerceAtLeast(1); Prefs.save() }
                T("Day ${Prefs.billingDay}", 18, weight = FontWeight.ExtraBold)
                PillButton("+", false) { Prefs.billingDay = (Prefs.billingDay + 1).coerceAtMost(28); Prefs.save() }
            }
        }

        RCard(Modifier.fillMaxWidth()) {
            T("Alerts", 15)
            Spacer(Modifier.height(6.dp))
            ToggleRow("75% chime", Prefs.alert75) { Prefs.alert75 = it; Prefs.save() }
            ToggleRow("Near-limit and out-of-data sounds", Prefs.alertLimit) { Prefs.alertLimit = it; Prefs.save() }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("Test 75%", false) { Alerts.post(ctx, Alerts.CH_CHIME, 21, "Test: 75% used", "This is the chime.") }
                PillButton("Test near", false) { Alerts.post(ctx, Alerts.CH_WARN, 22, "Test: almost out", "This is the sharper one.") }
                PillButton("Test out", false) { Alerts.post(ctx, Alerts.CH_OUT, 23, "Test: out of data", "This is the last one.") }
            }
            Spacer(Modifier.height(10.dp))
            PillButton("Change alert sounds") {
                ctx.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, modifier = Modifier.weight(1f))
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = p.accent, checkedThumbColor = p.onAccent, uncheckedTrackColor = p.track)
        )
    }
}

// ───────────────────────── SETTINGS ─────────────────────────

@Composable
fun SettingsScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    Page("Settings", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Themes", 15)
            Spacer(Modifier.height(10.dp))
            Seg(listOf("Follow phone", "Dark", "Light"), Prefs.theme) { Prefs.theme = it; Prefs.save() }
        }

        RCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Accent colour", 15, modifier = Modifier.weight(1f))
                Box(Modifier.size(18.dp).clip(CircleShape).background(p.accent))
            }
            Spacer(Modifier.height(14.dp))
            Spectrum(Prefs.hue, { Prefs.hue = it }, { Prefs.save() })
            Spacer(Modifier.height(14.dp))
            T("Brightness  ${(Prefs.brightness * 100).toInt()}%", 12, p.muted)
            Slider(
                value = Prefs.brightness, onValueChange = { Prefs.brightness = it }, valueRange = 0.3f..1f,
                onValueChangeFinished = { Prefs.save() },
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.track)
            )
            T("Opacity  ${(Prefs.opacity * 100).toInt()}%", 12, p.muted)
            Slider(
                value = Prefs.opacity, onValueChange = { Prefs.opacity = it }, valueRange = 0.3f..1f,
                onValueChangeFinished = { Prefs.save() },
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.track)
            )
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.bg).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                T("Live preview", 12, p.muted, modifier = Modifier.weight(1f))
                Box(Modifier.width(60.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.accent))
                T("  2.4 GB", 14, p.accText)
            }
            Spacer(Modifier.height(8.dp))
            T("Alert colours stay orange and red so warnings always stand out.", 11, p.muted, FontWeight.Medium)
        }

        RCard(Modifier.fillMaxWidth()) {
            T("Network Traffic overlay", 15)
            Spacer(Modifier.height(4.dp))
            T("Opacity  ${(Prefs.overlayOpacity * 100).toInt()}%", 12, p.muted)
            Slider(
                value = Prefs.overlayOpacity, onValueChange = { Prefs.overlayOpacity = it }, valueRange = 0.1f..1f,
                onValueChangeFinished = { Prefs.save() },
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.track)
            )
            T("Applies the next time the overlay opens.", 11, p.muted, FontWeight.Medium)
        }

        RCard(Modifier.fillMaxWidth()) {
            T("Permissions", 15)
            Spacer(Modifier.height(8.dp))
            PermRow("Usage access", UsageRepo.hasAccess(ctx)) { openUsageAccess(ctx) }
            PermRow("Display over other apps", Perm.overlay(ctx)) { openOverlayAccess(ctx) }
            PermRow("Notifications", Perm.notif(ctx)) {
                ctx.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            PermRow("No battery restriction", Perm.battery(ctx)) { openBattery(ctx) }
        }
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, onFix: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, modifier = Modifier.weight(1f))
        if (ok) T("On", 13, p.accText) else T("Fix", 13, Orange, modifier = Modifier.clickable { onFix() }.padding(8.dp))
    }
}

/** Rainbow bar. Tap or drag to pick any accent colour. */
@Composable
fun Spectrum(hue: Float, onHue: (Float) -> Unit, onDone: () -> Unit) {
    val colors = remember { (0..12).map { Color.hsv(it * 30f % 360f, 0.82f, 1f) } }
    var w by remember { mutableStateOf(1) }
    Box(
        Modifier.fillMaxWidth().height(30.dp).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .clip(RoundedCornerShape(15.dp)).background(Brush.horizontalGradient(colors))
            .pointerInput(Unit) {
                detectTapGestures { o -> onHue((o.x / w * 360f).coerceIn(0f, 359f)); onDone() }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o -> onHue((o.x / w * 360f).coerceIn(0f, 359f)) },
                    onDragEnd = { onDone() }
                ) { change, _ -> onHue((change.position.x / w * 360f).coerceIn(0f, 359f)) }
            }
    ) {
        Box(
            Modifier.offset { IntOffset((hue / 360f * w).toInt() - 14.dp.roundToPx(), 1.dp.roundToPx()) }
                .size(28.dp).clip(CircleShape).background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(18.dp).clip(CircleShape).background(Color.hsv(hue, 0.82f, 1f)))
        }
    }
}
