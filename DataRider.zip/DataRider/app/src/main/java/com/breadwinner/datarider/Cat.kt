package com.breadwinner.datarider

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * The pixel cat. Each frame is a 30 x 20 grid of little squares:
 * O orange, D dark tabby stripe, d far-side leg, W cream, K outline, P pink.
 */
private const val CAT_W = 30
private const val CAT_H = 20

private val CAT_RUN0 = arrayOf(
    "..............................",
    "...K.................KK..KK...",
    "..KDK...............KOOKKOOK..",
    ".KODK.........K.....KOPOOOPOK.",
    ".KOK.....KKKKKOKKKKKKOOODOOOK.",
    ".KDK...KKDOODOODOODOOOODDDOOOK",
    ".KODK.KOODOODOODOODOOOOOOKKOOK",
    "..KDOKOOODOODOODOODOOOWWWWWWPK",
    "...KODODOOOOOOOOOOOOOOOWWWWWK.",
    "....KDODOOOOOOOOOOOOOOOOOWOK..",
    ".....KOOOOWWWWWWWWWWOOKKKKK...",
    "......KKKOWWWWWWWWWWKK........",
    ".......KOOddKKWKKddOOK........",
    "......KOOKddK.K.KddKOOK.......",
    ".....KOOKddK.....KddKOOK......",
    "....KWWKKWWK.....KWWKKWWK.....",
    ".....KK..KK.......KK..KK......",
    "..............................",
    "..............................",
    ".............................."
)

private val CAT_RUN1 = arrayOf(
    "..............................",
    "..............................",
    ".....................KK..KK...",
    ".K..................KOOKKOOK..",
    "KDK...........K.....KOPOOOPOK.",
    "KDK......KKKKKOKKKKKKOOODOOOK.",
    "KOK....KKDOODOODOODOOOODDDOOOK",
    "KDOK..KOODOODOODOODOOOOOOKKOOK",
    ".KODKKOOODOODOODOODOOOWWWWWWPK",
    "..KDODODOOOOOOOOOOOOOOOWWWWWK.",
    "...KODODOOOOOOOOOOOOOOOOOWOK..",
    "....KKOOOOWWWWWWWWWWOOKKKKK...",
    "......KKKOWWWWWWWWWWKK........",
    ".......KddOOKKWKKOOddK........",
    "......KddKOOK.K.KOOKddK.......",
    ".....KddKKOOK...KOOKKddK......",
    "....KWWK.KWWK...KWWK.KWWK.....",
    ".....KK...KK.....KK...KK......",
    "..............................",
    ".............................."
)

private val CAT_RUN2 = arrayOf(
    "..............................",
    ".....................KK..KK...",
    "....................KOOKKOOK..",
    "..............K.....KOPOOOPOK.",
    "K........KKKKKOKKKKKKOOODOOOK.",
    "DK.....KKDOODOODOODOOOODDDOOOK",
    "DDK...KOODOODOODOODOOOOOOKKOOK",
    "ODOKKKOOODOODOODOODOOOWWWWWWPK",
    "KKODOKODOOOOOOOOOOOOOOOWWWWWK.",
    "..KDODODOOOOOOOOOOOOOOOOOWOK..",
    "...KKDOOOOWWWWWWWWWWOOKKKKK...",
    ".....KKKKOWWWWWWWWWWKK........",
    "........KOOddKWKddOOK.........",
    ".......KOOKddKKddKKOOK........",
    "......KOOKKddKKddK.KOOK.......",
    ".....KWWK.KWWKKWWK..KWWK......",
    "......KK...KK..KK....KK.......",
    "..............................",
    "..............................",
    ".............................."
)

private val CAT_RUN3 = arrayOf(
    "..............................",
    "..............................",
    ".....................KK..KK...",
    "..K.................KOOKKOOK..",
    ".KDK..........K.....KOPOOOPOK.",
    "KODK.....KKKKKOKKKKKKOOODOOOK.",
    "KOK....KKDOODOODOODOOOODDDOOOK",
    "KDOK..KOODOODOODOODOOOOOOKKOOK",
    ".KODKKOOODOODOODOODOOOWWWWWWPK",
    "..KDODODOOOOOOOOOOOOOOOWWWWWK.",
    "...KODODOOOOOOOOOOOOOOOOOWOK..",
    "....KKOOOOWWWWWWWWWWOOKKKKK...",
    "......KKKOWWWWWWWWWWKK........",
    "........KddOOKWKOOddK.........",
    ".......KddKOOKKOOKKddK........",
    "......KddKKOOKKOOK.KddK.......",
    ".....KWWK.KWWKKWWK..KWWK......",
    "......KK...KK..KK....KK.......",
    "..............................",
    ".............................."
)

private val CAT_SLEEP = arrayOf(
    "..............................",
    "..............................",
    "..............................",
    "..............................",
    "..............................",
    "..............................",
    "..............................",
    "..............K.....KK..KK....",
    "........KKKKKKDKKKKKOOKKOOK...",
    "......KKDOODOODOODOOOPOKOPOK..",
    ".....KOODOODOODOODOOOOOOOOOK..",
    "....KOOODOODOODOODOOOODDDOOK..",
    "....KOOOOOOOOOOOOOOOOOOOOOOOK.",
    "...KOOOOOOOOOOOOOOOOOOOOKKOOK.",
    "...KOOOOOOOOOOOOOOOOOOWWWWWPK.",
    "...KOOOOOOOOOOOOOOOOOWWWWWWWK.",
    "....KODDOODDOODDOOOOOOWWWWWK..",
    ".....KDDOODDOODDOOOOOKKKKKK...",
    "......KKKKKKKKOKKKKKK.........",
    "..............K..............."
)

private val CatO = Color(0xFFE8914A)
private val CatD = Color(0xFF9A5A2B)
private val CatFar = Color(0xFFC97C3A)
private val CatW = Color(0xFFFFF3E0)
private val CatK = Color(0xFF3A2418)
private val CatP = Color(0xFFF2A6A0)
val YarnRed = Color(0xFFD9534F)
val YarnLight = Color(0xFFFFB8A8)

private fun catColor(c: Char): Color? = when (c) {
    'O' -> CatO
    'D' -> CatD
    'd' -> CatFar
    'W' -> CatW
    'K' -> CatK
    'P' -> CatP
    else -> null
}

/** Which running picture to show, from the wheel-spin angle that CarMotion keeps. */
fun catFrame(spin: Float): Int = ((spin / 40f).toInt() and 3)

/**
 * Draws the pixel cat. cx is the middle, ground is where the paws touch the yarn,
 * cell is the size of one pixel, angle follows the slope of the yarn under it.
 */
fun DrawScope.drawCat(cx: Float, ground: Float, cell: Float, angle: Float, frame: Int, level: Int, broken: Boolean, time: Float) {
    val rows = if (broken) CAT_SLEEP else when (frame and 3) { 0 -> CAT_RUN0; 1 -> CAT_RUN1; 2 -> CAT_RUN2; else -> CAT_RUN3 }
    val left = cx - CAT_W * cell / 2f
    val top = ground - (if (broken) 19f else 18f) * cell
    val by = if (!broken && (frame and 1) == 1) 1 else 0
    fun box(x: Float, y: Float, w: Float, h: Float, c: Color) {
        drawRect(c, Offset(left + x * cell, top + y * cell), Size(w * cell + 0.4f, h * cell + 0.4f))
    }
    withTransform({ rotate(angle, Offset(cx, ground)) }) {
        for (y in rows.indices) {
            val row = rows[y]
            var x = 0
            while (x < CAT_W) {
                val ch = row[x]
                val col = catColor(ch)
                if (col == null) { x++; continue }
                var x2 = x + 1
                while (x2 < CAT_W && row[x2] == ch) x2++
                box(x.toFloat(), y.toFloat(), (x2 - x).toFloat(), 1f, col)
                x = x2
            }
        }
        if (!broken) {
            // little extras that the cat earns the longer you stay under your limit
            if (level >= 1) {
                box(20f, 7f + by, 2f, 4f, Color(0xFFD84A4A))                       // collar
            }
            if (level >= 2) box(20f, 11f + by, 2f, 2f, Color(0xFFF4C455))          // bell
            if (level >= 3) {
                for (x in 13..19) {
                    val w = Math.round(sin(time * 9f + x * 0.9f)).toFloat()
                    box(x.toFloat(), 9f + by + w, 1f, 2f, Color(0xFF5AA9E6))       // scarf blowing back
                }
            }
            if (level >= 4) {
                val gold = Color(0xFFF4C455)
                box(23f, 0f + by, 5f, 2f, gold)                                    // crown
                box(23f, -1f + by, 1f, 1f, gold)
                box(25f, -2f + by, 1f, 2f, gold)
                box(27f, -1f + by, 1f, 1f, gold)
            }
        } else {
            // sleepy z z z drifting up
            for (i in 0..2) {
                val t = ((time * 0.5f + i / 3f) % 1f)
                val zx = 24f + i * 2.2f + t * 3f
                val zy = 7f - t * 7f
                val a = (1f - t) * 0.85f
                val c = CatW.copy(alpha = a)
                val z = 0.8f + i * 0.2f
                box(zx, zy, 3f * z, 0.9f * z, c)
                box(zx + 1f * z, zy + 0.9f * z, 1f * z, 0.9f * z, c)
                box(zx, zy + 1.8f * z, 3f * z, 0.9f * z, c)
            }
        }
    }
}

/** A twisted strand of yarn along a path. [scroll] slides the twist so the yarn looks like it keeps unrolling. */
fun DrawScope.drawYarn(path: Path, thick: Float, scroll: Float, xs: List<Float>, ys: List<Float>) {
    drawPath(path, YarnRed, style = Stroke(thick, cap = StrokeCap.Round))
    val step = thick * 2.1f
    val off = scroll % step
    for (i in xs.indices) {
        val x = xs[i] - off
        if (x < 0f) continue
        val y = ys[i]
        drawLine(YarnLight.copy(alpha = 0.85f), Offset(x - thick * 0.4f, y - thick * 0.35f), Offset(x + thick * 0.4f, y + thick * 0.35f), thick * 0.3f, StrokeCap.Round)
    }
}

/** A ball of yarn that rolls as the world moves. c is its middle, r its radius, turn is the roll in degrees. */
fun DrawScope.drawYarnBall(c: Offset, r: Float, turn: Float) {
    drawCircle(YarnRed, r, c)
    for (i in 0..3) {
        drawArc(
            YarnLight.copy(alpha = 0.85f), turn + i * 55f, 70f, false,
            Offset(c.x - r * 0.72f, c.y - r * 0.72f), Size(r * 1.44f, r * 1.44f), style = Stroke(r * 0.16f, cap = StrokeCap.Round)
        )
    }
    drawArc(Color(0x55000000), 20f, 140f, false, Offset(c.x - r * 0.95f, c.y - r * 0.95f), Size(r * 1.9f, r * 1.9f), style = Stroke(r * 0.18f))
    drawCircle(Color.White.copy(alpha = 0.35f), r * 0.16f, Offset(c.x - r * 0.4f, c.y - r * 0.45f))
}
