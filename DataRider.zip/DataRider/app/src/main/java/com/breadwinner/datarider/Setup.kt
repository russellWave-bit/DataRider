package com.breadwinner.datarider

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private fun open(c: Context, i: Intent) {
    try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

fun openUsageAccess(c: Context) = open(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:${c.packageName}")))
fun openOverlayAccess(c: Context) = open(c, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
fun openBattery(c: Context) = open(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}")))

/** First-launch setup: one tap per permission, each jumps to the right Settings page. */
@Composable
fun SetupScreen(onDone: () -> Unit) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(700); tick++ } }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    @Suppress("UNUSED_VARIABLE") val t = tick
    val usage = UsageRepo.hasAccess(ctx)
    val overlay = Perm.overlay(ctx)
    val notif = Perm.notif(ctx)
    val battery = Perm.battery(ctx)
    val loc = Perm.location(ctx)

    Column(
        Modifier.fillMaxSize().background(p.bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CarView(Modifier.fillMaxWidth().height(92.dp), 0, false, p.accent)
        T("Let's get you set up", 26, weight = FontWeight.ExtraBold)
        T("Android makes you switch each of these on by hand. One tap each, and I'll take you to the right page.", 14, p.muted, FontWeight.Medium)

        Step("Usage access", "Required. Lets the app read your data history.", usage, "Open") { openUsageAccess(ctx) }
        Step("Display over other apps", "Powers the floating Network Traffic panel.", overlay, "Open") { openOverlayAccess(ctx) }
        Step("Notifications", "Plays the 75% chime and the limit alerts.", notif, "Allow") {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        Step("No battery restriction", "Stops Samsung putting the tracker to sleep.", battery, "Open") { openBattery(ctx) }
        Step("Location", "Optional. Needed by Android to show Wi-Fi names, nearby networks and cell towers.", loc, "Allow") {
            locLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            if (usage) PillButton("Let's ride") { onDone() }
            else T("Turn on Usage access to continue", 13, p.muted)
        }
        T("On Samsung: also set Battery to Unrestricted for this app (Settings > Apps > Data Rider > Battery).", 12, p.muted, FontWeight.Medium)
    }
}

@Composable
private fun Step(title: String, why: String, done: Boolean, action: String, onClick: () -> Unit) {
    val p = LocalPal.current
    RCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 15)
                Spacer(Modifier.height(3.dp))
                T(why, 12, p.muted, FontWeight.Medium)
            }
            Spacer(Modifier.padding(6.dp))
            if (done) T("On", 13, p.accText) else PillButton(action) { onClick() }
        }
    }
}
