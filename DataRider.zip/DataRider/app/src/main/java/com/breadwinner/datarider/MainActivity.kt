package com.breadwinner.datarider

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Prefs.setupDone && UsageRepo.hasAccess(this)) startTracker(this)
        setContent { RiderTheme { RiderApp() } }
    }
}

fun startTracker(c: Context) {
    ContextCompat.startForegroundService(c, Intent(c, TrackerService::class.java))
}

@Composable
fun RiderApp() {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(Prefs.setupDone && UsageRepo.hasAccess(ctx)) }

    if (!ready) {
        SetupScreen {
            Prefs.setupDone = true
            Prefs.save()
            startTracker(ctx)
            ready = true
        }
    } else {
        var screen by remember { mutableStateOf(Screen.Home) }
        var open by remember { mutableStateOf(false) }
        val p = LocalPal.current
        val menuP by animateFloatAsState(if (open) 1f else 0f, tween(350), label = "menuP")
        val blurR by animateDpAsState(if (open) 10.dp else 0.dp, tween(300), label = "blur")

        BackHandler(open || screen != Screen.Home) {
            if (open) open = false else screen = Screen.Home
        }

        val nav = Nav(open = { open = true }, menuP = menuP, go = { screen = it; open = false })

        Box(Modifier.fillMaxSize().background(p.bg)) {
            Box(Modifier.fillMaxSize().blur(blurR)) {
                when (screen) {
                    Screen.Home -> HomeScreen(nav)
                    Screen.Usage -> UsageScreen(nav)
                    Screen.Apps -> AppsScreen(nav)
                    Screen.Limits -> LimitsScreen(nav)
                    Screen.Settings -> SettingsScreen(nav)
                    Screen.SpeedTest -> SpeedTestScreen(nav)
                    Screen.Overlay -> OverlayScreen(nav)
                    Screen.Devices -> DevicesScreen(nav)
                    Screen.ConnLog -> ConnLogScreen(nav)
                    Screen.Wifi -> WifiScreen(nav)
                    Screen.Towers -> TowersScreen(nav)
                    Screen.Connections -> ConnectionsScreen(nav)
                    Screen.Ping -> PingScreen(nav)
                }
            }
            Drawer(open, screen, { screen = it; open = false }, { open = false })
        }
    }
}

@Composable
fun Drawer(open: Boolean, current: Screen, onPick: (Screen) -> Unit, onClose: () -> Unit) {
    val p = LocalPal.current
    // springy slide-out: overshoots, then settles
    val x by animateDpAsState(if (open) 0.dp else (-340).dp, spring(dampingRatio = 0.5f, stiffness = 220f), label = "drawerX")
    val scrim by animateFloatAsState(if (open) 0.6f else 0f, tween(250), label = "scrim")
    val prog by animateFloatAsState(if (open) 1f else 0f, tween(350), label = "arrow")
    val zip = remember { Animatable(0f) }
    LaunchedEffect(open) {
        if (open) {
            zip.snapTo(0f)
            zip.animateTo(1f, tween(1000, 150, LinearEasing))
        }
    }
    val d = LocalDensity.current.density

    if (scrim > 0.01f || open) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = scrim))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
        )
    }

    val entries: List<Any> = listOf(
        Screen.Home, Screen.Usage, Screen.Apps, Screen.Limits, Screen.SpeedTest,
        "TOOLS",
        Screen.Overlay, Screen.Devices, Screen.ConnLog, Screen.Wifi, Screen.Towers, Screen.Connections, Screen.Ping,
        "",
        Screen.Settings
    )

    Column(
        Modifier.offset(x = x - 40.dp).width(340.dp).fillMaxHeight()
            .clip(WaveEdgeShape()).background(p.card).padding(start = 40.dp)
            .statusBarsPadding().navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            MenuButton(prog, p.track, p.text, onClose)
            Spacer(Modifier.width(12.dp))
            T("Data Rider", 20, weight = FontWeight.ExtraBold)
        }
        // the little car zips across once as the drawer opens, then leaves the screen completely
        Canvas(Modifier.fillMaxWidth().height(56.dp).clipToBounds()) {
            if (open && zip.value < 1f) {
                val cx = zip.value * (size.width / d + 90f) - 45f
                val bounce = sin(zip.value * 60f) * 1.2f
                withTransform({ scale(d, d, Offset.Zero) }) {
                    drawCarFull(cx, 50f, 50f, 0.8f, 0f, bounce, zip.value * 3000f, 0.6f, Live.level, false, zip.value * 5f, 0f)
                }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            var idx = 0
            entries.forEach { e ->
                if (e is Screen) {
                    DrawerItem(e.title, e == current, open, idx) { onPick(e) }
                    idx++
                } else if (e is String && e.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    T(e, 11, p.muted, modifier = Modifier.padding(start = 12.dp, bottom = 4.dp))
                } else {
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

/** Menu entries pop in one after another. */
@Composable
private fun DrawerItem(label: String, selected: Boolean, open: Boolean, index: Int, onClick: () -> Unit) {
    val p = LocalPal.current
    val a by animateFloatAsState(
        if (open) 1f else 0f,
        tween(300, delayMillis = if (open) 150 + index * 45 else 0),
        label = "item$index"
    )
    Box(
        Modifier.fillMaxWidth().graphicsLayer {
            alpha = a
            translationX = (1f - a) * -40f * density
            scaleX = 0.9f + 0.1f * a
            scaleY = 0.9f + 0.1f * a
        }
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) p.accent.copy(alpha = 0.18f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        T(label, 15, if (selected) p.accText else p.text)
    }
}
