package com.breadwinner.datarider

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Prefs.setupDone && UsageRepo.hasAccess(this)) startTracker(this)
        setContent { RiderTheme { RiderApp() } }
    }
}

fun startTracker(c: Context) {
    ContextCompat.startForegroundService(c, Intent(c, TrackerService::class.java))
}

@Composable
fun RiderApp() {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(Prefs.setupDone && UsageRepo.hasAccess(ctx)) }

    if (!ready) {
        SetupScreen {
            Prefs.setupDone = true
            Prefs.save()
            startTracker(ctx)
            ready = true
        }
    } else {
        var screen by remember { mutableStateOf(Screen.Home) }
        val p = LocalPal.current
        val main = screen == Screen.Home || screen == Screen.Usage || screen == Screen.Apps ||
            screen == Screen.Limits || screen == Screen.More

        BackHandler(screen != Screen.Home) {
            screen = when (screen) {
                Screen.Usage, Screen.Apps, Screen.Limits, Screen.More -> Screen.Home
                else -> Screen.More
            }
        }

        val nav = Nav(sub = !main, go = { screen = it })

        Column(Modifier.fillMaxSize().background(p.bg)) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    Screen.Home -> HomeScreen(nav)
                    Screen.Usage -> UsageScreen(nav)
                    Screen.Apps -> AppsScreen(nav)
                    Screen.Limits -> LimitsScreen(nav)
                    Screen.More -> MoreScreen(nav)
                    Screen.Garage -> GarageScreen(nav)
                    Screen.Settings -> SettingsScreen(nav)
                    Screen.SpeedTest -> SpeedTestScreen(nav)
                    Screen.Overlay -> OverlayScreen(nav)
                    Screen.Devices -> DevicesScreen(nav)
                    Screen.ConnLog -> ConnLogScreen(nav)
                    Screen.Wifi -> WifiScreen(nav)
                    Screen.Towers -> TowersScreen(nav)
                    Screen.Connections -> ConnectionsScreen(nav)
                    Screen.Ping -> PingScreen(nav)
                }
            }
            BottomBar(if (main) screen else Screen.More) { screen = it }
        }
    }
}

private val TABS = listOf(Screen.Home, Screen.Usage, Screen.Apps, Screen.Limits, Screen.More)

/** Flat bottom bar with five tabs. The picked tab's icon pops with a spring. */
@Composable
fun BottomBar(current: Screen, onPick: (Screen) -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().background(p.card).navigationBarsPadding().height(64.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TABS.forEach { s ->
            val sel = s == current
            val sc by animateFloatAsState(if (sel) 1.18f else 1f, spring(dampingRatio = 0.35f, stiffness = 420f), label = "tab")
            Column(
                Modifier.weight(1f).fillMaxHeight()
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onPick(s) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.graphicsLayer { scaleX = sc; scaleY = sc }
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (sel) p.accent.copy(alpha = 0.18f) else Color.Transparent)
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    TabIcon(s, if (sel) p.accText else p.muted)
                }
                T(s.title.substringBefore(' '), 11, if (sel) p.accText else p.muted)
            }
        }
    }
}

@Composable
private fun TabIcon(s: Screen, c: Color) {
    Canvas(Modifier.size(22.dp)) {
        val u = size.width / 22f
        val st = Stroke(2.2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (s) {
            Screen.Home -> {
                val h = Path().apply {
                    moveTo(3f * u, 11f * u); lineTo(11f * u, 4f * u); lineTo(19f * u, 11f * u)
                    moveTo(5.5f * u, 10f * u); lineTo(5.5f * u, 18.5f * u); lineTo(16.5f * u, 18.5f * u); lineTo(16.5f * u, 10f * u)
                }
                drawPath(h, c, style = st)
            }
            Screen.Usage -> {
                drawLine(c, Offset(5f * u, 18f * u), Offset(5f * u, 12f * u), 3.2f * u, StrokeCap.Round)
                drawLine(c, Offset(11f * u, 18f * u), Offset(11f * u, 5f * u), 3.2f * u, StrokeCap.Round)
                drawLine(c, Offset(17f * u, 18f * u), Offset(17f * u, 9f * u), 3.2f * u, StrokeCap.Round)
            }
            Screen.Apps -> {
                for (i in 0..1) for (j in 0..1) {
                    drawRoundRect(c, Offset((3.5f + i * 8f) * u, (3.5f + j * 8f) * u), Size(6.5f * u, 6.5f * u), CornerRadius(2f * u))
                }
            }
            Screen.Limits -> {
                drawArc(c, 150f, 240f, false, Offset(3f * u, 4f * u), Size(16f * u, 16f * u), style = st)
                drawLine(c, Offset(11f * u, 12f * u), Offset(15f * u, 8f * u), 2.2f * u, StrokeCap.Round)
            }
            else -> {
                for (i in 0..2) drawCircle(c, 2f * u, Offset((4.5f + i * 6.5f) * u, 11f * u))
            }
        }
    }
}
