package com.breadwinner.datarider

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Calendar
import java.util.Locale

fun f0(x: Double): String = String.format(Locale.US, "%.0f", x)
fun f1(x: Double): String = String.format(Locale.US, "%.1f", x)
fun f2(x: Double): String = String.format(Locale.US, "%.2f", x)

/** Splits a byte count into a number and a unit, e.g. 2_400_000_000 -> ("2.40", "GB"). */
fun bytesParts(b: Long): Pair<String, String> {
    val d = b.toDouble()
    return when {
        d >= 1e10 -> f1(d / 1e9) to "GB"
        d >= 1e9 -> f2(d / 1e9) to "GB"
        d >= 1e6 -> f0(d / 1e6) to "MB"
        d >= 1e3 -> f0(d / 1e3) to "KB"
        else -> "$b" to "B"
    }
}

fun fmtBytes(b: Long): String {
    val (v, u) = bytesParts(b)
    return "$v $u"
}

/** Bytes per second -> KB/s or MB/s, switching automatically. */
fun speedParts(bps: Double): Pair<String, String> =
    if (bps >= 1e6) f1(bps / 1e6) to "MB/s" else f0(bps / 1e3) to "KB/s"

fun speedStr(bps: Double): String {
    val (v, u) = speedParts(bps)
    return "$v $u"
}

fun dayStart(ms: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun addDays(ms: Long, n: Int): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.add(Calendar.DAY_OF_YEAR, n)
    return c.timeInMillis
}

/** Start of the current billing cycle, given the day of month the bundle renews. */
fun cycleStart(day: Int, now: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = dayStart(now)
    val d = day.coerceIn(1, 28)
    if (c.get(Calendar.DAY_OF_MONTH) < d) c.add(Calendar.MONTH, -1)
    c.set(Calendar.DAY_OF_MONTH, d)
    return c.timeInMillis
}

/** Time a TCP connection takes, in ms. Returns -1 when it fails. */
fun tcpPing(host: String, port: Int = 443, timeout: Int = 2000): Int =
    try {
        val s = Socket()
        val t0 = System.nanoTime()
        s.connect(InetSocketAddress(host, port), timeout)
        val ms = ((System.nanoTime() - t0) / 1_000_000).toInt()
        s.close()
        ms
    } catch (e: Exception) {
        -1
    }

object Perm {
    fun overlay(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun notif(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun battery(c: Context): Boolean {
        val pm = c.getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    fun location(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
}
