package com.breadwinner.datarider

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Live numbers shared between the background tracker, the overlay and the screens. */
object Live {
    var down by mutableStateOf(0.0)   // bytes per second
    var up by mutableStateOf(0.0)
    var today by mutableStateOf(0L)
    val history = mutableStateListOf<Pair<Float, Float>>()

    fun push(d: Double, u: Double) {
        down = d
        up = u
        history.add(d.toFloat() to u.toFloat())
        if (history.size > 60) history.removeAt(0)
    }
}
