package com.breadwinner.datarider

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Live numbers shared between the background tracker, the overlay and the screens. */
object Live {
    var down by mutableStateOf(0.0)   // bytes per second
    var up by mutableStateOf(0.0)
    var today by mutableStateOf(0L)
    val history = mutableStateListOf<Pair<Float, Float>>()
    val stamps = ArrayList<Long>()    // when each history point was taken (ms)

    var streak by mutableStateOf(0)   // days in a row under the limit
    var score by mutableStateOf(0)    // days under the limit in the last 30

    // the pinned data plan, shown in the notification
    var planName by mutableStateOf("")
    var planUsed by mutableStateOf(0L)
    var planTotal by mutableStateOf(0L)

    /** Car upgrade level, 0 to 4, from how many of the last 30 days you stayed under your limit. */
    val level: Int
        get() = when {
            score >= 27 -> 4
            score >= 18 -> 3
            score >= 10 -> 2
            score >= 5 -> 1
            else -> 0
        }

    /** True when today's usage is past the daily limit. The car breaks down. */
    val broken: Boolean
        get() = Prefs.dailyLimitMb > 0f && today > Prefs.dailyLimitMb * 1_000_000.0

    fun push(d: Double, u: Double) {
        down = d
        up = u
        history.add(d.toFloat() to u.toFloat())
        stamps.add(System.currentTimeMillis())
        if (history.size > 60) {
            history.removeAt(0)
            stamps.removeAt(0)
        }
    }
}
