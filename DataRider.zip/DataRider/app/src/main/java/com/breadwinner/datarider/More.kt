package com.breadwinner.datarider

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
private fun Shelf(title: String, items: List<Pair<String, Screen>>, nav: Nav) {
    val p = LocalPal.current
    T(title.uppercase(), 11, p.muted, modifier = Modifier.padding(start = 4.dp))
    RCard(Modifier.fillMaxWidth(), pad = 6.dp) {
        items.forEachIndexed { i, (label, s) ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { nav.go(s) }
                    .padding(horizontal = 10.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(p.accent))
                Spacer(Modifier.size(14.dp))
                T(label, 15, modifier = Modifier.weight(1f))
                T(">", 14, p.muted)
            }
        }
    }
}

@Composable
fun MoreScreen(nav: Nav) {
    Page("More", nav) {
        Shelf("Measure", listOf("Speed Test" to Screen.SpeedTest, "Ping Test" to Screen.Ping, "Connection Log" to Screen.ConnLog), nav)
        Shelf("Watch", listOf("Network Traffic (floating)" to Screen.Overlay, "Network Connections" to Screen.Connections), nav)
        Shelf("Find", listOf("Device Discovery" to Screen.Devices, "Wi-Fi Analyzer" to Screen.Wifi, "Cell Towers" to Screen.Towers), nav)
        Shelf("You", listOf("My Car" to Screen.Garage, "Settings" to Screen.Settings), nav)
    }
}

@Composable
fun GarageScreen(nav: Nav) {
    val p = LocalPal.current
    Page("My Car", nav) {
        RCard(Modifier.fillMaxWidth()) {
            CarView(Modifier.fillMaxWidth().height(110.dp), Live.level, false, p.accent)
            T("Level: ${LEVEL_NAMES[Live.level]}", 13, p.accText)
            T("Stay under your limit on more days to upgrade it.", 12, p.muted, FontWeight.Medium)
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Rider", 15)
            Spacer(Modifier.height(10.dp))
            Seg(listOf("Car", "Cat"), Prefs.rider) { Prefs.rider = it; Prefs.save() }
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Model", 15)
            Spacer(Modifier.height(10.dp))
            Seg(CAR_MODEL_NAMES, Prefs.carModel) { Prefs.carModel = it; Prefs.save() }
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Paint", 15)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CAR_PAINTS.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(c)
                            .clickable { Prefs.carPaint = i; Prefs.save() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (i == Prefs.carPaint) Box(Modifier.size(12.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color.White))
                    }
                }
            }
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Upgrades", 15)
            Spacer(Modifier.height(8.dp))
            LEVEL_NAMES.forEachIndexed { i, n ->
                T((if (i <= Live.level) "✓  " else "○  ") + n + "  ·  ${LEVEL_AT[i]} days under limit", 13,
                    if (i <= Live.level) p.accText else p.muted)
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}
