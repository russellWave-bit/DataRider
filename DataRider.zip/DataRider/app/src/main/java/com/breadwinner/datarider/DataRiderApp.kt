package com.breadwinner.datarider

import android.app.Application

class DataRiderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Store.init(this)
        Alerts.channels(this)
    }
}
