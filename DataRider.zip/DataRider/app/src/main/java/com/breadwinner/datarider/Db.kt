package com.breadwinner.datarider

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.TreeMap

data class HourPing(val hour: Long, val avgMs: Int, val drops: Int, val total: Int)
data class SpeedRow(val ts: Long, val down: Double, val up: Double, val ping: Int)

object Store {
    lateinit var db: Db
    fun init(c: Context) {
        db = Db(c.applicationContext)
    }
}

/** The app's own history. Android forgets old usage; this does not. */
class Db(c: Context) : SQLiteOpenHelper(c, "rider.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE minute(ts INTEGER PRIMARY KEY, mrx INTEGER, mtx INTEGER, wrx INTEGER, wtx INTEGER, offm INTEGER, offw INTEGER)")
        d.execSQL("CREATE TABLE ping(ts INTEGER PRIMARY KEY, ms INTEGER)")
        d.execSQL("CREATE TABLE speed(ts INTEGER PRIMARY KEY, down REAL, up REAL, ping INTEGER)")
        d.execSQL("CREATE TABLE wifinet(day INTEGER, ssid TEXT, bytes INTEGER, PRIMARY KEY(day, ssid))")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized
    fun addMinute(ts: Long, mrx: Long, mtx: Long, wrx: Long, wtx: Long, offm: Long, offw: Long) {
        val d = writableDatabase
        d.execSQL("INSERT OR IGNORE INTO minute VALUES(?,0,0,0,0,0,0)", arrayOf<Any?>(ts))
        d.execSQL(
            "UPDATE minute SET mrx=mrx+?, mtx=mtx+?, wrx=wrx+?, wtx=wtx+?, offm=offm+?, offw=offw+? WHERE ts=?",
            arrayOf<Any?>(mrx, mtx, wrx, wtx, offm, offw, ts)
        )
    }

    /** Returns [mobile, wifi, screen-off mobile, screen-off wifi] in bytes. */
    @Synchronized
    fun sums(from: Long, to: Long): LongArray {
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(mrx+mtx),0), COALESCE(SUM(wrx+wtx),0), COALESCE(SUM(offm),0), COALESCE(SUM(offw),0) FROM minute WHERE ts>=? AND ts<?",
            arrayOf(from.toString(), to.toString())
        ).use { c ->
            c.moveToFirst()
            return longArrayOf(c.getLong(0), c.getLong(1), c.getLong(2), c.getLong(3))
        }
    }

    @Synchronized
    fun addPing(ts: Long, ms: Int) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO ping VALUES(?,?)", arrayOf<Any?>(ts, ms))
    }

    @Synchronized
    fun hourlyPings(since: Long): List<HourPing> {
        val map = TreeMap<Long, MutableList<Int>>()
        readableDatabase.rawQuery("SELECT ts, ms FROM ping WHERE ts>=? ORDER BY ts", arrayOf(since.toString())).use { c ->
            while (c.moveToNext()) {
                val h = c.getLong(0) / 3_600_000L * 3_600_000L
                map.getOrPut(h) { mutableListOf() }.add(c.getInt(1))
            }
        }
        return map.map { (h, l) ->
            val ok = l.filter { it >= 0 }
            HourPing(h, if (ok.isEmpty()) 0 else ok.average().toInt(), l.size - ok.size, l.size)
        }.reversed()
    }

    @Synchronized
    fun addSpeed(ts: Long, down: Double, up: Double, ping: Int) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO speed VALUES(?,?,?,?)", arrayOf<Any?>(ts, down, up, ping))
    }

    @Synchronized
    fun recentSpeeds(n: Int): List<SpeedRow> {
        val out = mutableListOf<SpeedRow>()
        readableDatabase.rawQuery("SELECT ts, down, up, ping FROM speed ORDER BY ts DESC LIMIT ?", arrayOf(n.toString())).use { c ->
            while (c.moveToNext()) out.add(SpeedRow(c.getLong(0), c.getDouble(1), c.getDouble(2), c.getInt(3)))
        }
        return out
    }

    @Synchronized
    fun addWifi(day: Long, ssid: String, bytes: Long) {
        val d = writableDatabase
        d.execSQL("INSERT OR IGNORE INTO wifinet VALUES(?,?,0)", arrayOf<Any?>(day, ssid))
        d.execSQL("UPDATE wifinet SET bytes=bytes+? WHERE day=? AND ssid=?", arrayOf<Any?>(bytes, day, ssid))
    }

    @Synchronized
    fun wifiByNet(fromDay: Long): List<Pair<String, Long>> {
        val out = mutableListOf<Pair<String, Long>>()
        readableDatabase.rawQuery(
            "SELECT ssid, SUM(bytes) FROM wifinet WHERE day>=? GROUP BY ssid ORDER BY 2 DESC",
            arrayOf(fromDay.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(c.getString(0) to c.getLong(1))
        }
        return out
    }
}
