package com.breadwinner.datarider

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Orange = Color(0xFFF2A33A)   // amber: warnings
val Red = Color(0xFFF0605A)      // coral: the limit

// card shapes: two playful "leaf" shapes and a plain one
val ShapeA = RoundedCornerShape(topStart = 22.dp, topEnd = 8.dp, bottomEnd = 22.dp, bottomStart = 8.dp)
val ShapeB = RoundedCornerShape(topStart = 8.dp, topEnd = 22.dp, bottomEnd = 8.dp, bottomStart = 22.dp)
val ShapeN = RoundedCornerShape(12.dp)

@Immutable
data class Pal(
    val bg: Color, val card: Color, val text: Color, val muted: Color,
    val accent: Color, val accText: Color, val onAccent: Color, val track: Color, val dark: Boolean
)

val LocalPal = staticCompositionLocalOf<Pal> { error("no palette") }

enum class Screen(val title: String) {
    Home("Home"), Usage("Usage"), Apps("Apps"), Limits("Limits & plans"), SpeedTest("Speed test"),
    Overlay("Network Traffic"), Devices("Device Discovery"), ConnLog("Connection Log"),
    Wifi("Wi-Fi Analyzer"), Towers("Cell Towers"), Connections("Network Connections"),
    Ping("Ping Test"), Settings("Settings")
}

class Nav(val open: () -> Unit, val menuP: Float, val go: (Screen) -> Unit)

@Composable
fun RiderTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val dark = when (Prefs.theme) { 1 -> true; 2 -> false; else -> sys }
    val acc = Color.hsv(Prefs.hue, 0.72f, Prefs.brightness).copy(alpha = Prefs.opacity)
    val solid = acc.copy(alpha = 1f)
    val onAcc = if (solid.luminance() > 0.4f) Color(0xFF14110F) else Color.White
    val pal = if (dark) {
        Pal(Color(0xFF1A1816), Color(0xFF24211E), Color(0xFFF4EFE7), Color(0xFFA59D91), acc, acc, onAcc, Color(0xFF322E2A), true)
    } else {
        Pal(Color(0xFFF6F1E8), Color.White, Color(0xFF1F1B17), Color(0xFF6F675B), acc,
            Color.hsv(Prefs.hue, 0.85f, (Prefs.brightness * 0.6f).coerceAtLeast(0.3f)), onAcc, Color(0xFFEAE3D7), false)
    }
    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = acc) else lightColorScheme(primary = acc), content = content)
    }
}

@Composable
fun T(
    text: String, size: Int = 13, color: Color = LocalPal.current.text,
    weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier)
}

@Composable
fun RCard(
    modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, pad: Dp = 14.dp, shape: Shape = ShapeN,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPal.current
    if (onClick == null) {
        Column(modifier.clip(shape).background(p.card).padding(pad), content = content)
    } else {
        // a little bounce when you tap a card
        val src = remember { MutableInteractionSource() }
        val pressed by src.collectIsPressedAsState()
        val sc by animateFloatAsState(
            if (pressed) 0.95f else 1f, spring(dampingRatio = 0.4f, stiffness = 500f), label = "bounce"
        )
        Column(
            modifier.graphicsLayer { scaleX = sc; scaleY = sc }
                .clip(shape).background(p.card)
                .clickable(interactionSource = src, indication = null) { onClick() }
                .padding(pad),
            content = content
        )
    }
}

/** A number that counts up to its value, so it feels alive when a screen opens. */
@Composable
fun rememberCount(target: Long): Long {
    val a = remember { Animatable(0f) }
    LaunchedEffect(target) { a.animateTo(target.toFloat(), tween(900)) }
    return a.value.toLong()
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.card).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (i == sel) p.accent else Color.Transparent)
                    .clickable { onSel(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 13, if (i == sel) p.onAccent else p.muted) }
        }
    }
}

@Composable
fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                    .background(if (i == sel) p.accent else p.card)
                    .clickable { onSel(i) }.padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) { T(s, 12, if (i == sel) p.onAccent else p.muted) }
        }
    }
}

@Composable
fun UseRow(label: String, value: String, frac: Float) {
    val p = LocalPal.current
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T(label, 13)
            T(value, 13, p.muted)
        }
        Spacer(Modifier.height(5.dp))
        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(p.track)) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().background(p.accent))
        }
    }
}

@Composable
fun PillButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (filled) p.accent else p.track)
            .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, if (filled) p.onAccent else p.text) }
}

/** Three dots that morph into a "<" when [progress] goes 0 -> 1. */
@Composable
fun MenuButton(progress: Float, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(bg)
            .semantics { contentDescription = "Menu" }.clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val u = size.width / 24f
            val vert = listOf(Offset(0f, -7f), Offset(0f, 0f), Offset(0f, 7f))
            val chev = listOf(Offset(3f, -6f), Offset(-3f, 0f), Offset(3f, 6f))
            for (i in 0..2) {
                val o = vert[i] + (chev[i] - vert[i]) * progress
                drawCircle(fg, 2f * u, Offset(center.x + o.x * u, center.y + o.y * u))
            }
        }
    }
}

@Composable
fun Page(title: String, nav: Nav, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxSize().background(p.bg).statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MenuButton(nav.menuP, p.card, p.text, nav.open)
            T(title, 22, weight = FontWeight.ExtraBold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

fun pick(m: Long, w: Long, src: Int): Long = when (src) { 0 -> m + w; 1 -> w; else -> m }
