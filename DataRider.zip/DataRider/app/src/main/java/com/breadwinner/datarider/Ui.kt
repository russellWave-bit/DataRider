package com.breadwinner.datarider

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.PI
import kotlin.math.sin
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Orange = Color(0xFFF2A33A)   // amber: warnings
val Red = Color(0xFFF0605A)      // coral: the limit

/** Which look is showing right now, so the warm colours can follow dark and light. */
object Look {
    var dark by mutableStateOf(true)
}

// light, flat hero band: pale mint sky and soft green hills
val SeaTop: Color get() = if (Look.dark) Color(0xFF1F3B2E) else Color(0xFFD3EFDD)
val SeaMid: Color get() = if (Look.dark) Color(0xFF244634) else Color(0xFFD3EFDD)
val SeaDeep: Color get() = if (Look.dark) Color(0xFF2A503B) else Color(0xFFE4F5EA)
val Wave1: Color get() = if (Look.dark) Color(0xFF2F5A43) else Color(0xFFB4E1C5)
val Wave2: Color get() = if (Look.dark) Color(0xFF3A6C52) else Color(0xFF8DD0A8)
val Wave3: Color get() = if (Look.dark) Color(0xFF47805F) else Color(0xFF5DBB84)
val HeadInk: Color get() = if (Look.dark) Color(0xFFE6F5EA) else Color(0xFF17402A)
val CrestLine: Color get() = if (Look.dark) Color(0xFF7FD3A0) else Color(0xFF2FA866)
val SunHalo = Color(0x66FFE29A)
val SunCore = Color(0xFFFFD36B)
val MenuBtnBg: Color get() = Color.White.copy(alpha = if (Look.dark) 0.12f else 0.6f)

// flat cards: one calm rounded shape everywhere
val ShapeA: Shape = RoundedCornerShape(18.dp)
val ShapeB: Shape = RoundedCornerShape(18.dp)
val ShapeN: Shape = RoundedCornerShape(18.dp)

/** Wave clock. It runs faster when your live data speed goes up. */
@Composable
fun rememberWaveTime(): State<Float> {
    val t = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) {
                    val dt = ((n - last) / 1e9f).coerceAtMost(0.05f)
                    t.value += dt * (0.6f + 2.4f * intensityOf(Live.down + Live.up))
                }
                last = n
            }
        }
    }
    return t
}

/** Flat mint band with two soft hills. The front hill is the [ground] colour, so the band melts into the page. */
@Composable
fun WaveBand(modifier: Modifier, ground: Color, amp: Float = 5f) {
    val t = rememberWaveTime()
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dd = density
        drawRect(Brush.verticalGradient(listOf(SeaTop, SeaDeep)))
        val cols = listOf(Wave1, ground)
        for (i in 0..1) {
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                val y = h * (0.62f + 0.2f * i) +
                    amp * dd * (0.8f + 0.3f * i) * sin(x / w * (1.2f + 0.5f * i) * 6.283f + t.value * 0.5f + i * 2f)
                path.lineTo(x, y)
                x += 6f * dd
            }
            path.lineTo(w, h)
            path.close()
            drawPath(path, cols[i])
        }
    }
}

@Immutable
data class Pal(
    val bg: Color, val card: Color, val text: Color, val muted: Color,
    val accent: Color, val accText: Color, val onAccent: Color, val track: Color, val dark: Boolean
)

val LocalPal = staticCompositionLocalOf<Pal> { error("no palette") }

enum class Screen(val title: String) {
    Home("Home"), Usage("Usage"), Apps("Apps"), Limits("Limits & plans"), SpeedTest("Speed test"),
    Overlay("Network Traffic"), Devices("Device Discovery"), ConnLog("Connection Log"),
    Wifi("Wi-Fi Analyzer"), Towers("Cell Towers"), Connections("Network Connections"),
    Ping("Ping Test"), Settings("Settings"), More("More"), Garage("My Car")
}

class Nav(val sub: Boolean, val go: (Screen) -> Unit)

@Composable
fun RiderTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val dark = when (Prefs.theme) { 1 -> true; 2 -> false; else -> sys }
    val acc = Color.hsv(Prefs.hue, 0.72f, Prefs.brightness).copy(alpha = Prefs.opacity)
    val solid = acc.copy(alpha = 1f)
    val onAcc = if (solid.luminance() > 0.4f) Color(0xFF14110F) else Color.White
    Look.dark = dark
    val pal = if (dark) {
        Pal(Color(0xFF141C17), Color(0xFF1E2923), Color(0xFFE9F3EC), Color(0xFF93A69B), acc, acc, onAcc, Color(0xFF2B3A32), true)
    } else {
        Pal(Color(0xFFEFEBE3), Color(0xFFFFFFFF), Color(0xFF1E2A23), Color(0xFF79867E), acc,
            Color.hsv(Prefs.hue, 0.85f, (Prefs.brightness * 0.75f).coerceAtLeast(0.3f)), onAcc, Color(0xFFECE7DC), false)
    }
    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = acc) else lightColorScheme(primary = acc), content = content)
    }
}

@Composable
fun T(
    text: String, size: Int = 13, color: Color = LocalPal.current.text,
    weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier)
}

@Composable
fun RCard(
    modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, pad: Dp = 14.dp, shape: Shape = ShapeN,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPal.current
    if (onClick == null) {
        Column(modifier.clip(shape).background(p.card).padding(pad), content = content)
    } else {
        // a little bounce when you tap a card
        val src = remember { MutableInteractionSource() }
        val pressed by src.collectIsPressedAsState()
        val sc by animateFloatAsState(
            if (pressed) 0.95f else 1f, spring(dampingRatio = 0.4f, stiffness = 500f), label = "bounce"
        )
        Column(
            modifier.graphicsLayer { scaleX = sc; scaleY = sc }
                .clip(shape).background(p.card)
                .clickable(interactionSource = src, indication = null) { onClick() }
                .padding(pad),
            content = content
        )
    }
}

/** A number that counts up to its value, so it feels alive when a screen opens. */
@Composable
fun rememberCount(target: Long): Long {
    val a = remember { Animatable(0f) }
    LaunchedEffect(target) { a.animateTo(target.toFloat(), tween(900)) }
    return a.value.toLong()
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.track).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (i == sel) p.accent else Color.Transparent)
                    .clickable { onSel(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 13, if (i == sel) p.onAccent else p.muted) }
        }
    }
}

@Composable
fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                    .background(if (i == sel) p.accent else p.card)
                    .clickable { onSel(i) }.padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) { T(s, 12, if (i == sel) p.onAccent else p.muted) }
        }
    }
}

@Composable
fun UseRow(label: String, value: String, frac: Float) {
    val p = LocalPal.current
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T(label, 13)
            T(value, 13, p.muted)
        }
        Spacer(Modifier.height(5.dp))
        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(p.track)) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().background(p.accent))
        }
    }
}

@Composable
fun PillButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (filled) p.accent else p.track)
            .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, if (filled) p.onAccent else p.text) }
}

/** Three dots that morph into a "<" when [progress] goes 0 -> 1. */
@Composable
fun MenuButton(progress: Float, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(bg)
            .semantics { contentDescription = "Menu" }.clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val u = size.width / 24f
            val vert = listOf(Offset(0f, -7f), Offset(0f, 0f), Offset(0f, 7f))
            val chev = listOf(Offset(3f, -6f), Offset(-3f, 0f), Offset(3f, 6f))
            for (i in 0..2) {
                val o = vert[i] + (chev[i] - vert[i]) * progress
                drawCircle(fg, 2f * u, Offset(center.x + o.x * u, center.y + o.y * u))
            }
        }
    }
}

/** Round back arrow, drawn, so no icon library is needed. */
@Composable
fun BackButton(onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(p.card)
            .semantics { contentDescription = "Back" }.clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            val u = size.width / 20f
            val st = androidx.compose.ui.graphics.drawscope.Stroke(2.4f * u, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            val ch = Path().apply { moveTo(12f * u, 4f * u); lineTo(6f * u, 10f * u); lineTo(12f * u, 16f * u) }
            drawPath(ch, p.text, style = st)
        }
    }
}

@Composable
fun Page(title: String, nav: Nav, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxSize().background(p.bg)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (nav.sub) BackButton { nav.go(Screen.More) }
            T(title, 26, p.text, FontWeight.ExtraBold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

fun pick(m: Long, w: Long, src: Int): Long = when (src) { 0 -> m + w; 1 -> w; else -> m }
