package com.breadwinner.datarider

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Runs in the background. Every 2 seconds it measures speed, every 30 seconds it saves
 * history and checks your limit, every minute it logs latency. Also drives the live-speed notification.
 */
class TrackerService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        Alerts.channels(this)
        startForeground(1, notif("Data Rider", "Watching your data"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    private fun notif(title: String, text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, Alerts.CH_LIVE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    /** Live speed on top, today's use (or the pinned data plan) underneath, with a progress bar for the limit. */
    private fun liveNotif(down: Double, up: Double): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val hasPlan = Live.planTotal > 0
        val used = if (hasPlan) Live.planUsed else Live.today
        val total = if (hasPlan) Live.planTotal else (Prefs.dailyLimitMb * 1_000_000.0).toLong()
        val label = if (hasPlan) Live.planName else "Today"
        val pct = if (total > 0) (used.toDouble() / total).coerceIn(0.0, 1.0) else 0.0
        val col = when {
            pct >= 0.9 -> 0xFFF0605A.toInt()
            pct >= 0.75 -> 0xFFF2A33A.toInt()
            else -> Color.HSVToColor(floatArrayOf(Prefs.hue, 0.72f, Prefs.brightness))
        }
        return Notification.Builder(this, Alerts.CH_LIVE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("↓ " + speedStr(down) + "   ↑ " + speedStr(up))
            .setContentText(label + " " + fmtBytes(used) + " of " + fmtBytes(total) + "  ·  " + (pct * 100).toInt() + "%")
            .setProgress(1000, (pct * 1000).toInt(), false)
            .setColor(col)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(pi)
            .build()
    }

    private fun delta(now: Long, before: Long): Long = if (now < 0 || before < 0 || now < before) 0L else now - before

    @Suppress("DEPRECATION")
    private fun currentSsid(wm: WifiManager): String? {
        val s = wm.connectionInfo?.ssid?.trim('"') ?: return null
        return if (s.isBlank() || s.startsWith("<unknown")) null else s
    }

    private suspend fun loop() {
        val repo = UsageRepo(this)
        val pm = getSystemService(PowerManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        val cm = getSystemService(ConnectivityManager::class.java)
        val wm = applicationContext.getSystemService(WifiManager::class.java)

        var lastT = SystemClock.elapsedRealtime()
        var pMrx = TrafficStats.getMobileRxBytes()
        var pMtx = TrafficStats.getMobileTxBytes()
        var pTrx = TrafficStats.getTotalRxBytes()
        var pTtx = TrafficStats.getTotalTxBytes()

        var aMrx = 0L; var aMtx = 0L; var aWrx = 0L; var aWtx = 0L; var aOffM = 0L; var aOffW = 0L
        var lastFlush = lastT
        var lastPing = 0L
        var tick = 0
        var lastScore = 0L

        while (true) {
            delay(2000)
            val t = SystemClock.elapsedRealtime()
            val dt = ((t - lastT) / 1000.0).coerceAtLeast(0.5)
            lastT = t

            val mrx = TrafficStats.getMobileRxBytes()
            val mtx = TrafficStats.getMobileTxBytes()
            val trx = TrafficStats.getTotalRxBytes()
            val ttx = TrafficStats.getTotalTxBytes()

            val dMrx = delta(mrx, pMrx)
            val dMtx = delta(mtx, pMtx)
            val dWrx = maxOf(0L, delta(trx, pTrx) - dMrx)
            val dWtx = maxOf(0L, delta(ttx, pTtx) - dMtx)
            pMrx = mrx; pMtx = mtx; pTrx = trx; pTtx = ttx

            aMrx += dMrx; aMtx += dMtx; aWrx += dWrx; aWtx += dWtx
            if (!pm.isInteractive) {
                aOffM += dMrx + dMtx
                aOffW += dWrx + dWtx
            }

            val down = (dMrx + dWrx) / dt
            val up = (dMtx + dWtx) / dt
            withContext(Dispatchers.Main) { Live.push(down, up) }

            tick++
            nm.notify(1, liveNotif(down, up))

            if (t - lastFlush >= 30_000) {
                lastFlush = t
                val now = System.currentTimeMillis()
                Store.db.addMinute(now / 60_000 * 60_000, aMrx, aMtx, aWrx, aWtx, aOffM, aOffW)
                val wifiBytes = aWrx + aWtx
                if (wifiBytes > 0) {
                    val ssid = try { currentSsid(wm) } catch (e: Exception) { null }
                    if (ssid != null) Store.db.addWifi(dayStart(now), ssid, wifiBytes)
                }
                aMrx = 0; aMtx = 0; aWrx = 0; aWtx = 0; aOffM = 0; aOffW = 0

                if (UsageRepo.hasAccess(this)) {
                    val (m, w) = repo.range(dayStart(now), now)
                    withContext(Dispatchers.Main) { Live.today = m + w }
                    Alerts.check(this, m + w)

                    // the pinned data plan, for the notification
                    val ap = Prefs.activePlan()
                    val pu = if (ap != null) repo.planUsed(ap, now) else 0L
                    withContext(Dispatchers.Main) {
                        if (ap != null) {
                            Live.planName = ap.name
                            Live.planTotal = (ap.mb * 1_000_000.0).toLong()
                            Live.planUsed = pu
                        } else {
                            Live.planTotal = 0L
                        }
                    }
                    // the car's level, every ten minutes
                    if (t - lastScore >= 600_000L || lastScore == 0L) {
                        lastScore = t
                        val (st, sc) = repo.streakAndScore()
                        withContext(Dispatchers.Main) { Live.streak = st; Live.score = sc }
                    }
                }
            }

            if (t - lastPing >= 60_000) {
                lastPing = t
                val online = cm.activeNetwork != null
                val ms = if (online) tcpPing("1.1.1.1", 443, 2000) else -1
                Store.db.addPing(System.currentTimeMillis(), ms)
            }
        }
    }
}
