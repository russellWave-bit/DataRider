package com.breadwinner.datarider

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** A data bundle you want to keep an eye on. kind: 0 = Mobile and Wi-Fi, 1 = Wi-Fi only, 2 = Mobile only. */
data class Plan(val id: Long, val name: String, val mb: Float, val day: Int, val kind: Int)

/** All user settings. Fields are Compose state so the UI updates the moment they change. */
object Prefs {
    private lateinit var sp: SharedPreferences

    var theme by mutableStateOf(1)            // 0 follow phone, 1 dark, 2 light
    var hue by mutableStateOf(174f)           // 174 = aqua
    var brightness by mutableStateOf(0.9f)
    var opacity by mutableStateOf(1f)
    var overlayOpacity by mutableStateOf(0.55f)
    var overlayCarSize by mutableStateOf(72f) // width of the floating car, in dp
    var overlayLocked by mutableStateOf(false)
    var overlayX by mutableStateOf(-1)
    var overlayY by mutableStateOf(-1)
    var dailyLimitMb by mutableStateOf(4096f)
    var billingDay by mutableStateOf(1)       // monthly start day, 1 to 31, 32 = last day of the month
    var limitMode by mutableStateOf(0)        // 0 daily, 1 monthly
    var monthlyLimitMb by mutableStateOf(30720f)
    var dailyResetMin by mutableStateOf(0)    // daily cycle start, minutes after midnight
    var alert75 by mutableStateOf(true)
    var alertLimit by mutableStateOf(true)
    var setupDone by mutableStateOf(false)
    var overlayOn by mutableStateOf(false)
    var lastDevices by mutableStateOf(0)
    var pinnedPlan by mutableStateOf(0L)
    val planList = mutableStateListOf<Plan>()

    fun init(c: Context) {
        sp = c.getSharedPreferences("rider", Context.MODE_PRIVATE)
        theme = sp.getInt("theme", 1)
        hue = sp.getFloat("hue", 174f)
        brightness = sp.getFloat("brightness", 0.9f)
        opacity = sp.getFloat("opacity", 1f)
        // the new look starts with the fresh green, once
        if (sp.getInt("palVer", 0) < 3) {
            hue = 174f
            brightness = 0.9f
            opacity = 1f
            sp.edit().putInt("palVer", 3).putFloat("hue", hue).putFloat("brightness", brightness).putFloat("opacity", opacity).apply()
        }
        overlayOpacity = sp.getFloat("overlayOpacity", 0.55f)
        overlayCarSize = sp.getFloat("overlayCarSize", 72f)
        overlayLocked = sp.getBoolean("overlayLocked", false)
        overlayX = sp.getInt("overlayX", -1)
        overlayY = sp.getInt("overlayY", -1)
        dailyLimitMb = sp.getFloat("dailyLimitMb", 4096f)
        billingDay = sp.getInt("billingDay", 1)
        limitMode = sp.getInt("limitMode", 0)
        monthlyLimitMb = sp.getFloat("monthlyLimitMb", 30720f)
        dailyResetMin = sp.getInt("dailyResetMin", 0)
        alert75 = sp.getBoolean("alert75", true)
        alertLimit = sp.getBoolean("alertLimit", true)
        setupDone = sp.getBoolean("setupDone", false)
        overlayOn = sp.getBoolean("overlayOn", false)
        lastDevices = sp.getInt("lastDevices", 0)
        pinnedPlan = sp.getLong("pinnedPlan", 0L)
        planList.clear()
        try {
            val arr = JSONArray(sp.getString("plans", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                planList.add(Plan(o.getLong("id"), o.getString("name"), o.getDouble("mb").toFloat(), o.getInt("day"), o.getInt("kind")))
            }
        } catch (e: Exception) {
        }
    }

    fun save() {
        sp.edit()
            .putInt("theme", theme)
            .putFloat("hue", hue)
            .putFloat("brightness", brightness)
            .putFloat("opacity", opacity)
            .putFloat("overlayOpacity", overlayOpacity)
            .putFloat("overlayCarSize", overlayCarSize)
            .putBoolean("overlayLocked", overlayLocked)
            .putInt("overlayX", overlayX)
            .putInt("overlayY", overlayY)
            .putFloat("dailyLimitMb", dailyLimitMb)
            .putInt("billingDay", billingDay)
            .putInt("limitMode", limitMode)
            .putFloat("monthlyLimitMb", monthlyLimitMb)
            .putInt("dailyResetMin", dailyResetMin)
            .putBoolean("alert75", alert75)
            .putBoolean("alertLimit", alertLimit)
            .putBoolean("setupDone", setupDone)
            .putBoolean("overlayOn", overlayOn)
            .putInt("lastDevices", lastDevices)
            .putLong("pinnedPlan", pinnedPlan)
            .apply()
    }

    private fun savePlans() {
        val arr = JSONArray()
        for (p in planList) {
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("mb", p.mb.toDouble()).put("day", p.day).put("kind", p.kind))
        }
        sp.edit().putString("plans", arr.toString()).apply()
    }

    fun addPlan(p: Plan) {
        planList.add(p)
        savePlans()
    }

    fun removePlan(id: Long) {
        planList.removeAll { it.id == id }
        if (pinnedPlan == id) pinnedPlan = 0L
        savePlans()
        save()
    }

    /** The limit in the chosen mode. */
    fun limitMb(): Float = if (limitMode == 0) dailyLimitMb else monthlyLimitMb
    fun limitBytes(): Long = (limitMb() * 1_000_000.0).toLong()
    fun isDaily(): Boolean = limitMode == 0

    /** The plan shown in the notification: the pinned one, or the first. */
    fun activePlan(): Plan? = planList.firstOrNull { it.id == pinnedPlan } ?: planList.firstOrNull()

    fun knownDevices(): Set<String> = sp.getStringSet("known", emptySet()) ?: emptySet()
    fun saveKnown(s: Set<String>) {
        sp.edit().putStringSet("known", s).apply()
    }

    fun alertDay(): Long = sp.getLong("alertDay", 0L)
    fun alertLevel(): Int = sp.getInt("alertLevel", 0)
    fun setAlert(day: Long, level: Int) {
        sp.edit().putLong("alertDay", day).putInt("alertLevel", level).apply()
    }
}
