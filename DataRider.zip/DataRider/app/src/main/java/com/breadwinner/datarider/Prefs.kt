package com.breadwinner.datarider

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** All user settings. Fields are Compose state so the UI updates the moment they change. */
object Prefs {
    private lateinit var sp: SharedPreferences

    var theme by mutableStateOf(1)            // 0 follow phone, 1 dark, 2 light
    var hue by mutableStateOf(203f)           // 203 = electric blue
    var brightness by mutableStateOf(1f)
    var opacity by mutableStateOf(1f)
    var overlayOpacity by mutableStateOf(0.55f)
    var dailyLimitMb by mutableStateOf(4096f)
    var billingDay by mutableStateOf(1)
    var alert75 by mutableStateOf(true)
    var alertLimit by mutableStateOf(true)
    var setupDone by mutableStateOf(false)
    var overlayOn by mutableStateOf(false)
    var lastDevices by mutableStateOf(0)

    fun init(c: Context) {
        sp = c.getSharedPreferences("rider", Context.MODE_PRIVATE)
        theme = sp.getInt("theme", 1)
        hue = sp.getFloat("hue", 203f)
        brightness = sp.getFloat("brightness", 1f)
        opacity = sp.getFloat("opacity", 1f)
        overlayOpacity = sp.getFloat("overlayOpacity", 0.55f)
        dailyLimitMb = sp.getFloat("dailyLimitMb", 4096f)
        billingDay = sp.getInt("billingDay", 1)
        alert75 = sp.getBoolean("alert75", true)
        alertLimit = sp.getBoolean("alertLimit", true)
        setupDone = sp.getBoolean("setupDone", false)
        overlayOn = sp.getBoolean("overlayOn", false)
        lastDevices = sp.getInt("lastDevices", 0)
    }

    fun save() {
        sp.edit()
            .putInt("theme", theme)
            .putFloat("hue", hue)
            .putFloat("brightness", brightness)
            .putFloat("opacity", opacity)
            .putFloat("overlayOpacity", overlayOpacity)
            .putFloat("dailyLimitMb", dailyLimitMb)
            .putInt("billingDay", billingDay)
            .putBoolean("alert75", alert75)
            .putBoolean("alertLimit", alertLimit)
            .putBoolean("setupDone", setupDone)
            .putBoolean("overlayOn", overlayOn)
            .putInt("lastDevices", lastDevices)
            .apply()
    }

    fun knownDevices(): Set<String> = sp.getStringSet("known", emptySet()) ?: emptySet()
    fun saveKnown(s: Set<String>) {
        sp.edit().putStringSet("known", s).apply()
    }

    fun alertDay(): Long = sp.getLong("alertDay", 0L)
    fun alertLevel(): Int = sp.getInt("alertLevel", 0)
    fun setAlert(day: Long, level: Int) {
        sp.edit().putLong("alertDay", day).putInt("alertLevel", level).apply()
    }
}
