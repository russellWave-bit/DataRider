package com.breadwinner.datarider

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Process

data class AppUse(val uid: Int, val label: String, val mobile: Long, val wifi: Long, val bg: Long) {
    val total: Long get() = mobile + wifi
}

data class DayUse(val start: Long, val mobile: Long, val wifi: Long)

/** Reads Android's own usage history (usage access permission). */
class UsageRepo(ctx: Context) {
    private val c = ctx.applicationContext
    private val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    private val labels = HashMap<Int, String>()

    companion object {
        fun hasAccess(ctx: Context): Boolean {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    private fun dev(type: Int, from: Long, to: Long): Long =
        try {
            val b = nsm.querySummaryForDevice(type, null, from, to)
            b.rxBytes + b.txBytes
        } catch (e: Exception) {
            0L
        }

    fun mobile(from: Long, to: Long): Long = dev(ConnectivityManager.TYPE_MOBILE, from, to)
    fun wifi(from: Long, to: Long): Long = dev(ConnectivityManager.TYPE_WIFI, from, to)

    /** (mobile, wifi) bytes. Uses the larger of Android's record and the app's own history. */
    fun range(from: Long, to: Long): Pair<Long, Long> {
        val s = Store.db.sums(from, to)
        return maxOf(mobile(from, to), s[0]) to maxOf(wifi(from, to), s[1])
    }

    fun daily(days: Int): List<DayUse> {
        val today = dayStart()
        val out = ArrayList<DayUse>()
        for (i in days - 1 downTo 0) {
            val s = addDays(today, -i)
            val e = addDays(today, -i + 1)
            val (m, w) = range(s, e)
            out.add(DayUse(s, m, w))
        }
        return out
    }

    /** (streak, days under the limit in the last 30). A day counts when it used something but stayed within the daily limit. */
    fun streakAndScore(): Pair<Int, Int> {
        val limit = (Prefs.dailyLimitMb * 1_000_000.0).toLong()
        val days = daily(60)
        var streak = 0
        for (d in days.reversed()) {
            val t = d.mobile + d.wifi
            if (t in 1..limit) streak++ else break
        }
        val score = days.takeLast(30).count { (it.mobile + it.wifi) in 1..limit }
        return streak to score
    }

    /** Bytes used so far in this plan's cycle, counting only what the plan covers. */
    fun planUsed(p: Plan, now: Long = System.currentTimeMillis()): Long {
        val (m, w) = range(cycleStart(p.day, now), now)
        return pick(m, w, p.kind)
    }

    fun apps(from: Long, to: Long): List<AppUse> {
        val m = HashMap<Int, LongArray>() // mobile, wifi, background
        fun scan(type: Int, idx: Int) {
            try {
                val s = nsm.querySummary(type, null, from, to)
                val b = NetworkStats.Bucket()
                while (s.hasNextBucket()) {
                    s.getNextBucket(b)
                    val a = m.getOrPut(b.uid) { LongArray(3) }
                    val t = b.rxBytes + b.txBytes
                    a[idx] += t
                    if (b.state == NetworkStats.Bucket.STATE_DEFAULT) a[2] += t
                }
                s.close()
            } catch (e: Exception) {
            }
        }
        scan(ConnectivityManager.TYPE_MOBILE, 0)
        scan(ConnectivityManager.TYPE_WIFI, 1)
        return m.map { (uid, a) -> AppUse(uid, label(uid), a[0], a[1], a[2]) }
            .filter { it.total > 0 }
            .sortedByDescending { it.total }
    }

    fun label(uid: Int): String = labels.getOrPut(uid) {
        when (uid) {
            -4 -> "Removed apps"
            -5 -> "Hotspot / tethering"
            0, 1000 -> "Android system"
            else -> try {
                val pm = c.packageManager
                val p = pm.getPackagesForUid(uid)?.firstOrNull()
                if (p != null) pm.getApplicationInfo(p, 0).loadLabel(pm).toString() else "App $uid"
            } catch (e: Exception) {
                "App $uid"
            }
        }
    }
}
