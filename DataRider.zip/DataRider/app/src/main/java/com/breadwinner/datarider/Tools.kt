package com.breadwinner.datarider

import android.Manifest
import android.content.Intent
import android.net.ConnectivityManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellIdentityNr
import android.telephony.TelephonyManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URL
import java.net.HttpURLConnection
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

// ───────────────────────── SPEED TEST ─────────────────────────

private fun runDownload(onProgress: (Double) -> Unit): Double {
    val conn = URL("https://speed.cloudflare.com/__down?bytes=60000000").openConnection() as HttpURLConnection
    conn.connectTimeout = 5000
    conn.readTimeout = 8000
    val buf = ByteArray(64 * 1024)
    var total = 0L
    val t0 = System.nanoTime()
    conn.inputStream.use { ins ->
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            total += n
            val secs = (System.nanoTime() - t0) / 1e9
            if (secs > 0.3) onProgress(total * 8 / secs / 1e6)
            if (secs > 8.0) break
        }
    }
    conn.disconnect()
    val secs = ((System.nanoTime() - t0) / 1e9).coerceAtLeast(0.1)
    return total * 8 / secs / 1e6
}

private fun runUpload(onProgress: (Double) -> Unit): Double {
    val size = 8_000_000
    val conn = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
    conn.requestMethod = "POST"
    conn.doOutput = true
    conn.connectTimeout = 5000
    conn.readTimeout = 15000
    conn.setFixedLengthStreamingMode(size)
    val chunk = ByteArray(64 * 1024) { (it * 31).toByte() }
    var sent = 0L
    val t0 = System.nanoTime()
    conn.outputStream.use { out ->
        while (sent < size) {
            val n = minOf(chunk.size.toLong(), size - sent).toInt()
            out.write(chunk, 0, n)
            sent += n
            val secs = (System.nanoTime() - t0) / 1e9
            if (secs > 0.3) onProgress(sent * 8 / secs / 1e6)
        }
        out.flush()
    }
    try { conn.responseCode } catch (e: Exception) { }
    conn.disconnect()
    val secs = ((System.nanoTime() - t0) / 1e9).coerceAtLeast(0.1)
    return sent * 8 / secs / 1e6
}

@Composable
fun SpeedTestScreen(nav: Nav) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var phase by remember { mutableStateOf("Ready") }
    var down by remember { mutableStateOf(0.0) }
    var up by remember { mutableStateOf(0.0) }
    var ping by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(Store.db.recentSpeeds(8)) }
    val f = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }

    Page("Speed test", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T(phase, 13, p.muted)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { T("Download", 12, p.muted); T(f1(down), 30, p.accText, FontWeight.ExtraBold); T("Mbps", 11, p.muted) }
                Column { T("Upload", 12, p.muted); T(f1(up), 30, p.accText, FontWeight.ExtraBold); T("Mbps", 11, p.muted) }
                Column { T("Ping", 12, p.muted); T("$ping", 30, weight = FontWeight.ExtraBold); T("ms", 11, p.muted) }
            }
            Spacer(Modifier.height(14.dp))
            PillButton(if (busy) "Testing…" else "Start test") {
                if (!busy) {
                    busy = true
                    down = 0.0; up = 0.0; ping = 0
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            try {
                                phase = "Measuring ping…"
                                val pings = (1..5).map { tcpPing("1.1.1.1", 443, 2000) }.filter { it >= 0 }
                                ping = if (pings.isEmpty()) 0 else pings.average().toInt()
                                phase = "Testing download…"
                                down = runDownload { down = it }
                                phase = "Testing upload…"
                                up = runUpload { up = it }
                                Store.db.addSpeed(System.currentTimeMillis(), down, up, ping)
                                phase = "Done. This test used roughly ${fmtBytes(60_000_000L + 8_000_000L)} of data."
                            } catch (e: Exception) {
                                phase = "Test failed. Check your connection."
                            }
                        }
                        history = Store.db.recentSpeeds(8)
                        busy = false
                    }
                }
            }
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Past tests", 15)
            Spacer(Modifier.height(8.dp))
            if (history.isEmpty()) T("None yet.", 13, p.muted)
            history.forEach {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T(f.format(Date(it.ts)), 12, p.muted)
                    T("${f1(it.down)} down · ${f1(it.up)} up · ${it.ping} ms", 12)
                }
            }
        }
    }
}

// ───────────────────────── NETWORK TRAFFIC OVERLAY ─────────────────────────

@Composable
fun OverlayScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    Page("Network Traffic", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Floating panel", 15)
            Spacer(Modifier.height(4.dp))
            T("Shows a live graph of download and upload, your current speed, and the top three apps moving data. Tap it to shrink to a bubble, drag to move it, tap the X to close.", 13, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(14.dp))
            val on = Prefs.overlayOn
            PillButton(if (on) "Turn off" else "Turn on") {
                if (!Perm.overlay(ctx)) {
                    openOverlayAccess(ctx)
                } else if (on) {
                    ctx.stopService(Intent(ctx, OverlayService::class.java))
                    Prefs.overlayOn = false
                    Prefs.save()
                } else {
                    ctx.startService(Intent(ctx, OverlayService::class.java))
                }
            }
            if (!Perm.overlay(ctx)) {
                Spacer(Modifier.height(8.dp))
                T("Needs the Display over other apps permission first.", 12, Orange, FontWeight.Medium)
            }
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Opacity  ${(Prefs.overlayOpacity * 100).toInt()}%", 13)
            Slider(
                value = Prefs.overlayOpacity, onValueChange = { Prefs.overlayOpacity = it }, valueRange = 0.1f..1f,
                onValueChangeFinished = { Prefs.save() },
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.track)
            )
            T("Fainter for WhatsApp, stronger elsewhere. Applies next time you turn it on.", 11, p.muted, FontWeight.Medium)
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Heads up", 13, Orange)
            T("Android updates per-app numbers in chunks, so the top-three list is approximate rather than second-by-second.", 12, p.muted, FontWeight.Medium)
        }
    }
}

// ───────────────────────── DEVICE DISCOVERY ─────────────────────────

private fun scanLan(ctx: android.content.Context): List<Pair<String, String>> {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val net = cm.activeNetwork ?: return emptyList()
    val lp = cm.getLinkProperties(net) ?: return emptyList()
    val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return emptyList()
    val ip = la.address.hostAddress ?: return emptyList()
    val base = ip.substringBeforeLast(".")
    val found = Collections.synchronizedList(mutableListOf<Pair<String, String>>())
    val pool = Executors.newFixedThreadPool(48)
    val jobs = (1..254).map { i ->
        pool.submit {
            val a = "$base.$i"
            try {
                val ia = InetAddress.getByName(a)
                if (ia.isReachable(500)) {
                    val name = ia.canonicalHostName
                    found.add(a to (if (name == a) "Unknown device" else name))
                }
            } catch (e: Exception) {
            }
        }
    }
    jobs.forEach { try { it.get() } catch (e: Exception) { } }
    pool.shutdown()
    return found.sortedBy { it.first.substringAfterLast(".").toIntOrNull() ?: 0 }
}

@Composable
fun DevicesScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var devices by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(false) }
    var newOnes by remember { mutableStateOf<Set<String>>(emptySet()) }

    Page("Device Discovery", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Scan your Wi-Fi", 15)
            Spacer(Modifier.height(4.dp))
            T("Lists everything answering on the Wi-Fi you're connected to. It can't see random phones nearby, only this network.", 12, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            PillButton(if (busy) "Scanning…" else "Scan now") {
                if (!busy) {
                    busy = true
                    scope.launch {
                        val res = withContext(Dispatchers.IO) { scanLan(ctx) }
                        val known = Prefs.knownDevices()
                        val keys = res.map { "${it.first}|${it.second}" }.toSet()
                        newOnes = if (known.isEmpty()) emptySet() else keys - known
                        Prefs.saveKnown(known + keys)
                        devices = res
                        Prefs.lastDevices = res.size
                        Prefs.save()
                        scanned = true
                        busy = false
                    }
                }
            }
        }
        if (scanned) {
            RCard(Modifier.fillMaxWidth()) {
                T("${devices.size} devices found", 15)
                Spacer(Modifier.height(8.dp))
                if (devices.isEmpty()) T("Nothing answered. Are you on Wi-Fi?", 13, p.muted)
                devices.forEach { (ip, name) ->
                    val isNew = "$ip|$name" in newOnes
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            T(name, 13)
                            T(ip, 12, p.muted, FontWeight.Medium)
                        }
                        if (isNew) T("NEW", 12, Orange)
                    }
                }
                Spacer(Modifier.height(8.dp))
                T("New means not seen in an earlier scan. Android hides device hardware addresses from apps, so this matches by IP and name.", 11, p.muted, FontWeight.Medium)
            }
        }
    }
}

// ───────────────────────── CONNECTION LOG ─────────────────────────

@Composable
fun ConnLogScreen(nav: Nav) {
    val p = LocalPal.current
    val rows by produceState<List<HourPing>>(emptyList()) {
        value = withContext(Dispatchers.IO) { Store.db.hourlyPings(System.currentTimeMillis() - 24 * 3_600_000L) }
    }
    val f = remember { SimpleDateFormat("EEE HH:00", Locale.getDefault()) }
    Page("Connection Log", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Last 24 hours, hour by hour", 15)
            T("A tiny ping goes out every minute while the tracker runs. Drops are pings that got no answer.", 12, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            if (rows.isEmpty()) T("Nothing logged yet. Give it a few minutes.", 13, p.muted)
            rows.forEach {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T(f.format(Date(it.hour)), 13, p.muted)
                    T(if (it.total - it.drops == 0) "offline" else "${it.avgMs} ms", 13)
                    T("${it.drops} drops", 13, if (it.drops > 0) Orange else p.muted)
                }
            }
        }
    }
}

// ───────────────────────── WI-FI ANALYZER ─────────────────────────

private fun channelOf(freq: Int): Int = when {
    freq in 2412..2484 -> (freq - 2407) / 5
    freq in 5000..5900 -> (freq - 5000) / 5
    else -> 0
}

@Composable
fun WifiScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var results by remember { mutableStateOf<List<ScanResult>>(emptyList()) }

    fun scan() {
        val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
        @Suppress("DEPRECATION") wm.startScan()
        results = try { wm.scanResults.sortedByDescending { it.level } } catch (e: SecurityException) { emptyList() }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { scan() }

    Page("Wi-Fi Analyzer", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Networks around you", 15)
            T("Needs the Location permission, and Location switched on, because Android treats Wi-Fi scans as location data.", 12, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            PillButton("Scan") {
                if (Perm.location(ctx)) scan() else launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
        if (results.isNotEmpty()) {
            val g24 = results.filter { it.frequency in 2400..2500 }
            val counts = (1..13).associateWith { c -> g24.count { channelOf(it.frequency) == c } }
            val best = listOf(1, 6, 11).minByOrNull { counts[it] ?: 0 } ?: 1
            RCard(Modifier.fillMaxWidth()) {
                T("2.4 GHz channel congestion", 15)
                Spacer(Modifier.height(10.dp))
                val mx = (counts.values.maxOrNull() ?: 1).coerceAtLeast(1)
                Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                    counts.forEach { (ch, n) ->
                        Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Box(
                                Modifier.fillMaxWidth().fillMaxHeight((n.toFloat() / mx).coerceAtLeast(0.05f) * 0.75f)
                                    .clip(RoundedCornerShape(2.dp)).background(if (n == 0) p.track else p.accent)
                            )
                            T("$ch", 9, p.muted)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                T("Least crowded of 1, 6 and 11: channel $best", 12, p.accText)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("${results.size} networks", 15)
                Spacer(Modifier.height(8.dp))
                results.take(25).forEach {
                    val name = it.SSID.ifBlank { "(hidden)" }
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            T(name, 13)
                            T("Channel ${channelOf(it.frequency)} · ${if (it.frequency > 4000) "5" else "2.4"} GHz", 11, p.muted, FontWeight.Medium)
                        }
                        T("${it.level} dBm", 12, if (it.level > -60) p.accText else if (it.level > -75) p.text else Orange)
                    }
                }
            }
        }
    }
}

// ───────────────────────── CELL TOWERS ─────────────────────────

private fun cellLine(ci: CellInfo): Pair<String, String> = when (ci) {
    is CellInfoLte -> "4G LTE" to "PCI ${ci.cellIdentity.pci} · ${ci.cellSignalStrength.dbm} dBm"
    is CellInfoGsm -> "2G GSM" to "Cell ${ci.cellIdentity.cid} · ${ci.cellSignalStrength.dbm} dBm"
    is CellInfoWcdma -> "3G WCDMA" to "Cell ${ci.cellIdentity.cid} · ${ci.cellSignalStrength.dbm} dBm"
    is CellInfoNr -> "5G NR" to "PCI ${(ci.cellIdentity as CellIdentityNr).pci} · ${ci.cellSignalStrength.dbm} dBm"
    else -> "Cell" to "Signal details unavailable"
}

@Composable
fun TowersScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var cells by remember { mutableStateOf<List<CellInfo>>(emptyList()) }
    var tried by remember { mutableStateOf(false) }

    fun load() {
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        cells = try { tm.allCellInfo ?: emptyList() } catch (e: SecurityException) { emptyList() }
        tried = true
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { load() }

    Page("Cell Towers", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Towers your phone can see", 15)
            T("Needs the Location permission. Samsung may hide some towers from apps.", 12, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            PillButton("Refresh") {
                if (Perm.location(ctx)) load() else launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
        if (tried) {
            RCard(Modifier.fillMaxWidth()) {
                if (cells.isEmpty()) T("No towers reported. Check Location is on.", 13, p.muted)
                cells.forEach {
                    val (kind, detail) = cellLine(it)
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { T(kind, 13); T(detail, 12, p.muted, FontWeight.Medium) }
                        if (it.isRegistered) T("Connected", 12, p.accText)
                    }
                }
            }
        }
    }
}

// ───────────────────────── NETWORK CONNECTIONS ─────────────────────────

@Composable
fun ConnectionsScreen(nav: Nav) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val repo = remember { UsageRepo(ctx) }
    val apps by produceState<List<AppUse>>(emptyList()) {
        value = withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            repo.apps(now - 3_600_000L, now).take(12)
        }
    }
    Page("Network Connections", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("What Android allows", 15)
            T("Since Android 10, apps are not allowed to see which sockets other apps have open. That list needs root, so this screen shows what is possible: which apps moved data in the last hour, and over which network.", 12, p.muted, FontWeight.Medium)
        }
        RCard(Modifier.fillMaxWidth()) {
            T("Active in the last hour", 15)
            Spacer(Modifier.height(8.dp))
            if (apps.isEmpty()) T("Nothing yet.", 13, p.muted)
            apps.forEach {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T(it.label, 13, modifier = Modifier.weight(1f))
                    T("Mobile ${fmtBytes(it.mobile)} · Wi-Fi ${fmtBytes(it.wifi)}", 11, p.muted, FontWeight.Medium)
                }
            }
        }
    }
}

// ───────────────────────── PING TEST ─────────────────────────

@Composable
fun PingScreen(nav: Nav) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var host by remember { mutableStateOf("1.1.1.1") }
    var out by remember { mutableStateOf<List<Int>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }

    Page("Ping Test", nav) {
        RCard(Modifier.fillMaxWidth()) {
            T("Host", 13, p.muted)
            Spacer(Modifier.height(6.dp))
            BasicTextField(
                value = host, onValueChange = { host = it.trim() }, singleLine = true,
                textStyle = TextStyle(color = p.text, fontSize = 16.sp),
                cursorBrush = SolidColor(p.accent),
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(p.bg).padding(12.dp)
            )
            Spacer(Modifier.height(6.dp))
            T("Uses a TCP connection on port 443 (or 80), which works without root. Results are close to a normal ping.", 11, p.muted, FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            PillButton(if (busy) "Pinging…" else "Ping 10 times") {
                if (!busy && host.isNotBlank()) {
                    busy = true; done = false; out = emptyList()
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            val res = mutableListOf<Int>()
                            repeat(10) {
                                var ms = tcpPing(host, 443, 2000)
                                if (ms < 0) ms = tcpPing(host, 80, 2000)
                                res.add(ms)
                                out = res.toList()
                                Thread.sleep(300)
                            }
                        }
                        busy = false
                        done = true
                    }
                }
            }
        }
        if (out.isNotEmpty()) {
            RCard(Modifier.fillMaxWidth()) {
                val ok = out.filter { it >= 0 }
                val loss = 100 * (out.size - ok.size) / out.size
                T(if (done) "Result" else "Running…", 13, p.muted)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { T("Min", 12, p.muted); T(if (ok.isEmpty()) "-" else "${ok.min()} ms", 20, weight = FontWeight.ExtraBold) }
                    Column { T("Avg", 12, p.muted); T(if (ok.isEmpty()) "-" else "${ok.average().toInt()} ms", 20, weight = FontWeight.ExtraBold) }
                    Column { T("Max", 12, p.muted); T(if (ok.isEmpty()) "-" else "${ok.max()} ms", 20, weight = FontWeight.ExtraBold) }
                    Column { T("Loss", 12, p.muted); T("$loss%", 20, if (loss > 0) Orange else p.accText, FontWeight.ExtraBold) }
                }
                Spacer(Modifier.height(10.dp))
                T(out.joinToString("  ") { if (it < 0) "x" else "$it" }, 12, p.muted, FontWeight.Medium)
            }
        }
    }
}
