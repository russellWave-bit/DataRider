package com.breadwinner.datarider

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sin
import kotlin.math.sqrt
import androidx.compose.ui.graphics.Color as ComposeColor

/**
 * Just the little rider: the red car or the pixel cat. Wheels (or paws) move with your data speed and the car's
 * exhaust smoke gets thicker when the flow is heavy. The view is wider and taller than the rider on purpose,
 * so the smoke has room to drift back and is never cut off at the edge.
 */
class CarOverlayView(c: Context) : View(c) {
    private val motion = CarMotion()
    private val ds = CanvasDrawScope()
    var widthDp = 72f
    private var last = 0L
    private var thr = 0f

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val carW = (widthDp * resources.displayMetrics.density).toInt()
        setMeasuredDimension((carW * 1.9f).toInt(), (carW * 1.22f).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1000f).coerceIn(0.005f, 0.1f)
        last = now
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val carW = widthDp * resources.displayMetrics.density
        val sc = carW / 70f
        val cx = w - carW / 2f
        val inten = intensityOf(Live.down + Live.up)
        val broken = Live.broken
        val ground = h - 2f
        val cat = Prefs.rider == 1
        val cell = sc * 1.6f
        motion.step(
            dt, 0f, 0f, inten, broken, false, 50f * sc,
            if (cat) cx - 9f * cell else cx + EXH_X * sc, if (cat) ground - cell else ground + (EXH_Y - 7.5f) * sc,
            cx + 18f * sc, ground - 36f * sc, sc
        )
        thr += (20f + 160f * inten) * sc * dt * (if (broken) 0f else 1f)
        val bob = sin(motion.time * 14f) * (0.5f + 1.5f * inten)
        ds.draw(Density(resources.displayMetrics.density), LayoutDirection.Ltr, androidx.compose.ui.graphics.Canvas(cv), Size(w, h)) {
            if (cat) {
                val xs = ArrayList<Float>()
                val ys = ArrayList<Float>()
                var x = cx - carW * 0.62f
                val x1 = cx + carW * 0.62f
                while (x <= x1) { xs.add(x); ys.add(ground); x += 3.2f * sc * 2f }
                val strand = Path().apply { moveTo(cx - carW * 0.62f, ground); lineTo(x1, ground) }
                drawYarn(strand, 3.2f * sc, thr, xs, ys)
                drawDust(motion.smoke, sc)
                drawCat(cx, ground - 1.2f * sc, cell, 0f, catFrame(motion.spin), Live.level, broken, motion.time)
            } else {
                drawSmoke(motion.smoke, sc)
                drawCarFull(
                    cx, ground, ground, sc, 0f, 0f, motion.spin, motion.blur,
                    Live.level, broken, motion.time, bob
                )
            }
        }
        if (isShown) postInvalidateDelayed(33)
    }
}

/** The smooth, wavy download graph with the car riding along the line. */
class GraphCarView(c: Context, private val accent: Int) : View(c) {
    private val motion = CarMotion()
    private val ds = CanvasDrawScope()
    private val d = c.resources.displayMetrics.density
    private var last = 0L
    private val windowMs = 120_000f

    private fun smooth(v: List<Float>): List<Float> {
        var cur = v
        repeat(2) {
            cur = cur.mapIndexed { i, x ->
                val a = cur.getOrElse(i - 1) { x }
                val b = cur.getOrElse(i + 1) { x }
                (a + 2f * x + b) / 4f
            }
        }
        return cur
    }

    /** Catmull-Rom curve through the points, as cubic pieces, so nothing looks sharp. */
    private fun curve(xs: List<Float>, ys: List<Float>): Path {
        val p = Path()
        if (xs.size < 2) return p
        p.moveTo(xs[0], ys[0])
        for (i in 0 until xs.size - 1) {
            val x0 = xs.getOrElse(i - 1) { xs[i] }
            val y0 = ys.getOrElse(i - 1) { ys[i] }
            val x3 = xs.getOrElse(i + 2) { xs[i + 1] }
            val y3 = ys.getOrElse(i + 2) { ys[i + 1] }
            p.cubicTo(
                xs[i] + (xs[i + 1] - x0) / 6f, ys[i] + (ys[i + 1] - y0) / 6f,
                xs[i + 1] - (x3 - xs[i]) / 6f, ys[i + 1] - (y3 - ys[i]) / 6f,
                xs[i + 1], ys[i + 1]
            )
        }
        return p
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1000f).coerceIn(0.005f, 0.1f)
        last = now
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return

        val hist = Live.history.toList()
        val stamps = Live.stamps.toList()
        val n = minOf(hist.size, stamps.size)
        val inten = intensityOf(Live.down + Live.up)
        val broken = Live.broken
        val sc = (34f * d) / 58f

        // points: x by time so the graph flows smoothly, y squashed with a square root so spikes stay gentle
        val nowMs = System.currentTimeMillis()
        var mx = 50_000f
        for (i in 0 until n) mx = maxOf(mx, hist[i].first, hist[i].second)
        val top = h * 0.30f
        fun yOf(v: Float): Float = h - 3f * d - sqrt((v / mx).coerceIn(0f, 1f)) * (h - top - 3f * d)
        val xs = ArrayList<Float>()
        val yd = ArrayList<Float>()
        val yu = ArrayList<Float>()
        if (n >= 2) {
            val dv = smooth((0 until n).map { hist[it].first })
            val uv = smooth((0 until n).map { hist[it].second })
            for (i in 0 until n) {
                xs.add(w * (1f - (nowMs - stamps[i]) / windowMs))
                yd.add(yOf(dv[i]))
                yu.add(yOf(uv[i]))
            }
            // carry the line to the edges
            xs.add(w + 2f); yd.add(yd.last()); yu.add(yu.last())
            if (xs[0] > 0f) {
                xs.add(0, -2f); yd.add(0, yd[0]); yu.add(0, yu[0])
            }
        }

        fun lineY(x: Float): Float {
            if (xs.size < 2) return h - 3f * d
            if (x <= xs.first()) return yd.first()
            for (i in 0 until xs.size - 1) {
                if (x <= xs[i + 1]) {
                    val t = ((x - xs[i]) / (xs[i + 1] - xs[i]).coerceAtLeast(0.001f)).coerceIn(0f, 1f)
                    return yd[i] + (yd[i + 1] - yd[i]) * t
                }
            }
            return yd.last()
        }

        val cx = w * 0.62f
        val dxw = 17f * sc
        val gr = lineY(cx - dxw)
        val gf = lineY(cx + dxw)
        val baseAng = atan2(gf - gr, dxw * 2f) * 180f / Math.PI.toFloat()
        val midY = (gr + gf) / 2f
        val cat = Prefs.rider == 1
        val cell = sc * 1.6f
        motion.step(
            dt, h - midY, baseAng, inten, broken, true, w / windowMs * 20f,
            if (cat) cx - 9f * cell else cx + EXH_X * sc, if (cat) midY - cell else midY + (EXH_Y - 7.5f) * sc,
            cx + 18f * sc, midY - 36f * sc, sc
        )

        val acc = ComposeColor(accent)
        ds.draw(Density(d), LayoutDirection.Ltr, androidx.compose.ui.graphics.Canvas(cv), Size(w, h)) {
            if (xs.size >= 2) {
                val pd = curve(xs, yd)
                val pu = curve(xs, yu)
                val fill = curve(xs, yd)
                fill.lineTo(xs.last(), h)
                fill.lineTo(xs.first(), h)
                fill.close()
                drawPath(fill, acc.copy(alpha = 0.22f))
                drawPath(pu, ComposeColor(0xFFF4EFE7).copy(alpha = 0.7f), style = Stroke(1.5f * d, cap = StrokeCap.Round))
                drawPath(pd, acc, style = Stroke(2.6f * d, cap = StrokeCap.Round))
            }
            if (cat) {
                drawDust(motion.smoke, sc)
                drawCat(cx, midY - 1f * d, cell, motion.ang, catFrame(motion.spin), Live.level, broken, motion.time)
            } else {
                drawSmoke(motion.smoke, sc)
                drawCarFull(
                    cx, gr, gf, sc, motion.ang, motion.bodyY, motion.spin, motion.blur,
                    Live.level, broken, motion.time, sin(motion.time * 9f) * (0.4f + 1.2f * inten)
                )
            }
        }
        if (isShown) postInvalidateDelayed(33)
    }
}

/**
 * The floating "Network Traffic" overlay. By default it is only the little car.
 * Tap it to open the graph, tap again to shrink back. Long press and drag to move it, or lock it in Settings.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var poll: Job? = null
    @Volatile private var topText = "Collecting…"
    private var expanded = false

    private lateinit var carView: CarOverlayView
    private lateinit var panel: LinearLayout
    private lateinit var panelBg: GradientDrawable
    private lateinit var speedTv: TextView
    private lateinit var graph: GraphCarView
    private lateinit var appsTv: TextView

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) build()
        return START_STICKY
    }

    private fun panelAlpha(): Int = (Prefs.overlayOpacity * 255).toInt().coerceIn(25, 255)

    private fun build() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val accent = Color.HSVToColor(floatArrayOf(Prefs.hue, 0.72f, Prefs.brightness))

        // the car
        carView = CarOverlayView(this).apply { widthDp = Prefs.overlayCarSize }

        // the graph panel
        panelBg = GradientDrawable().apply {
            cornerRadius = 16 * d
            setColor(Color.argb(panelAlpha(), 26, 24, 22))
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
            visibility = View.GONE
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        speedTv = TextView(this).apply {
            setTextColor(accent); textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.argb(220, 244, 239, 231)); textSize = 16f
            setPadding((14 * d).toInt(), (4 * d).toInt(), (2 * d).toInt(), (4 * d).toInt())
            setOnClickListener {
                Prefs.overlayOn = false
                Prefs.save()
                stopSelf()
            }
        }
        header.addView(speedTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(close)
        graph = GraphCarView(this, accent)
        appsTv = TextView(this).apply { setTextColor(Color.argb(235, 244, 239, 231)); textSize = 12f }
        panel.addView(header)
        panel.addView(graph, LinearLayout.LayoutParams((206 * d).toInt(), (84 * d).toInt()))
        panel.addView(appsTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (6 * d).toInt() })

        val box = FrameLayout(this)
        box.addView(carView)
        box.addView(panel)

        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (Prefs.overlayX >= 0) Prefs.overlayX.coerceIn(0, (sw - (40 * d).toInt()).coerceAtLeast(0)) else (16 * d).toInt()
            y = if (Prefs.overlayY >= 0) Prefs.overlayY.coerceIn(0, (sh - (60 * d).toInt()).coerceAtLeast(0)) else (120 * d).toInt()
        }

        // long press then drag moves it; a plain tap opens or closes the graph
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var dragging = false
        var longFired = false
        val longRun = Runnable {
            longFired = true
            if (!moved && !Prefs.overlayLocked) {
                dragging = true
                box.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            }
        }
        box.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y
                    moved = false; dragging = false; longFired = false
                    handler.postDelayed(longRun, 380)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > 12 || abs(dy) > 12)) {
                        moved = true
                        handler.removeCallbacks(longRun)
                    }
                    if (dragging) {
                        lp.x = (startX + dx).toInt().coerceIn(0, (sw - v.width).coerceAtLeast(0))
                        lp.y = (startY + dy).toInt().coerceIn(0, (sh - v.height).coerceAtLeast(0))
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRun)
                    if (dragging) {
                        Prefs.overlayX = lp.x
                        Prefs.overlayY = lp.y
                        Prefs.save()
                    } else if (!moved && !longFired && e.action == MotionEvent.ACTION_UP) {
                        toggle()
                    }
                    dragging = false
                    true
                }
                else -> false
            }
        }

        root = box
        wm.addView(box, lp)
        Prefs.overlayOn = true
        Prefs.save()
        tickUi()
        startPolling()
    }

    private fun toggle() {
        expanded = !expanded
        carView.visibility = if (expanded) View.GONE else View.VISIBLE
        panel.visibility = if (expanded) View.VISIBLE else View.GONE
        carView.invalidate()
        graph.invalidate()
        // keep the panel on screen when it opens near the right edge
        handler.post {
            val r = root ?: return@post
            val sw = resources.displayMetrics.widthPixels
            val sh = resources.displayMetrics.heightPixels
            lp.x = lp.x.coerceIn(0, (sw - r.width).coerceAtLeast(0))
            lp.y = lp.y.coerceIn(0, (sh - r.height).coerceAtLeast(0))
            try { wm.updateViewLayout(r, lp) } catch (e: Exception) { }
        }
    }

    private fun tickUi() {
        speedTv.text = speedStr(Live.down + Live.up)
        appsTv.text = topText
        panelBg.setColor(Color.argb(panelAlpha(), 26, 24, 22))
        if (carView.widthDp != Prefs.overlayCarSize) {
            carView.widthDp = Prefs.overlayCarSize
            carView.requestLayout()
        }
        handler.postDelayed({ if (root != null) tickUi() }, 1000)
    }

    /** Top three apps by data moved since the last check. Android updates per-app numbers in chunks, so this is approximate. */
    private fun startPolling() {
        poll = scope.launch {
            val repo = UsageRepo(this@OverlayService)
            var prev = HashMap<Int, Long>()
            var prevT = System.currentTimeMillis()
            while (true) {
                try {
                    val now = System.currentTimeMillis()
                    val apps = repo.apps(dayStart(now), now)
                    val secs = ((now - prevT) / 1000.0).coerceAtLeast(1.0)
                    val cur = HashMap<Int, Long>()
                    apps.forEach { cur[it.uid] = it.total }
                    val moving = apps.map { it to ((cur[it.uid] ?: 0L) - (prev[it.uid] ?: it.total)) }
                        .filter { it.second > 0 }
                        .sortedByDescending { it.second }
                        .take(3)
                    topText = if (moving.isNotEmpty() && prev.isNotEmpty()) {
                        moving.joinToString("\n") { "${it.first.label}  ${speedStr(it.second / secs)}" }
                    } else {
                        apps.take(3).joinToString("\n") { "${it.label}  ${fmtBytes(it.total)} today" }.ifEmpty { "No app data yet" }
                    }
                    prev = cur
                    prevT = now
                } catch (e: Exception) {
                }
                delay(8000)
            }
        }
    }

    override fun onDestroy() {
        poll?.cancel()
        handler.removeCallbacksAndMessages(null)
        root?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        root = null
        Prefs.overlayOn = false
        Prefs.save()
        super.onDestroy()
    }
}
