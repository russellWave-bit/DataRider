package com.breadwinner.datarider

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Draws two flowing lines (download in accent, upload in white). */
class GraphView(c: Context, private val accent: Int) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val down = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent; style = Paint.Style.STROKE; strokeWidth = 2.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val up = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 235, 242, 250); style = Paint.Style.STROKE; strokeWidth = 1.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent)); style = Paint.Style.FILL
    }

    override fun onDraw(cv: Canvas) {
        val h = Live.history.toList()
        if (h.size < 2) return
        var mx = 50_000f
        for ((a, b) in h) mx = maxOf(mx, a, b)
        val w = width.toFloat()
        val ht = height.toFloat()
        val pd = Path()
        val pu = Path()
        val pf = Path()
        h.forEachIndexed { i, (a, b) ->
            val x = i / 59f * w
            val yd = ht - a / mx * ht * 0.9f - 2 * d
            val yu = ht - b / mx * ht * 0.9f - 2 * d
            if (i == 0) {
                pd.moveTo(x, yd); pu.moveTo(x, yu); pf.moveTo(x, ht); pf.lineTo(x, yd)
            } else {
                pd.lineTo(x, yd); pu.lineTo(x, yu); pf.lineTo(x, yd)
            }
        }
        pf.lineTo((h.size - 1) / 59f * w, ht)
        pf.close()
        cv.drawPath(pf, fill)
        cv.drawPath(pu, up)
        cv.drawPath(pd, down)
    }
}

/** The floating "Network Traffic" panel. Tap to shrink to a bubble, drag to move, X to close. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var poll: Job? = null
    @Volatile private var topText = "Collecting…"
    private var expanded = true

    private lateinit var speedTv: TextView
    private lateinit var graph: GraphView
    private lateinit var appsTv: TextView

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) build()
        return START_STICKY
    }

    private fun build() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val accent = Color.HSVToColor(floatArrayOf(Prefs.hue, 0.82f, Prefs.brightness))

        val bg = GradientDrawable().apply {
            cornerRadius = 16 * d
            setColor(Color.argb((Prefs.overlayOpacity * 255).toInt().coerceIn(25, 255), 8, 12, 18))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        speedTv = TextView(this).apply {
            setTextColor(accent); textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.argb(220, 230, 238, 246)); textSize = 16f
            setPadding((14 * d).toInt(), (4 * d).toInt(), (2 * d).toInt(), (4 * d).toInt())
            setOnClickListener {
                Prefs.overlayOn = false
                Prefs.save()
                stopSelf()
            }
        }
        header.addView(speedTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(close)

        graph = GraphView(this, accent)
        appsTv = TextView(this).apply { setTextColor(Color.argb(235, 232, 241, 250)); textSize = 12f }

        box.addView(header)
        box.addView(graph, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (56 * d).toInt()))
        box.addView(appsTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (6 * d).toInt() })

        val lp = WindowManager.LayoutParams(
            (230 * d).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (16 * d).toInt(); y = (120 * d).toInt() }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    if (moved) {
                        lp.x = (ox + dx).toInt(); lp.y = (oy + dy).toInt()
                        wm.updateViewLayout(box, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggle(); true }
                else -> false
            }
        }

        root = box
        wm.addView(box, lp)
        Prefs.overlayOn = true
        Prefs.save()
        tickUi()
        startPolling()
    }

    private fun toggle() {
        expanded = !expanded
        val v = if (expanded) View.VISIBLE else View.GONE
        graph.visibility = v
        appsTv.visibility = v
        speedTv.textSize = if (expanded) 20f else 16f
    }

    private fun tickUi() {
        speedTv.text = speedStr(Live.down + Live.up)
        graph.invalidate()
        appsTv.text = topText
        handler.postDelayed({ if (root != null) tickUi() }, 1000)
    }

    /** Top three apps by data moved since the last check. Android updates per-app numbers in chunks, so this is approximate. */
    private fun startPolling() {
        poll = scope.launch {
            val repo = UsageRepo(this@OverlayService)
            var prev = HashMap<Int, Long>()
            var prevT = System.currentTimeMillis()
            while (true) {
                try {
                    val now = System.currentTimeMillis()
                    val apps = repo.apps(dayStart(now), now)
                    val secs = ((now - prevT) / 1000.0).coerceAtLeast(1.0)
                    val cur = HashMap<Int, Long>()
                    apps.forEach { cur[it.uid] = it.total }
                    val moving = apps.map { it to ((cur[it.uid] ?: 0L) - (prev[it.uid] ?: it.total)) }
                        .filter { it.second > 0 }
                        .sortedByDescending { it.second }
                        .take(3)
                    topText = if (moving.isNotEmpty() && prev.isNotEmpty()) {
                        moving.joinToString("\n") { "${it.first.label}  ${speedStr(it.second / secs)}" }
                    } else {
                        apps.take(3).joinToString("\n") { "${it.label}  ${fmtBytes(it.total)} today" }.ifEmpty { "No app data yet" }
                    }
                    prev = cur
                    prevT = now
                } catch (e: Exception) {
                }
                delay(8000)
            }
        }
    }

    override fun onDestroy() {
        poll?.cancel()
        handler.removeCallbacksAndMessages(null)
        root?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        root = null
        Prefs.overlayOn = false
        Prefs.save()
        super.onDestroy()
    }
}
