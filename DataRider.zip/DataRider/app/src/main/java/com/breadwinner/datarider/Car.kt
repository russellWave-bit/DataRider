package com.breadwinner.datarider

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.random.Random

val LEVEL_NAMES = listOf("Plain", "Shiny", "Gold wheels", "Racing stripe", "Top spec")
val LEVEL_AT = listOf(0, 5, 10, 18, 27)

private fun rad(d: Float): Float = (d * PI / 180.0).toFloat()

private val Tyre = Color(0xFF14110F)
private val Silver = Color(0xFFD5DBE2)
private val Gold = Color(0xFFF4C455)
private val Spoke = Color(0xFF55606C)
private val Dot = Color(0xFFFFD23F)
private val RedA = Color(0xFFE23039)
private val RedB = Color(0xFFA8202A)
private val Dark = Color(0xFF2A2420)

private fun DrawScope.drawWheel(c: Offset, r: Float, spin: Float, blur: Float, level: Int, flat: Boolean) {
    if (flat) {
        val ry = r * 0.62f
        drawOval(Tyre, Offset(c.x - r, c.y - ry), Size(r * 2f, ry * 2f))
        drawOval(Silver, Offset(c.x - r * 0.55f, c.y - ry * 0.55f), Size(r * 1.1f, ry * 1.1f))
        return
    }
    val rim = if (level >= 2) Gold else Silver
    val rr = r * (if (level >= 2) 0.7f else 0.62f)
    drawCircle(Tyre, r, c)
    drawCircle(rim, rr, c)
    val a = 1f - 0.75f * blur
    val n = if (level >= 2) 6 else 5
    for (i in 0 until n) {
        val ang = rad(spin + i * 360f / n)
        drawLine(
            Spoke.copy(alpha = a), c,
            Offset(c.x + cos(ang) * rr * 0.92f, c.y + sin(ang) * rr * 0.92f),
            r * 0.16f, StrokeCap.Round
        )
    }
    if (blur > 0.25f) {
        for (k in 0..2) {
            drawArc(
                Color.White.copy(alpha = 0.3f * blur), spin + k * 120f, 55f, false,
                Offset(c.x - rr * 0.62f, c.y - rr * 0.62f), Size(rr * 1.24f, rr * 1.24f),
                style = Stroke(rr * 0.5f)
            )
        }
    }
    drawCircle(Spoke, r * 0.14f, c)
    val da = rad(spin + 36f)
    drawCircle(Dot, r * 0.13f, Offset(c.x + cos(da) * rr * 0.78f, c.y + sin(da) * rr * 0.78f))
}

/** Where the tailpipe tip is, in the car's own units (used as the smoke start). */
const val EXH_X = -33.5f
const val EXH_Y = -8f

val CAR_PAINTS = listOf(
    Color(0xFFEF6B5B), Color(0xFF4C9BE8), Color(0xFFF2A93B), Color(0xFF2FA866), Color(0xFF8C5BC8), Color(0xFF3D4A44)
)
val CAR_PAINT_NAMES = listOf("Coral", "Sky", "Amber", "Green", "Plum", "Charcoal")
val CAR_MODEL_NAMES = listOf("Hatch", "Combi", "Bakkie")

private fun shade(c: Color, k: Float): Color = androidx.compose.ui.graphics.lerp(c, Color.Black, k)

/**
 * The car body, kept simple and flat: a tub, a cabin, a window, a driver in shades.
 * Local units: the axle line is y = 0, the wheels sit at x = -17 and x = +17, up is negative y.
 */
private fun DrawScope.drawBodyLocal(level: Int, broken: Boolean, time: Float, bob: Float) {
    val model = Prefs.carModel.coerceIn(0, 2)
    val paint = CAR_PAINTS[Prefs.carPaint.coerceIn(0, CAR_PAINTS.size - 1)]
    val dk = shade(paint, 0.28f)
    val glass = Color(0xFFCFE9F7)

    // tailpipe
    drawRoundRect(Dark, Offset(-35f, -9.5f), Size(7f, 3f), CornerRadius(1.4f))
    // spoiler on the top car
    if (level >= 4 && model != 2) {
        drawRect(Dark, Offset(-30f, -26f), Size(2f, 5f))
        drawRoundRect(dk, Offset(-33f, -28f), Size(12f, 2.6f), CornerRadius(1.2f))
    }

    // tub
    drawRoundRect(paint, Offset(-30f, -18f), Size(60f, 12f), CornerRadius(5f))

    // cabin
    val cab = Path()
    when (model) {
        0 -> { // hatch: short, tall back
            cab.moveTo(-22f, -17f); cab.lineTo(-19f, -29f); cab.lineTo(6f, -29f); cab.lineTo(15f, -17f); cab.close()
        }
        1 -> { // combi: long roof to the back
            cab.moveTo(-28f, -17f); cab.lineTo(-27f, -29f); cab.lineTo(7f, -29f); cab.lineTo(16f, -17f); cab.close()
        }
        else -> { // bakkie: cab at the front, open load bed at the back
            cab.moveTo(-6f, -17f); cab.lineTo(-4f, -29f); cab.lineTo(10f, -29f); cab.lineTo(18f, -17f); cab.close()
        }
    }
    drawPath(cab, paint)
    // window
    val win = Path()
    when (model) {
        0 -> { win.moveTo(-17f, -18.5f); win.lineTo(-15f, -27f); win.lineTo(5f, -27f); win.lineTo(12.5f, -18.5f); win.close() }
        1 -> { win.moveTo(-25f, -18.5f); win.lineTo(-24.5f, -27f); win.lineTo(5.5f, -27f); win.lineTo(13f, -18.5f); win.close() }
        else -> { win.moveTo(-3f, -18.5f); win.lineTo(-1.5f, -27f); win.lineTo(8.5f, -27f); win.lineTo(15f, -18.5f); win.close() }
    }
    drawPath(win, glass)
    if (model == 2) {
        // the load bed: a low wall at the back and a small crate
        drawRoundRect(dk, Offset(-30f, -22f), Size(21f, 5f), CornerRadius(1.5f))
        drawRoundRect(Color(0xFFC9A27A), Offset(-26f, -26f), Size(11f, 5f), CornerRadius(1.2f))
    }
    // door line and trim
    drawLine(dk, Offset(-4f, -17f), Offset(-4f, -7f), 1f, StrokeCap.Round)
    drawRoundRect(dk, Offset(-30f, -9f), Size(60f, 3.2f), CornerRadius(1.6f))
    if (level >= 1) drawRoundRect(Color.White.copy(alpha = 0.35f), Offset(-26f, -16f), Size(18f, 2f), CornerRadius(1f))
    if (level >= 3) drawRect(Color.White.copy(alpha = 0.9f), Offset(-30f, -13.5f), Size(60f, 2f))
    if (level >= 4 && model != 2) {
        drawRoundRect(Dark, Offset(-18f, -31f), Size(22f, 1.8f), CornerRadius(0.9f))
    }

    // driver, in shades
    val hx = if (model == 2) 3f else -4f
    drawCircle(Color(0xFFF2C29B), 4.6f, Offset(hx, -23.2f + bob))
    if (broken) {
        drawCircle(Color(0xFF2A2724), 0.9f, Offset(hx + 1.2f, -23.6f + bob))
        drawCircle(Color(0xFF2A2724), 0.9f, Offset(hx + 3.2f, -23.6f + bob))
        val sweat = Path().apply {
            moveTo(hx - 5f, -27f + bob); quadraticBezierTo(hx - 7f, -23.5f + bob, hx - 5f, -22.8f + bob)
            quadraticBezierTo(hx - 3f, -23.5f + bob, hx - 5f, -27f + bob); close()
        }
        drawPath(sweat, Color(0xFF8FD3F4))
    } else {
        drawRoundRect(Color(0xFF2A2724), Offset(hx - 0.4f, -24.6f + bob), Size(6.4f, 2.4f), CornerRadius(1.1f))
    }
    drawRoundRect(Color(0xFF2A2724), Offset(hx - 4.4f, -28.4f + bob), Size(8.8f, 2.4f), CornerRadius(1.2f))

    // lights
    if (broken) {
        val on = (time * 2.6f).toInt() % 2 == 0
        val col = if (on) Color(0xFFFFB02E) else Color(0xFF8A6A2A)
        drawCircle(col, 2.8f, Offset(27.5f, -13f))
        drawCircle(col, 2.2f, Offset(-27.5f, -13f))
        // bonnet standing open at the front
        withTransform({ translate(17f, -18f); rotate(-58f, Offset.Zero) }) {
            drawRoundRect(dk, Offset(0f, -2.5f), Size(13f, 3.2f), CornerRadius(1.4f))
        }
    } else {
        drawCircle(Color(0xFFFFE066), 2.8f, Offset(27.5f, -13f))
        drawRoundRect(Color(0xFFFF8A3D), Offset(-30f, -14f), Size(2.4f, 4f), CornerRadius(1f))
    }
    // sparkles on the top-level car
    if (level >= 4 && !broken) {
        val spots = listOf(Offset(-12f, -14f), Offset(10f, -22f), Offset(22f, -12f))
        for ((i, sp) in spots.withIndex()) {
            val v = sin(time * 4f + i * 2.1f) * 0.5f + 0.5f
            val al = v * v * v
            if (al > 0.05f) {
                drawLine(Color.White.copy(alpha = al), Offset(sp.x - 3.5f, sp.y), Offset(sp.x + 3.5f, sp.y), 1f, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = al), Offset(sp.x, sp.y - 3.5f), Offset(sp.x, sp.y + 3.5f), 1f, StrokeCap.Round)
            }
        }
    }
    // wheel arches: the wheel sits in a round gap
    clipRect(-40f, -30f, 40f, -3.5f) {
        drawCircle(Color(0xFF26302B), 9.6f, Offset(-17f, 0f))
        drawCircle(Color(0xFF26302B), 9.6f, Offset(17f, 0f))
    }
}

/**
 * Draws the whole car. cx is the middle, rearGround / frontGround are the y of the ground under each wheel,
 * so the wheels sit on whatever surface they are given. The body hangs between the wheels and can move on its own
 * (bodyDy, angle), which is what makes the ride look bumpy.
 */
fun DrawScope.drawCarFull(
    cx: Float, rearGround: Float, frontGround: Float, sc: Float, angle: Float, bodyDy: Float,
    spin: Float, blur: Float, level: Int, broken: Boolean, time: Float, bob: Float
) {
    val dx = 17f * sc
    val r = 7.5f * sc
    val rearC = Offset(cx - dx, rearGround - (if (broken) r * 0.62f else r))
    val frontC = Offset(cx + dx, frontGround - r)
    val mx = (rearC.x + frontC.x) / 2f
    // broken: leans back a bit more, shudders, and the driver only fidgets
    val my = (rearC.y + frontC.y) / 2f + (if (broken) bodyDy * 0.5f + sin(time * 38f) * 0.25f else bodyDy) * sc
    val ang = if (broken) angle - 3f else angle
    val bobUse = if (broken) sin(time * 6f) * 0.4f else bob
    withTransform({
        translate(mx, my)
        rotate(ang, Offset.Zero)
        scale(sc, sc, Offset.Zero)
    }) {
        drawBodyLocal(level, broken, time, bobUse)
    }
    drawWheel(rearC, r, spin, blur, level, broken)
    drawWheel(frontC, r, spin, blur, level, false)
}

/**
 * Soft round puffs. Exhaust smoke starts as a thin wisp, swells, drifts back and fades,
 * and gets thicker and greyer when lots of data is flowing.
 */
fun DrawScope.drawSmoke(list: List<FloatArray>, sc: Float) {
    for (p in list) {
        val kind = p[3].toInt()
        val life = if (kind == 2) 1.4f else 1.7f
        val t = (p[2] / life).coerceIn(0f, 1f)
        val fade = (1f - t) * (1f - t)
        val grow = kotlin.math.sqrt(t)
        val dark = p[6].coerceIn(0f, 1f)
        val r = (1.4f + (if (kind == 2) 6.5f else 8f) * grow) * sc
        val base = when (kind) {
            0 -> androidx.compose.ui.graphics.lerp(Color(0xFFD9DFDB), Color(0xFF5A635E), dark * 0.9f)
            1 -> Color(0xFF3F3A36)
            else -> Color.White
        }
        val a0 = when (kind) {
            0 -> 0.3f + 0.42f * dark
            1 -> 0.7f
            else -> 0.5f
        } * fade
        if (a0 < 0.01f) continue
        val c = Offset(p[0], p[1])
        drawCircle(
            Brush.radialGradient(listOf(base.copy(alpha = a0), base.copy(alpha = a0 * 0.55f), base.copy(alpha = 0f)), c, r),
            r, c
        )
    }
}

/** Little square dust puffs kicked up by the cat's back paws, only when it really runs. */
fun DrawScope.drawDust(list: List<FloatArray>, sc: Float) {
    for (p in list) {
        if (p[3].toInt() != 0 || p[6] < 0.35f) continue
        val t = (p[2] / 1.7f).coerceIn(0f, 1f)
        val a = (1f - t) * 0.7f
        val s2 = (1.2f + 2.6f * t) * sc
        drawRect(Color(0xFFFFF0DA).copy(alpha = a), Offset(p[0] - s2 / 2f, p[1] - s2 / 2f), Size(s2, s2))
    }
}

/** Wheel spin, suspension, driver bounce and smoke. Used by the header, the overlay and the small car views. */
class CarMotion {
    var spin = 0f
    var time = 0f
    var bodyY = 0f      // body height offset, positive = lower
    private var bodyV = 0f
    var ang = 0f        // body angle in degrees, positive = nose down
    private var angV = 0f
    var blur = 0f
    val smoke = ArrayList<FloatArray>() // x, y, age, kind (0 white, 1 dark)
    private var smokeAcc = 0f
    private var steamAcc = 0f
    private var hoodAcc = 0f
    private var prevG = 0f
    private var prevGv = 0f
    private var have = false
    private var bumpIn = 0.5f

    /**
     * groundH is the ground height under the car (up is positive), baseAng the slope under the wheels in degrees.
     * suspension = false gives a rigid car with attached wheels. drift is how fast the world moves left, in px per second.
     */
    fun step(
        dt: Float, groundH: Float, baseAng: Float, inten: Float, broken: Boolean, suspension: Boolean,
        drift: Float, ex: Float, ey: Float, hx: Float, hy: Float, sc: Float
    ) {
        val d = dt.coerceAtLeast(0.004f)
        time += d
        val rate = if (broken) 0f else 120f + 1000f * inten
        spin = (spin + rate * d) % 360f
        blur = if (broken) 0f else ((inten - 0.3f) / 0.7f).coerceIn(0f, 1f)

        if (suspension) {
            if (!have) {
                prevG = groundH
                have = true
            }
            val gv = (groundH - prevG) / d
            val ga = ((gv - prevGv) / d).coerceIn(-1200f, 1200f)
            prevG = groundH
            prevGv = gv
            bodyV += (-170f * bodyY - 9f * bodyV + 1.1f * ga) * d
            bumpIn -= d
            if (bumpIn <= 0f) {
                bumpIn = 0.35f + Random.nextFloat() * 0.9f
                bodyV += (Random.nextFloat() - 0.5f) * (30f + 70f * inten + (if (broken) 60f else 0f))
            }
            bodyY = (bodyY + bodyV * d).coerceIn(-4f, 4f)
            val target = baseAng + (if (broken) -4f else 0f)
            angV += (95f * (target - ang) - 9f * angV) * d
            ang += angV * d
        } else {
            bodyY = 0f
            ang = 0f
        }

        if (!broken) {
            // exhaust: a thin wisp always, thick grey puffs when lots of data flows
            smokeAcc += d * (4f + 22f * inten)
            while (smokeAcc >= 1f) {
                smokeAcc -= 1f
                smoke.add(
                    floatArrayOf(
                        ex + (Random.nextFloat() - 0.5f) * sc, ey + (Random.nextFloat() - 0.5f) * sc, 0f, 0f,
                        -(14f + 26f * inten + Random.nextFloat() * 8f) * sc, Random.nextFloat() * 6.28f, inten
                    )
                )
            }
        } else {
            // the tailpipe only coughs, and dark smoke rolls out of the open hood
            smokeAcc += d * 2.5f
            while (smokeAcc >= 1f) {
                smokeAcc -= 1f
                smoke.add(floatArrayOf(ex, ey, 0f, 1f, -9f * sc, Random.nextFloat() * 6.28f, 1f))
            }
            steamAcc += d
            while (steamAcc > 0.09f) {
                steamAcc -= 0.09f
                smoke.add(floatArrayOf(hx - 3f * sc + (Random.nextFloat() - 0.5f) * 8f * sc, hy + 2f * sc, 0f, 2f, 0f, Random.nextFloat() * 6.28f, 0f))
            }
            hoodAcc += d * 6f
            while (hoodAcc >= 1f) {
                hoodAcc -= 1f
                smoke.add(floatArrayOf(hx, hy, 0f, 1f, 0f, Random.nextFloat() * 6.28f, 1f))
            }
        }
        val iter = smoke.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            val kind = p[3].toInt()
            p[2] += d
            p[0] += (p[4] - drift) * d
            p[4] *= (1f - 1.6f * d).coerceAtLeast(0f)
            p[0] += sin(p[2] * 5f + p[5]) * 0.16f * sc
            p[1] -= (if (kind == 2) 26f else 6f + 16f * p[2]) * sc * d
            if (p[2] > (if (kind == 2) 1.4f else 1.7f)) iter.remove()
        }
    }
}

private const val HILL_SC = 0.8f

/** Everything that moves in the header. The hills scroll right to left, the car stays near the middle. */
class CarSim {
    var w = 0f           // width in dp, set by the canvas
    var h = 0f
    var scroll = 0f
    var carX = -1f
    var amp = 8f
    var speed = 60f
    val m = CarMotion()

    /** Smooth rolling hills: two gentle waves, nothing sharp. */
    fun terrain(x: Float): Float {
        val u = x + scroll
        return amp * (0.62f * sin(u * 0.016f) + 0.38f * sin(u * 0.041f + 1.3f))
    }

    fun slope(x: Float): Float = -(terrain(x + 2f) - terrain(x - 2f)) / 4f

    fun base(): Float = h * 0.66f

    fun gy(x: Float): Float = base() - terrain(x)

    fun step(dt: Float, inten: Float, broken: Boolean) {
        if (w <= 0f) return
        val k = if (broken) 0.35f else 1f
        speed = (45f + 190f * inten) * k
        scroll += speed * dt
        amp = 5f + 17f * inten

        val center = w * 0.5f
        if (carX < 0f) carX = center
        // Steep climb pushes the car back, easy stretches let it creep forward. Stays within the middle two thirds.
        val s = slope(carX)
        val target = center + s * w * (if (s < 0f) 0.9f else 0.5f)
        carX += (target - carX) * minOf(1f, dt * 2.2f)
        carX = carX.coerceIn(w / 6f, w * 5f / 6f)

        val dx = 17f * HILL_SC
        val gr = gy(carX - dx)
        val gf = gy(carX + dx)
        val baseAng = atan2(gf - gr, dx * 2f) * 180f / PI.toFloat()
        val midY = (gr + gf) / 2f
        val cat = Prefs.rider == 1
        m.step(
            dt, terrain(carX), baseAng, inten, broken, true, speed,
            if (cat) carX - 13f else carX + EXH_X * HILL_SC, if (cat) gy(carX) - 2f else midY + (EXH_Y - 7.5f) * HILL_SC,
            carX + 18f * HILL_SC, midY - 36f * HILL_SC, HILL_SC
        )
    }
}

@Composable
fun HillsCanvas(modifier: Modifier, intensity: Float, ink: Color) {
    val sim = remember { CarSim() }
    var tick by remember { mutableStateOf(0L) }
    val inten by rememberUpdatedState(intensity)
    val broken by rememberUpdatedState(Live.broken)
    val d = LocalDensity.current.density

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) sim.step(((now - last) / 1e9f).coerceAtMost(0.05f), inten, broken)
                last = now
                tick = now
            }
        }
    }

    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val subscribe = tick
        sim.w = size.width / d
        sim.h = size.height / d
        val level = Live.level
        val isBroken = Live.broken
        withTransform({ scale(d, d, Offset.Zero) }) {
            val path = Path()
            val fill = Path()
            var x = 0f
            var first = true
            while (x <= sim.w + 4f) {
                val y = sim.gy(x)
                if (first) {
                    path.moveTo(x, y); fill.moveTo(x, sim.h); fill.lineTo(x, y); first = false
                } else {
                    path.lineTo(x, y); fill.lineTo(x, y)
                }
                x += 4f
            }
            fill.lineTo(sim.w + 4f, sim.h)
            fill.close()
            // two softer waves behind, the car rides the front crest
            for (k in 0..1) {
                val lp = Path()
                lp.moveTo(0f, sim.h)
                var xx = 0f
                while (xx <= sim.w + 4f) {
                    lp.lineTo(xx, sim.gy(xx + (if (k == 0) 120f else 55f)) - (if (k == 0) 14f else 7f))
                    xx += 4f
                }
                lp.lineTo(sim.w + 4f, sim.h)
                lp.close()
                drawPath(lp, if (k == 0) Wave1 else Wave2)
            }
            drawPath(fill, Wave3)
            if (Prefs.rider == 1) {
                // the hill line becomes a strand of yarn that unrolls from a ball up ahead
                val xsY = ArrayList<Float>()
                val ysY = ArrayList<Float>()
                var yx = 0f
                while (yx <= sim.w) { xsY.add(yx); ysY.add(sim.gy(yx)); yx += 6f }
                drawYarn(path, 3.4f, sim.scroll, xsY, ysY)
                val bx = sim.w - 22f
                drawYarnBall(Offset(bx, sim.gy(bx) - 8f), 9f, sim.scroll * 4f)
            } else {
                drawPath(path, CrestLine, style = Stroke(2f, cap = StrokeCap.Round))
            }

            val cx = sim.carX
            val dx = 17f * HILL_SC
            if (Prefs.rider == 1) {
                drawDust(sim.m.smoke, HILL_SC)
                drawCat(cx, sim.gy(cx) - 1f, 1.6f, sim.m.ang, catFrame(sim.m.spin), level, isBroken, sim.m.time)
            } else {
                drawSmoke(sim.m.smoke, HILL_SC)
                val bob = sin(sim.m.time * 9f) * (0.4f + 1.2f * intensity)
                drawCarFull(
                    cx, sim.gy(cx - dx), sim.gy(cx + dx), HILL_SC, sim.m.ang, sim.m.bodyY,
                    sim.m.spin, sim.m.blur, level, isBroken, sim.m.time, bob
                )
            }
        }
    }
}

/** A red warning triangle standing on the road. sx is its middle, g the ground. */
private fun DrawScope.drawWarning(sx: Float, g: Float, sc: Float) {
    withTransform({ translate(sx, g); scale(sc, sc, Offset.Zero) }) {
        val outer = Path().apply { moveTo(0f, -22f); lineTo(12f, 0f); lineTo(-12f, 0f); close() }
        drawPath(outer, Color(0xFFF0605A))
        val inner = Path().apply { moveTo(0f, -16f); lineTo(7.2f, -3f); lineTo(-7.2f, -3f); close() }
        drawPath(inner, Color(0xFFFFF4EE))
        drawLine(Color(0xFFF0605A), Offset(0f, -12f), Offset(0f, -7.5f), 1.8f, StrokeCap.Round)
        drawCircle(Color(0xFFF0605A), 1f, Offset(0f, -4.8f))
    }
}

private class Dims {
    var w = 0f
    var h = 0f
    var sc = 1f
    var roadX = 0f
    var last = 0L
}

/**
 * A small car on a bit of road, for the setup page and the Usage tab.
 * It rolls and bounces when it is fine and sits still with smoke when it is broken.
 */
@Composable
fun CarView(modifier: Modifier, level: Int, broken: Boolean, ink: Color) {
    val motion = remember { CarMotion() }
    val dm = remember { Dims() }
    var tick by remember { mutableStateOf(0L) }
    val isBroken by rememberUpdatedState(broken)

    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                val dt = if (dm.last != 0L) ((now - dm.last) / 1e9f).coerceAtMost(0.05f) else 0.016f
                dm.last = now
                if (dm.w > 0f) {
                    val g = dm.h - 6f
                    val b = isBroken
                    val catMode = Prefs.rider == 1
                    motion.step(
                        dt, 0f, 0f, 0.28f, b, true, 0f,
                        if (catMode) dm.w / 2f - 13f * dm.sc else dm.w / 2f + EXH_X * dm.sc,
                        if (catMode) g - 2f else g + (EXH_Y - 7.5f) * dm.sc,
                        dm.w / 2f + 18f * dm.sc, g - 36f * dm.sc, dm.sc
                    )
                    if (!b) dm.roadX = (dm.roadX + 70f * dt) % 40f
                }
                tick = now
            }
        }
    }

    val d = LocalDensity.current.density
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val subscribe = tick
        dm.w = size.width / d
        dm.h = size.height / d
        dm.sc = (dm.h / 52f).coerceAtMost(dm.w / 80f)
        withTransform({ scale(d, d, Offset.Zero) }) {
            val g = dm.h - 6f
            val cat = Prefs.rider == 1
            if (cat) {
                // a strand of yarn on the floor, rolling away under the cat
                val xs = ArrayList<Float>()
                val ys = ArrayList<Float>()
                var yx = 0f
                while (yx <= dm.w) { xs.add(yx); ys.add(g); yx += 7f }
                val strand = Path().apply { moveTo(0f, g); lineTo(dm.w, g) }
                drawYarn(strand, 4f, dm.roadX * 1.4f, xs, ys)
                if (!isBroken) drawYarnBall(Offset(dm.w - 16f, g - 10f), 10f, dm.roadX * 9f)
                else {
                    // over the limit: the yarn is all tangled and the cat has given up
                    drawYarnBall(Offset(dm.w - 22f, g - 10f), 10f, 30f)
                    drawYarnBall(Offset(dm.w - 36f, g - 7f), 7f, 100f)
                    drawYarn(Path().apply { moveTo(dm.w - 36f, g - 4f); cubicTo(dm.w - 60f, g - 24f, dm.w - 80f, g + 4f, dm.w - 98f, g - 4f) }, 3f, 0f, emptyList(), emptyList())
                }
                drawDust(motion.smoke, dm.sc)
                drawCat(dm.w / 2f, g - 1.5f, dm.sc * 1.9f, motion.ang * 0.5f, catFrame(motion.spin), level, isBroken, motion.time)
            } else {
                drawLine(ink.copy(alpha = 0.35f), Offset(0f, g), Offset(dm.w, g), 2f, StrokeCap.Round)
                if (!isBroken) {
                    var x = -dm.roadX
                    while (x < dm.w) {
                        drawRoundRect(ink.copy(alpha = 0.25f), Offset(x, g + 2.5f), Size(14f, 2f), CornerRadius(1f))
                        x += 40f
                    }
                }
                if (isBroken) drawWarning((dm.w / 2f - 62f * dm.sc).coerceAtLeast(14f * dm.sc), g, dm.sc)
                drawSmoke(motion.smoke, dm.sc)
                drawCarFull(
                    dm.w / 2f, g, g, dm.sc, motion.ang, motion.bodyY, motion.spin,
                    motion.blur, level, isBroken, motion.time, sin(motion.time * 8f) * 0.8f
                )
            }
        }
    }
}

/** 0..1 loudness of the traffic, used to pick wheel speed and smoke. */
fun intensityOf(bytesPerSec: Double): Float =
    (ln(1.0 + bytesPerSec / 20_000.0) / ln(251.0)).toFloat().coerceIn(0f, 1f)
