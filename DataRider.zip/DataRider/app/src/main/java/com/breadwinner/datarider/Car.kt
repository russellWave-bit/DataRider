package com.breadwinner.datarider

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.sin

/** The little red open-top car with a driver in shades. Origin is where the wheels touch the ground. */
fun DrawScope.drawCar(wheelBounce: Float) {
    val black = Color(0xFF0A0D12)
    val silver = Color(0xFFC9D3DD)
    // driver
    drawRect(Color(0xFF1B2A3A), Offset(-14f, -20f), Size(9f, 6f))
    drawCircle(Color(0xFFF2C29B), 4.6f, Offset(-9.5f, -24f))
    drawRect(Color(0xFF1B2A3A), Offset(-14.2f, -29f), Size(9.4f, 3.2f))
    drawRect(Color(0xFF05070A), Offset(-14f, -26f), Size(9.6f, 2.6f))
    // red open-top body
    val body = Path().apply {
        moveTo(-23f, -7f); lineTo(-23f, -16f); lineTo(-5f, -16f); lineTo(3f, -13f)
        lineTo(23f, -13f); lineTo(23f, -7f); close()
    }
    drawPath(body, Color(0xFFE5232E))
    drawRect(Color(0xFFB5121C), Offset(-23f, -11f), Size(46f, 2f))
    drawRect(silver, Offset(-5.6f, -22f), Size(1.6f, 7f))
    drawRect(Color(0xFFFFE9A8), Offset(21f, -15f), Size(3.4f, 2.4f))
    // black tyres, silver rims
    for (x in listOf(-13f, 13f)) {
        val c = Offset(x, -6f - wheelBounce)
        drawCircle(black, 6.2f, c)
        drawCircle(silver, 3.2f, c)
        drawCircle(Color(0xFF6B7886), 1f, c)
    }
}

/** Everything that moves in the header. The hills scroll right to left, the car stays near the middle. */
class CarSim {
    var w = 0f           // width in dp, set by the canvas
    var h = 0f
    var scroll = 0f
    var carX = -1f
    var time = 0f
    var amp = 8f
    var speed = 60f
    val smoke = ArrayList<FloatArray>() // x, y, age
    private var smokeAcc = 0f

    fun terrain(x: Float): Float {
        val u = x + scroll
        return amp * (0.55f * sin(u * 0.018f) + 0.30f * sin(u * 0.047f + 1.3f) + 0.15f * sin(u * 0.11f + 0.4f))
    }

    fun slope(x: Float): Float = -(terrain(x + 2f) - terrain(x - 2f)) / 4f

    fun base(): Float = h * 0.62f

    fun step(dt: Float, inten: Float) {
        if (w <= 0f) return
        time += dt
        speed = 45f + 190f * inten
        scroll += speed * dt
        amp = 5f + 17f * inten

        val center = w * 0.5f
        if (carX < 0f) carX = center
        // Steep climb pushes the car back, easy stretches let it creep forward. Stays within the middle two thirds.
        val s = slope(carX)
        val target = center + s * w * (if (s < 0f) 0.9f else 0.5f)
        carX += (target - carX) * minOf(1f, dt * 2.2f)
        carX = carX.coerceIn(w / 6f, w * 5f / 6f)

        // exhaust smoke when the data flow is heavy
        if (inten > 0.55f) {
            smokeAcc += dt * 14f * inten
            while (smokeAcc >= 1f) {
                smokeAcc -= 1f
                smoke.add(floatArrayOf(carX - 26f, base() - terrain(carX) - 12f, 0f))
            }
        }
        val it = smoke.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p[2] += dt
            p[0] -= speed * dt
            p[1] -= 14f * dt
            if (p[2] > 1.1f) it.remove()
        }
    }
}

@Composable
fun HillsCanvas(modifier: Modifier, intensity: Float, ink: Color) {
    val sim = remember { CarSim() }
    var tick by remember { mutableStateOf(0L) }
    val inten by rememberUpdatedState(intensity)
    val d = LocalDensity.current.density

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) sim.step(((now - last) / 1e9f).coerceAtMost(0.05f), inten)
                last = now
                tick = now
            }
        }
    }

    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val subscribe = tick
        sim.w = size.width / d
        sim.h = size.height / d
        withTransform({ scale(d, d, Offset.Zero) }) {
            val base = sim.base()
            val path = Path()
            val fill = Path()
            var x = 0f
            var first = true
            while (x <= sim.w + 4f) {
                val y = base - sim.terrain(x)
                if (first) {
                    path.moveTo(x, y); fill.moveTo(x, sim.h); fill.lineTo(x, y); first = false
                } else {
                    path.lineTo(x, y); fill.lineTo(x, y)
                }
                x += 4f
            }
            fill.lineTo(sim.w + 4f, sim.h)
            fill.close()
            drawPath(fill, ink.copy(alpha = 0.16f))
            drawPath(path, ink, style = Stroke(2.2f, cap = StrokeCap.Round))

            for (p in sim.smoke) {
                val a = 1f - p[2] / 1.1f
                drawCircle(Color.White.copy(alpha = 0.85f * a), 2f + 6f * p[2], Offset(p[0], p[1]))
            }

            val cx = sim.carX.coerceAtLeast(0f)
            val gy = base - sim.terrain(cx)
            val ang = atan2(sim.slope(cx), 1f) * 180f / PI.toFloat()
            val bounce = sin(sim.time * 28f) * 0.9f * intensity
            withTransform({
                translate(cx, gy - 1f)
                rotate(ang, Offset.Zero)
                scale(0.95f, 0.95f, Offset.Zero)
            }) { drawCar(bounce) }
        }
    }
}
