package com.breadwinner.datarider

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.random.Random

val LEVEL_NAMES = listOf("Plain racer", "Shiny", "Chrome wheels", "Sleek paint", "Glossy racer")
val LEVEL_AT = listOf(0, 5, 10, 18, 27)

private fun rad(d: Float): Float = (d * PI / 180.0).toFloat()

private val Tyre = Color(0xFF14110F)
private val Silver = Color(0xFFD5DBE2)
private val Gold = Color(0xFFF4C455)
private val Spoke = Color(0xFF55606C)
private val Dot = Color(0xFFFFD23F)
private val RedA = Color(0xFFE23039)
private val RedB = Color(0xFFA8202A)
private val Dark = Color(0xFF2A2420)

private fun DrawScope.drawWheel(c: Offset, r: Float, spin: Float, blur: Float, level: Int, flat: Boolean) {
    if (flat) {
        val ry = r * 0.62f
        drawOval(Tyre, Offset(c.x - r, c.y - ry), Size(r * 2f, ry * 2f))
        drawOval(Silver, Offset(c.x - r * 0.55f, c.y - ry * 0.55f), Size(r * 1.1f, ry * 1.1f))
        return
    }
    val rim = if (level >= 2) Gold else Silver
    val rr = r * (if (level >= 2) 0.7f else 0.62f)
    drawCircle(Tyre, r, c)
    drawCircle(rim, rr, c)
    val a = 1f - 0.75f * blur
    val n = if (level >= 2) 6 else 5
    for (i in 0 until n) {
        val ang = rad(spin + i * 360f / n)
        drawLine(
            Spoke.copy(alpha = a), c,
            Offset(c.x + cos(ang) * rr * 0.92f, c.y + sin(ang) * rr * 0.92f),
            r * 0.16f, StrokeCap.Round
        )
    }
    if (blur > 0.25f) {
        for (k in 0..2) {
            drawArc(
                Color.White.copy(alpha = 0.3f * blur), spin + k * 120f, 55f, false,
                Offset(c.x - rr * 0.62f, c.y - rr * 0.62f), Size(rr * 1.24f, rr * 1.24f),
                style = Stroke(rr * 0.5f)
            )
        }
    }
    drawCircle(Spoke, r * 0.14f, c)
    val da = rad(spin + 36f)
    drawCircle(Dot, r * 0.13f, Offset(c.x + cos(da) * rr * 0.78f, c.y + sin(da) * rr * 0.78f))
}

/** The car body. Local units: the axle line is y = 0, the wheels sit at x = -17 and x = +17, up is negative y. */
private fun DrawScope.drawBodyLocal(level: Int, broken: Boolean, time: Float, bob: Float) {
    val paint: Brush? = if (level >= 3) {
        Brush.verticalGradient(listOf(Color(0xFFFF5A62), Color(0xFFB0121D)), -26f, -4f)
    } else {
        null
    }
    // exhaust pipe
    drawRoundRect(Color(0xFF6B6560), Offset(-33f, -9f), Size(6f, 3f), CornerRadius(1.2f))
    // spoiler (top level only)
    if (level >= 4) {
        drawRect(Dark, Offset(-27f, -27f), Size(2f, 4f))
        drawRect(Dark, Offset(-22f, -27f), Size(2f, 4f))
        drawRoundRect(Tyre, Offset(-31f, -30f), Size(14f, 3f), CornerRadius(1.4f))
    }
    // hull and raised hood
    if (paint != null) {
        drawRoundRect(paint, Offset(-29f, -23.5f), Size(58f, 20f), CornerRadius(8f))
        if (!broken) drawRoundRect(paint, Offset(5f, -27.5f), Size(24f, 12f), CornerRadius(5f))
    } else {
        drawRoundRect(RedA, Offset(-29f, -23.5f), Size(58f, 20f), CornerRadius(8f))
        if (!broken) drawRoundRect(RedA, Offset(5f, -27.5f), Size(24f, 12f), CornerRadius(5f))
    }
    if (broken) {
        // engine bay with the engine showing, shuddering a little
        drawRoundRect(Color(0xFF1E1816), Offset(5f, -27.5f), Size(24f, 5f), CornerRadius(2f))
        drawRoundRect(Color(0xFF6E7781), Offset(9f, -30.5f), Size(12f, 6f), CornerRadius(2f))
        drawRoundRect(Color(0xFF4A525B), Offset(11f, -32f), Size(5f, 2f), CornerRadius(1f))
        val sh = sin(time * 40f) * 0.35f
        drawCircle(Color(0xFFC9D3DD), 1.1f, Offset(13f + sh, -27.5f))
        drawCircle(Color(0xFFC9D3DD), 1.1f, Offset(18f - sh, -27.5f))
    }
    // dark lower trim
    drawRoundRect(Dark, Offset(-29f, -8f), Size(58f, 4.5f), CornerRadius(3f))
    // shine and stripe
    if (level >= 1) {
        drawRoundRect(Color.White.copy(alpha = 0.32f), Offset(-24f, -22f), Size(22f, 2.4f), CornerRadius(1.2f))
        if (!broken) drawRoundRect(Color.White.copy(alpha = 0.32f), Offset(9f, -26f), Size(14f, 2f), CornerRadius(1f))
    }
    if (level >= 3) {
        drawRect(Color.White.copy(alpha = 0.9f), Offset(-29f, -14.5f), Size(58f, 2.2f))
    } else {
        drawRect(RedB, Offset(-29f, -13f), Size(58f, 1.6f))
    }
    // wheel arches: the wheel sits in a round gap, so it floats
    clipRect(-40f, -30f, 40f, -3.5f) {
        drawCircle(Color(0xFF1E1816), 10.8f, Offset(-17f, 0f))
        drawCircle(Color(0xFF1E1816), 10.8f, Offset(17f, 0f))
    }
    // open cockpit
    drawRoundRect(Color(0xFF3A1014), Offset(-20f, -24.5f), Size(24f, 5f), CornerRadius(2.5f))
    drawRoundRect(RedB, Offset(-21f, -31f), Size(5f, 9f), CornerRadius(2f))
    // driver
    drawRoundRect(Color(0xFF2E7DD6), Offset(-15f, -31f + bob), Size(11f, 9f), CornerRadius(3f))
    if (broken) {
        // hand on head
        drawLine(Color(0xFF2E7DD6), Offset(-5f, -27f + bob), Offset(-2.5f, -38f + bob), 2.4f, StrokeCap.Round)
        drawCircle(Color(0xFFF2C29B), 2f, Offset(-3f, -40f + bob))
    } else {
        drawLine(Color(0xFF2E7DD6), Offset(-5f, -27f + bob), Offset(2f, -29f), 2.4f, StrokeCap.Round)
    }
    drawCircle(Color(0xFFF2C29B), 5.4f, Offset(-9.5f, -36f + bob))
    drawRoundRect(Color(0xFF2A2724), Offset(-15.2f, -42.2f + bob), Size(11.4f, 5f), CornerRadius(2.5f))
    drawRoundRect(Color(0xFF2A2724), Offset(-5.5f, -38.8f + bob), Size(6f, 1.8f), CornerRadius(0.9f))
    drawRoundRect(Color(0xFF0B0B0C), Offset(-14.4f, -37.6f + bob), Size(9.6f, 3.2f), CornerRadius(1.4f))
    drawRect(Color.White.copy(alpha = 0.6f), Offset(-13.2f, -37.2f + bob), Size(2.2f, 0.9f))
    if (broken) {
        drawArc(Color(0xFF7A3B2E), 207f, 126f, false, Offset(-12.4f, -33.4f + bob), Size(5.8f, 5.2f), style = Stroke(0.9f, cap = StrokeCap.Round))
        // sweat drop
        val sweat = Path().apply {
            moveTo(-15.6f, -39.5f + bob)
            quadraticBezierTo(-18f, -35.6f + bob, -15.6f, -34.8f + bob)
            quadraticBezierTo(-13.2f, -35.6f + bob, -15.6f, -39.5f + bob)
            close()
        }
        drawPath(sweat, Color(0xFF8FD3F4))
    } else {
        drawArc(Color(0xFF7A3B2E), 20f, 140f, false, Offset(-12.4f, -34.8f + bob), Size(5.8f, 3.6f), style = Stroke(0.9f))
    }
    // steering wheel and windscreen
    drawLine(Tyre, Offset(2.5f, -32f), Offset(1f, -26.5f), 1.6f, StrokeCap.Round)
    val ws = Path().apply {
        moveTo(5f, -27.5f); lineTo(8f, -27.5f); lineTo(4.5f, -35.5f); lineTo(2.5f, -35.5f); close()
    }
    drawPath(ws, Color(0xFFBFE6F5).copy(alpha = 0.75f))
    // lights
    if (broken) {
        // hazard lights blink
        val on = (time * 2.6f).toInt() % 2 == 0
        val c = if (on) Color(0xFFFFB02E) else Color(0xFF5A3A12)
        drawCircle(c, 3f, Offset(27f, -17f))
        drawCircle(c, 2.2f, Offset(-27.8f, -16.7f))
    } else {
        drawCircle(Color(0xFFFFE066), 3f, Offset(27f, -17f))
        drawCircle(Color.White, 1.2f, Offset(27.4f, -17.4f))
        drawRoundRect(Color(0xFFFF8A3D), Offset(-29.5f, -19f), Size(2.4f, 4.5f), CornerRadius(1f))
    }
    // sparkles on the top-level car
    if (level >= 4 && !broken) {
        val spots = listOf(Offset(-12f, -19f), Offset(14f, -22f), Offset(22f, -14f))
        for ((i, s) in spots.withIndex()) {
            val v = sin(time * 4f + i * 2.1f) * 0.5f + 0.5f
            val a = v * v * v
            if (a > 0.05f) {
                drawLine(Color.White.copy(alpha = a), Offset(s.x - 3.5f, s.y), Offset(s.x + 3.5f, s.y), 1f, StrokeCap.Round)
                drawLine(Color.White.copy(alpha = a), Offset(s.x, s.y - 3.5f), Offset(s.x, s.y + 3.5f), 1f, StrokeCap.Round)
            }
        }
    }
}

/**
 * Draws the whole car. cx is the middle, rearGround / frontGround are the y of the ground under each wheel,
 * so the wheels sit on whatever surface they are given. The body hangs between the wheels and can move on its own
 * (bodyDy, angle), which is what makes the ride look bumpy.
 */
fun DrawScope.drawCarFull(
    cx: Float, rearGround: Float, frontGround: Float, sc: Float, angle: Float, bodyDy: Float,
    spin: Float, blur: Float, level: Int, broken: Boolean, time: Float, bob: Float
) {
    val dx = 17f * sc
    val r = 7.5f * sc
    val rearC = Offset(cx - dx, rearGround - (if (broken) r * 0.62f else r))
    val frontC = Offset(cx + dx, frontGround - r)
    val mx = (rearC.x + frontC.x) / 2f
    // broken: leans back a bit more, shudders, and the driver only fidgets
    val my = (rearC.y + frontC.y) / 2f + (if (broken) bodyDy * 0.5f + sin(time * 38f) * 0.25f else bodyDy) * sc
    val ang = if (broken) angle - 3f else angle
    val bobUse = if (broken) sin(time * 6f) * 0.4f else bob
    withTransform({
        translate(mx, my)
        rotate(ang, Offset.Zero)
        scale(sc, sc, Offset.Zero)
    }) {
        drawBodyLocal(level, broken, time, bobUse)
        if (broken) {
            // the hood, hinged at its back edge and standing open
            withTransform({ translate(5f, -27.5f); rotate(-62f, Offset.Zero) }) {
                drawRoundRect(RedA, Offset(0f, -3.5f), Size(24f, 4.5f), CornerRadius(2f))
                drawRoundRect(RedB, Offset(0f, 0.2f), Size(24f, 0.8f), CornerRadius(0.4f))
            }
        }
    }
    drawWheel(rearC, r, spin, blur, level, broken)
    drawWheel(frontC, r, spin, blur, level, false)
}

fun DrawScope.drawSmoke(list: List<FloatArray>, sc: Float) {
    for (p in list) {
        val kind = p[3].toInt()
        val life = if (kind == 2) 1.4f else 1.1f
        val a = 1f - p[2] / life
        val col = if (kind == 1) Color(0xFF4F4A45) else Color.White
        val alpha = if (kind == 2) 0.55f else 0.8f
        drawCircle(col.copy(alpha = alpha * a), (2f + (if (kind == 2) 5f else 6f) * p[2]) * sc, Offset(p[0], p[1]))
    }
}

/** Wheel spin, suspension, driver bounce and smoke. Used by the header, the overlay and the small car views. */
class CarMotion {
    var spin = 0f
    var time = 0f
    var bodyY = 0f      // body height offset, positive = lower
    private var bodyV = 0f
    var ang = 0f        // body angle in degrees, positive = nose down
    private var angV = 0f
    var blur = 0f
    val smoke = ArrayList<FloatArray>() // x, y, age, kind (0 white, 1 dark)
    private var smokeAcc = 0f
    private var steamAcc = 0f
    private var prevG = 0f
    private var prevGv = 0f
    private var have = false
    private var bumpIn = 0.5f

    /**
     * groundH is the ground height under the car (up is positive), baseAng the slope under the wheels in degrees.
     * suspension = false gives a rigid car with attached wheels. drift is how fast the world moves left, in px per second.
     */
    fun step(
        dt: Float, groundH: Float, baseAng: Float, inten: Float, broken: Boolean, suspension: Boolean,
        drift: Float, ex: Float, ey: Float, hx: Float, hy: Float, sc: Float
    ) {
        val d = dt.coerceAtLeast(0.004f)
        time += d
        val rate = if (broken) 0f else 120f + 1000f * inten
        spin = (spin + rate * d) % 360f
        blur = if (broken) 0f else ((inten - 0.3f) / 0.7f).coerceIn(0f, 1f)

        if (suspension) {
            if (!have) {
                prevG = groundH
                have = true
            }
            val gv = (groundH - prevG) / d
            val ga = ((gv - prevGv) / d).coerceIn(-1200f, 1200f)
            prevG = groundH
            prevGv = gv
            bodyV += (-170f * bodyY - 9f * bodyV + 1.1f * ga) * d
            bumpIn -= d
            if (bumpIn <= 0f) {
                bumpIn = 0.35f + Random.nextFloat() * 0.9f
                bodyV += (Random.nextFloat() - 0.5f) * (30f + 70f * inten + (if (broken) 60f else 0f))
            }
            bodyY = (bodyY + bodyV * d).coerceIn(-4f, 4f)
            val target = baseAng + (if (broken) -4f else 0f)
            angV += (95f * (target - ang) - 9f * angV) * d
            ang += angV * d
        } else {
            bodyY = 0f
            ang = 0f
        }

        if (broken || inten > 0.55f) {
            smokeAcc += d * (if (broken) 7f else 14f * inten)
            while (smokeAcc >= 1f) {
                smokeAcc -= 1f
                if (broken) smoke.add(floatArrayOf(hx, hy, 0f, 1f)) else smoke.add(floatArrayOf(ex, ey, 0f, 0f))
            }
        }
        if (broken) {
            // white steam puffing out of the open hood
            steamAcc += d
            while (steamAcc > 0.09f) {
                steamAcc -= 0.09f
                smoke.add(floatArrayOf(hx - 3f * sc + (Random.nextFloat() - 0.5f) * 8f * sc, hy + 2f * sc, 0f, 2f))
            }
        }
        val iter = smoke.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            val steam = p[3] > 1.5f
            p[2] += d
            p[0] -= drift * d
            if (steam) p[0] += sin(p[2] * 5f + p[1]) * 0.25f * sc
            p[1] -= (if (steam) 26f else 14f) * sc * d
            if (p[2] > (if (steam) 1.4f else 1.1f)) iter.remove()
        }
    }
}

private const val HILL_SC = 0.8f

/** Everything that moves in the header. The hills scroll right to left, the car stays near the middle. */
class CarSim {
    var w = 0f           // width in dp, set by the canvas
    var h = 0f
    var scroll = 0f
    var carX = -1f
    var amp = 8f
    var speed = 60f
    val m = CarMotion()

    /** Smooth rolling hills: two gentle waves, nothing sharp. */
    fun terrain(x: Float): Float {
        val u = x + scroll
        return amp * (0.62f * sin(u * 0.016f) + 0.38f * sin(u * 0.041f + 1.3f))
    }

    fun slope(x: Float): Float = -(terrain(x + 2f) - terrain(x - 2f)) / 4f

    fun base(): Float = h * 0.66f

    fun gy(x: Float): Float = base() - terrain(x)

    fun step(dt: Float, inten: Float, broken: Boolean) {
        if (w <= 0f) return
        val k = if (broken) 0.35f else 1f
        speed = (45f + 190f * inten) * k
        scroll += speed * dt
        amp = 5f + 17f * inten

        val center = w * 0.5f
        if (carX < 0f) carX = center
        // Steep climb pushes the car back, easy stretches let it creep forward. Stays within the middle two thirds.
        val s = slope(carX)
        val target = center + s * w * (if (s < 0f) 0.9f else 0.5f)
        carX += (target - carX) * minOf(1f, dt * 2.2f)
        carX = carX.coerceIn(w / 6f, w * 5f / 6f)

        val dx = 17f * HILL_SC
        val gr = gy(carX - dx)
        val gf = gy(carX + dx)
        val baseAng = atan2(gf - gr, dx * 2f) * 180f / PI.toFloat()
        val midY = (gr + gf) / 2f
        m.step(
            dt, terrain(carX), baseAng, inten, broken, true, speed,
            carX - 33f * HILL_SC, midY - 15f * HILL_SC, carX + 18f * HILL_SC, midY - 34f * HILL_SC, 1f
        )
    }
}

@Composable
fun HillsCanvas(modifier: Modifier, intensity: Float, ink: Color) {
    val sim = remember { CarSim() }
    var tick by remember { mutableStateOf(0L) }
    val inten by rememberUpdatedState(intensity)
    val broken by rememberUpdatedState(Live.broken)
    val d = LocalDensity.current.density

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) sim.step(((now - last) / 1e9f).coerceAtMost(0.05f), inten, broken)
                last = now
                tick = now
            }
        }
    }

    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val subscribe = tick
        sim.w = size.width / d
        sim.h = size.height / d
        val level = Live.level
        val isBroken = Live.broken
        withTransform({ scale(d, d, Offset.Zero) }) {
            val path = Path()
            val fill = Path()
            var x = 0f
            var first = true
            while (x <= sim.w + 4f) {
                val y = sim.gy(x)
                if (first) {
                    path.moveTo(x, y); fill.moveTo(x, sim.h); fill.lineTo(x, y); first = false
                } else {
                    path.lineTo(x, y); fill.lineTo(x, y)
                }
                x += 4f
            }
            fill.lineTo(sim.w + 4f, sim.h)
            fill.close()
            // two softer waves behind, the car rides the front crest
            for (k in 0..1) {
                val lp = Path()
                lp.moveTo(0f, sim.h)
                var xx = 0f
                while (xx <= sim.w + 4f) {
                    lp.lineTo(xx, sim.gy(xx + (if (k == 0) 120f else 55f)) - (if (k == 0) 14f else 7f))
                    xx += 4f
                }
                lp.lineTo(sim.w + 4f, sim.h)
                lp.close()
                drawPath(lp, if (k == 0) Wave1 else Wave2)
            }
            drawPath(fill, Wave3)
            drawPath(path, Color(0xFF9DF5E8), style = Stroke(2f, cap = StrokeCap.Round))

            drawSmoke(sim.m.smoke, 1f)

            val cx = sim.carX
            val dx = 17f * HILL_SC
            val bob = sin(sim.m.time * 9f) * (0.4f + 1.2f * intensity)
            drawCarFull(
                cx, sim.gy(cx - dx), sim.gy(cx + dx), HILL_SC, sim.m.ang, sim.m.bodyY,
                sim.m.spin, sim.m.blur, level, isBroken, sim.m.time, bob
            )
        }
    }
}

/** A red warning triangle standing on the road. sx is its middle, g the ground. */
private fun DrawScope.drawWarning(sx: Float, g: Float, sc: Float) {
    withTransform({ translate(sx, g); scale(sc, sc, Offset.Zero) }) {
        val outer = Path().apply { moveTo(0f, -22f); lineTo(12f, 0f); lineTo(-12f, 0f); close() }
        drawPath(outer, Color(0xFFF0605A))
        val inner = Path().apply { moveTo(0f, -16f); lineTo(7.2f, -3f); lineTo(-7.2f, -3f); close() }
        drawPath(inner, Color(0xFFFFF4EE))
        drawLine(Color(0xFFF0605A), Offset(0f, -12f), Offset(0f, -7.5f), 1.8f, StrokeCap.Round)
        drawCircle(Color(0xFFF0605A), 1f, Offset(0f, -4.8f))
    }
}

private class Dims {
    var w = 0f
    var h = 0f
    var sc = 1f
    var roadX = 0f
    var last = 0L
}

/**
 * A small car on a bit of road, for the setup page and the Usage tab.
 * It rolls and bounces when it is fine and sits still with smoke when it is broken.
 */
@Composable
fun CarView(modifier: Modifier, level: Int, broken: Boolean, ink: Color) {
    val motion = remember { CarMotion() }
    val dm = remember { Dims() }
    var tick by remember { mutableStateOf(0L) }
    val isBroken by rememberUpdatedState(broken)

    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                val dt = if (dm.last != 0L) ((now - dm.last) / 1e9f).coerceAtMost(0.05f) else 0.016f
                dm.last = now
                if (dm.w > 0f) {
                    val g = dm.h - 6f
                    val b = isBroken
                    motion.step(
                        dt, 0f, 0f, 0.28f, b, true, 0f,
                        dm.w / 2f - 33f * dm.sc, g - 15f * dm.sc, dm.w / 2f + 18f * dm.sc, g - 34f * dm.sc, dm.sc
                    )
                    if (!b) dm.roadX = (dm.roadX + 70f * dt) % 40f
                }
                tick = now
            }
        }
    }

    val d = LocalDensity.current.density
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val subscribe = tick
        dm.w = size.width / d
        dm.h = size.height / d
        dm.sc = (dm.h / 52f).coerceAtMost(dm.w / 80f)
        withTransform({ scale(d, d, Offset.Zero) }) {
            val g = dm.h - 6f
            drawLine(ink.copy(alpha = 0.35f), Offset(0f, g), Offset(dm.w, g), 2f, StrokeCap.Round)
            if (!isBroken) {
                var x = -dm.roadX
                while (x < dm.w) {
                    drawRoundRect(ink.copy(alpha = 0.25f), Offset(x, g + 2.5f), Size(14f, 2f), CornerRadius(1f))
                    x += 40f
                }
            }
            if (isBroken) drawWarning((dm.w / 2f - 62f * dm.sc).coerceAtLeast(14f * dm.sc), g, dm.sc)
            drawSmoke(motion.smoke, dm.sc)
            drawCarFull(
                dm.w / 2f, g, g, dm.sc, motion.ang, motion.bodyY, motion.spin,
                motion.blur, level, isBroken, motion.time, sin(motion.time * 8f) * 0.8f
            )
        }
    }
}

/** 0..1 loudness of the traffic, used to pick wheel speed and smoke. */
fun intensityOf(bytesPerSec: Double): Float =
    (ln(1.0 + bytesPerSec / 20_000.0) / ln(251.0)).toFloat().coerceIn(0f, 1f)
