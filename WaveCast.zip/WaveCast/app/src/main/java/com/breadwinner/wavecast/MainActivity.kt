package com.breadwinner.wavecast

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, CastService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d).putExtra("mode", Hub.mode)
            ContextCompat.startForegroundService(this, i)
        } else {
            Hub.hotspotMsg = "Screen capture was not allowed."
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun begin() {
        Hub.hotspotMsg = ""
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Hub.mode == 1) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) askProjection() else permLauncher.launch(missing.toTypedArray())
    }

    private fun end() {
        startService(Intent(this, CastService::class.java).setAction(CastService.STOP))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Hub.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Acc)) {
                WaveCastApp(onStart = { begin() }, onStop = { end() })
            }
        }
    }

    /** Android only lets an app read the clipboard while it is in front, so we look when you come back to it. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) readClip()
    }

    fun readClip() {
        try {
            val cm = getSystemService(ClipboardManager::class.java)
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return
            if (t.isNotEmpty() && t != Hub.phoneClip && t != Hub.pcClip) {
                Hub.phoneClip = t
                Hub.phoneClipSeq++
            }
        } catch (e: Exception) {
        }
    }
}
