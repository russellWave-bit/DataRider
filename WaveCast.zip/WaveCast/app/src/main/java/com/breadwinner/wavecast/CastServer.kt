package com.breadwinner.wavecast

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException

/** The little web server on the phone. The PC just opens its address in a browser. */
class CastServer(port: Int, private val ctx: Context) : NanoHTTPD(port) {
    private var pageCache: String? = null

    override fun serve(session: IHTTPSession): Response {
        Hub.touch(session.remoteIpAddress ?: "?")
        val uri = session.uri
        return try {
            when {
                uri == "/" -> page()
                uri == "/frame" -> frame(session)
                uri == "/info" -> json(info())
                uri == "/ping" -> ping()
                uri == "/cfg" -> cfg(session)
                uri == "/clip" -> clip(session)
                uri == "/log" -> log(session)
                uri == "/upload" && session.method == Method.POST -> upload(session)
                else -> text(Status.NOT_FOUND, "Not found")
            }
        } catch (e: Exception) {
            Hub.logErr("Server: " + (e.message ?: e.javaClass.simpleName))
            text(Status.INTERNAL_ERROR, "Something went wrong on the phone")
        }
    }

    private fun text(status: Status, msg: String): Response =
        newFixedLengthResponse(status, "text/plain", msg)

    private fun noCache(r: Response): Response {
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun json(o: JSONObject): Response =
        noCache(newFixedLengthResponse(Status.OK, "application/json", o.toString()))

    private fun page(): Response {
        val html = pageCache ?: ctx.assets.open("index.html").bufferedReader().use { it.readText() }.also { pageCache = it }
        return noCache(newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html))
    }

    private fun ping(): Response {
        val r = noCache(newFixedLengthResponse(Status.OK, "text/plain", "ok"))
        r.addHeader("X-T", System.currentTimeMillis().toString())
        return r
    }

    /** Waits for the next picture. 204 means nothing changed on the phone screen. */
    private fun frame(session: IHTTPSession): Response {
        val after = session.parameters["after"]?.firstOrNull()?.toIntOrNull() ?: -1
        val f = Frames.waitNewer(after, 700)
        if (f == null) {
            return noCache(newFixedLengthResponse(Status.NO_CONTENT, "text/plain", ""))
        }
        val (bytes, seq, stamp) = f
        val r = newFixedLengthResponse(Status.OK, "image/jpeg", ByteArrayInputStream(bytes), bytes.size.toLong())
        r.addHeader("X-Seq", seq.toString())
        r.addHeader("X-T", stamp.toString())
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun info(): JSONObject = JSONObject()
        .put("w", Hub.frameW).put("h", Hub.frameH)
        .put("fps", Hub.fps).put("quality", Hub.quality).put("scale", Hub.scalePct)
        .put("preset", Hub.preset).put("health", Hub.showHealth)
        .put("sentFps", Hub.sentFps).put("encodeMs", Hub.encodeMs).put("kb", Hub.lastKb)
        .put("dropped", Hub.dropped).put("viewers", Hub.viewers)
        .put("t", System.currentTimeMillis())

    private fun cfg(session: IHTTPSession): Response {
        val p = session.parameters
        p["preset"]?.firstOrNull()?.toIntOrNull()?.let { Hub.applyPreset(it.coerceIn(0, 2)) }
        p["fps"]?.firstOrNull()?.toIntOrNull()?.let { Hub.fps = it.coerceIn(1, 60) }
        p["quality"]?.firstOrNull()?.toIntOrNull()?.let { Hub.quality = it.coerceIn(10, 100) }
        p["scale"]?.firstOrNull()?.toIntOrNull()?.let { Hub.scalePct = it.coerceIn(20, 100) }
        Hub.save()
        return json(info())
    }

    /** GET gives the phone's clipboard. POST puts the PC's text on the phone's clipboard. */
    private fun clip(session: IHTTPSession): Response {
        if (session.method == Method.POST) {
            session.parseBody(HashMap())
            val t = session.parameters["text"]?.firstOrNull() ?: ""
            Hub.pcClip = t
            Handler(Looper.getMainLooper()).post {
                try {
                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                    cm.setPrimaryClip(ClipData.newPlainText("WaveCast", t))
                } catch (e: Exception) {
                    Hub.logErr("Clipboard: " + (e.message ?: ""))
                }
            }
            return text(Status.OK, "ok")
        }
        return json(JSONObject().put("seq", Hub.phoneClipSeq).put("text", Hub.phoneClip))
    }

    /** The PC page reports its own errors here, and reads the phone's log. */
    private fun log(session: IHTTPSession): Response {
        if (session.method == Method.POST) {
            session.parseBody(HashMap())
            val m = session.parameters["msg"]?.firstOrNull()
            if (!m.isNullOrBlank()) Hub.logErr("PC: " + m.take(200))
            return text(Status.OK, "ok")
        }
        val arr = JSONArray()
        for (e in Hub.errors.toList().take(30)) arr.put(e)
        return json(JSONObject().put("errors", arr))
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun upload(session: IHTTPSession): Response {
        val files = HashMap<String, String>()
        session.parseBody(files)
        val tmp = files["file"] ?: return text(Status.BAD_REQUEST, "No file")
        val raw = session.parameters["file"]?.firstOrNull() ?: "file"
        val name = raw.substringAfterLast('/').substringAfterLast('\\').ifBlank { "file" }
        val size = File(tmp).length()
        val saved = save(name, tmp)
        Hub.received.add(0, Got(name, size, System.currentTimeMillis(), saved))
        return text(Status.OK, "ok")
    }

    /** Puts the received file in Downloads/WaveCast. */
    private fun save(name: String, tmp: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/WaveCast")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create the file")
        resolver.openOutputStream(uri)!!.use { out ->
            FileInputStream(tmp).use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        File(tmp).delete()
        return uri
    }
}
