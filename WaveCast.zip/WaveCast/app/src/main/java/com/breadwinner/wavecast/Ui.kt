package com.breadwinner.wavecast

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlin.math.sin
import kotlinx.coroutines.delay

// Ember: a deep warm dark with a bold scarlet-orange accent, a different red from Data Rider's car.
val Bg = Color(0xFF140B0B)
val CardC = Color(0xFF231414)
val Track = Color(0xFF3A2323)
val TextC = Color(0xFFF7ECE6)
val Muted = Color(0xFFB59A92)
val Acc = Color(0xFFF2543D)
val OnAcc = Color(0xFF1A0A08)
val Sand = Color(0xFFF3D9B1)
val Warm = Color(0xFFFFB347)
val Good = Color(0xFF6FD3A0)

@Composable
fun T(text: String, size: Int = 13, color: Color = TextC, weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier)
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 8.dp, topEnd = 20.dp, bottomEnd = 8.dp, bottomStart = 20.dp)).background(CardC).padding(16.dp), content = content)
}

@Composable
fun Pill(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(if (filled) Acc else Track)
            .clickable { onClick() }.padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 14, if (filled) OnAcc else TextC) }
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Track).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(9.dp))
                    .background(if (i == sel) Acc else Color.Transparent).clickable { onSel(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 12, if (i == sel) OnAcc else Muted) }
        }
    }
}

@Composable
fun ToggleRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = Acc, checkedThumbColor = OnAcc, uncheckedTrackColor = Track))
    }
}

@Composable
fun LabeledSlider(label: String, value: Int, range: IntRange, unit: String, onChange: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            T(label, 13, modifier = Modifier.weight(1f))
            T("$value$unit", 13, Acc)
        }
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            colors = SliderDefaults.colors(thumbColor = Acc, activeTrackColor = Acc, inactiveTrackColor = Track)
        )
    }
}

@Composable
fun Qr(text: String, dp: Dp) {
    val m = remember(text) {
        try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 1))
        } catch (e: Exception) {
            null
        }
    }
    Canvas(Modifier.size(dp).clip(RoundedCornerShape(8.dp)).background(Color.White)) {
        if (m != null) {
            val cell = this.size.width / m.width
            for (y in 0 until m.height) {
                for (x in 0 until m.width) {
                    if (m.get(x, y)) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
                }
            }
        }
    }
}

@Composable
fun rememberWaveTime(): State<Float> {
    val t = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) t.value += ((n - last) / 1e9f).coerceAtMost(0.05f) * (if (Hub.running) 2.2f else 0.7f)
                last = n
            }
        }
    }
    return t
}

/** Warm night sky with three moving waves; the front one melts into the page. */
@Composable
fun WaveBand(modifier: Modifier) {
    val t = rememberWaveTime()
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dd = density
        drawRect(Brush.verticalGradient(listOf(Color(0xFF4A1612), Color(0xFF2A100E), Color(0xFF1B0C0B))))
        drawCircle(Color(0x33F3D9B1), 26f * dd, Offset(w * 0.84f, h * 0.32f))
        drawCircle(Sand, 14f * dd, Offset(w * 0.84f, h * 0.32f))
        val cols = listOf(Color(0xFF6B2218), Color(0xFFA73523), Bg)
        for (i in 0..2) {
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                val y = h * (0.58f + 0.12f * i) +
                    5f * dd * (0.8f + 0.3f * i) * sin(x / w * (1.3f + 0.4f * i) * 6.283f + t.value * (0.9f + 0.4f * i) + i * 2f)
                path.lineTo(x, y)
                x += 6f * dd
            }
            path.lineTo(w, h)
            path.close()
            drawPath(path, cols[i])
        }
    }
}

private val TABS = listOf("Cast", "Speed", "Health", "Share", "More")

@Composable
fun WaveCastApp(onStart: () -> Unit, onStop: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.fillMaxWidth()) {
            WaveBand(Modifier.matchParentSize())
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 38.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    T("WAVECAST", 11, Sand.copy(alpha = 0.85f))
                    T(TABS[tab], 26, TextC, FontWeight.ExtraBold)
                }
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (Hub.running) Acc else Color.White.copy(alpha = 0.14f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                    T(if (Hub.running) "LIVE" else "OFF", 11, if (Hub.running) OnAcc else TextC)
                }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (tab) {
                0 -> CastTab(onStart, onStop)
                1 -> SpeedTab()
                2 -> HealthTab()
                3 -> ShareTab()
                else -> MoreTab()
            }
        }
        Row(Modifier.fillMaxWidth().background(CardC).navigationBarsPadding().padding(vertical = 6.dp)) {
            TABS.forEachIndexed { i, s ->
                Column(
                    Modifier.weight(1f).clickable { tab = i }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(width = if (i == tab) 26.dp else 8.dp, height = 6.dp).clip(CircleShape).background(if (i == tab) Acc else Track))
                    Spacer(Modifier.height(5.dp))
                    T(s, 12, if (i == tab) TextC else Muted)
                }
            }
        }
    }
}

@Composable
fun CastTab(onStart: () -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    var addr by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Hub.running, Hub.mode) {
        while (true) {
            addr = findIp(Hub.mode)?.first
            delay(2000)
        }
    }
    Card {
        T(if (Hub.running) "Casting your screen" else "Ready to cast", 18, weight = FontWeight.ExtraBold)
        Spacer(Modifier.height(4.dp))
        T(
            if (Hub.running) "${Hub.viewers} PC watching" else "Tap Start, accept the Android popup, then open the address on your PC.",
            13, Muted, FontWeight.Medium
        )
        Spacer(Modifier.height(12.dp))
        if (Hub.running) Pill("Stop casting", false) { onStop() } else Pill("Start casting") { onStart() }
        if (Hub.hotspotMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            T(Hub.hotspotMsg, 12, Warm, FontWeight.Medium)
        }
    }
    if (Hub.running) {
        val url = if (addr != null) "http://$addr:${Hub.port}" else null
        Card {
            T("Open this on your PC", 14)
            Spacer(Modifier.height(6.dp))
            T(url?.removePrefix("http://") ?: "Finding the address...", 24, Acc, FontWeight.ExtraBold)
            T("Type it into Chrome or Edge. The PC must be on the same hotspot, Wi-Fi or USB cable.", 12, Muted, FontWeight.Medium)
            if (url != null) {
                Spacer(Modifier.height(12.dp))
                Qr(url, 150.dp)
            }
        }
        if (Hub.mode == 1 && Hub.ssid.isNotEmpty()) {
            Card {
                T("Join this Wi-Fi on your PC first", 14)
                Spacer(Modifier.height(6.dp))
                T("Name: ${Hub.ssid}", 15, Sand)
                T("Password: ${Hub.pass}", 15, Sand)
            }
        }
    } else {
        Card {
            T("How should the PC connect?", 14)
            Spacer(Modifier.height(10.dp))
            Seg(listOf("My hotspot", "Auto hotspot", "USB cable"), Hub.mode) { Hub.mode = it; Hub.save() }
            Spacer(Modifier.height(8.dp))
            T(
                when (Hub.mode) {
                    0 -> "Turn on your phone's own hotspot, join it from the PC, then start."
                    1 -> "The app makes a private hotspot for you. It shows the name and password."
                    else -> "Plug the cable in and turn on USB tethering in the phone's settings."
                },
                12, Muted, FontWeight.Medium
            )
            if (Hub.mode != 1) {
                Spacer(Modifier.height(10.dp))
                Pill("Open hotspot settings", false) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}

@Composable
fun SpeedTab() {
    Card {
        T("What are you doing?", 15)
        Spacer(Modifier.height(10.dp))
        Seg(listOf("Game", "Normal", "Music"), Hub.preset) { Hub.applyPreset(it) }
        Spacer(Modifier.height(8.dp))
        T(
            when (Hub.preset) {
                0 -> "Low delay. Fewer details, but it keeps up with fast action."
                2 -> "Steadier and sharper. A little slower, which is fine for music and video."
                else -> "A good balance for everyday use."
            },
            12, Muted, FontWeight.Medium
        )
    }
    Card {
        T("Fine tune", 15)
        LabeledSlider("Frames per second", Hub.fps, 5..30, "") { Hub.fps = it; Hub.save() }
        LabeledSlider("Picture quality", Hub.quality, 30..95, "%") { Hub.quality = it; Hub.save() }
        LabeledSlider("Picture size", Hub.scalePct, 30..100, "%") { Hub.scalePct = it; Hub.save() }
        T("The PC page also has a buffer slider. A bigger buffer is smoother but later. A small one is faster but can stutter.", 12, Muted, FontWeight.Medium)
    }
}

@Composable
fun HealthTab() {
    Card {
        ToggleRow("Show latency and errors", Hub.showHealth) { Hub.showHealth = it; Hub.save() }
        T("Switch this off to keep this screen and the PC panel quiet.", 12, Muted, FontWeight.Medium)
    }
    if (Hub.showHealth) {
        Card {
            T("Right now", 14)
            Spacer(Modifier.height(8.dp))
            StatRow("Frames sent per second", "${Hub.sentFps}")
            StatRow("Frames the PC missed", "${Hub.droppedShown}")
            StatRow("Time to make a picture", "${Hub.encodeMs} ms")
            StatRow("Picture size", "${Hub.lastKb} KB  (${Hub.frameW}x${Hub.frameH})")
            StatRow("PCs watching", "${Hub.viewers}")
            Spacer(Modifier.height(6.dp))
            T("The PC page shows the full delay, because it can see how long pictures take to arrive.", 12, Muted, FontWeight.Medium)
        }
        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Errors", 14, modifier = Modifier.weight(1f))
                Pill("Clear", false) { Hub.errors.clear() }
            }
            Spacer(Modifier.height(8.dp))
            if (Hub.errors.isEmpty()) {
                T("No errors. Good.", 13, Good, FontWeight.Medium)
            } else {
                for (e in Hub.errors.take(25)) {
                    T(e, 12, Warm, FontWeight.Medium, Modifier.padding(vertical = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        T(label, 13, Muted, FontWeight.Medium, Modifier.weight(1f))
        T(value, 13)
    }
}

@Composable
fun ShareTab() {
    val ctx = LocalContext.current
    Card {
        T("Clipboard", 15)
        Spacer(Modifier.height(4.dp))
        T("Copy something on the phone, then come back here. The PC page picks it up. Text copied on the PC lands on the phone's clipboard.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        T("Phone clipboard", 12, Muted)
        T(Hub.phoneClip.ifEmpty { "Nothing yet" }.take(160), 14, Sand, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        T("Last text from the PC", 12, Muted)
        T(Hub.pcClip.ifEmpty { "Nothing yet" }.take(160), 14, Sand, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Pill("Read phone clipboard now", false) { (ctx as? MainActivity)?.readClip() }
    }
    Card {
        T("Files from your PC", 15)
        T("Drop files on the PC page. They are saved in Downloads/WaveCast.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        if (Hub.received.isEmpty()) {
            T("Nothing received yet.", 13, Muted, FontWeight.Medium)
        } else {
            for (g in Hub.received.take(20)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    T(g.name, 13, modifier = Modifier.weight(1f))
                    T(fmtSize(g.size), 13, Muted)
                }
            }
        }
    }
}

@Composable
fun MoreTab() {
    Card {
        ToggleRow("Keep the phone screen awake while casting", Hub.stayAwake) { Hub.stayAwake = it; Hub.save() }
        T("Applies the next time you start casting.", 12, Muted, FontWeight.Medium)
    }
    Card {
        T("Tips", 15)
        Spacer(Modifier.height(6.dp))
        T("Android shows a popup every time you start casting. That is a safety rule and no app can skip it.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("If casting stops by itself, set the app's battery use to Unrestricted in Android settings.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("Pictures may not show for apps that block screen capture, like some banking apps.", 13, Muted, FontWeight.Medium)
    }
    Card {
        T("Coming next", 15)
        Spacer(Modifier.height(6.dp))
        T("Round 2: audio, typing from the PC.", 13, Muted, FontWeight.Medium)
        T("Round 3: full mouse and keyboard control, camera, gamepad.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        T("WaveCast 1.0", 12, Muted, FontWeight.Medium)
    }
}
