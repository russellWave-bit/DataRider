package com.breadwinner.wavecast

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream

/** Grabs the screen, turns it into pictures, and keeps the web server (and optional hotspot) alive. */
class CastService : Service() {
    private var server: CastServer? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var cpuLock: PowerManager.WakeLock? = null
    private var awakeLock: PowerManager.WakeLock? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var curW = 0
    private var curH = 0
    private var lastEnc = 0L
    private var count = 0

    companion object {
        const val STOP = "wavecast.stop"
        const val CH = "cast"
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Casting", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        val code = i?.getIntExtra("code", 0) ?: 0
        if (data == null || code == 0) {
            Hub.hotspotMsg = "Screen capture was not allowed."
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        startServer()
        if (server == null) {
            Hub.hotspotMsg = "Could not start the casting server."
            stopSelf()
            return START_NOT_STICKY
        }
        val pm = getSystemService(PowerManager::class.java)
        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavecast:cpu").apply { acquire() }
        if (Hub.stayAwake) {
            @Suppress("DEPRECATION")
            awakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE, "wavecast:awake").apply { acquire() }
        }
        thread = HandlerThread("wavecast-capture").also { it.start() }
        handler = Handler(thread!!.looper)

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Hub.logErr("Screen capture was stopped by Android")
                    stopSelf()
                }
            }, handler)
            projection = mp
            Frames.reset()
            buildDisplay()
            handler?.postDelayed(tick, 1000)
            Hub.running = true
            Hub.mode = i?.getIntExtra("mode", 1) ?: 1
            if (Hub.mode == 1 && reservation == null) startHotspot()
        } catch (e: Exception) {
            Hub.logErr("Could not start capture: " + (e.message ?: e.javaClass.simpleName))
            Hub.hotspotMsg = "Could not start screen capture."
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            Hub.sentFps = count
            count = 0
            Hub.droppedShown = Hub.dropped
            Hub.recount()
            try {
                val (w, h) = targetSize()
                if (display != null && (w != curW || h != curH)) buildDisplay()
            } catch (e: Exception) {
                Hub.logErr("Resize failed: " + (e.message ?: ""))
            }
            handler?.postDelayed(this, 1000)
        }
    }

    private fun targetSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        val wm = getSystemService(WindowManager::class.java)
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        val s = Hub.scalePct.coerceIn(20, 100) / 100f
        val w = ((m.widthPixels * s).toInt() / 2 * 2).coerceAtLeast(160)
        val h = ((m.heightPixels * s).toInt() / 2 * 2).coerceAtLeast(160)
        return w to h
    }

    private fun buildDisplay() {
        val mp = projection ?: return
        val (w, h) = targetSize()
        val old = reader
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd -> onImage(rd) }, handler)
        val dpi = resources.displayMetrics.densityDpi
        val d = display
        if (d == null) {
            display = mp.createVirtualDisplay(
                "WaveCast", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } else {
            d.resize(w, h, dpi)
            d.surface = r.surface
        }
        reader = r
        curW = w
        curH = h
        try { old?.close() } catch (e: Exception) { }
    }

    private fun onImage(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastEnc < 1000L / Hub.fps.coerceIn(1, 60)) return
            lastEnc = now
            val plane = img.planes[0]
            val ps = plane.pixelStride
            val rowW = plane.rowStride / ps
            val bmp = Bitmap.createBitmap(rowW, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            val crop = if (rowW != img.width) Bitmap.createBitmap(bmp, 0, 0, img.width, img.height) else bmp
            val out = ByteArrayOutputStream(48 * 1024)
            crop.compress(Bitmap.CompressFormat.JPEG, Hub.quality.coerceIn(10, 100), out)
            if (crop !== bmp) crop.recycle()
            bmp.recycle()
            val bytes = out.toByteArray()
            Frames.put(bytes)
            count++
            Hub.encodeMs = (SystemClock.elapsedRealtime() - now).toInt()
            Hub.lastKb = bytes.size / 1024
            Hub.frameW = img.width
            Hub.frameH = img.height
        } catch (e: Exception) {
            Hub.logErr("Picture failed: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            img.close()
        }
    }

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CastService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveCast is casting")
            .setContentText("Open the address on your PC")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stop).build())
            .build()
    }

    private fun startServer() {
        for (p in 8080..8090) {
            try {
                val s = CastServer(p, applicationContext)
                s.start()
                server = s
                Hub.port = p
                return
            } catch (e: Exception) {
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun startHotspot() {
        Hub.hotspotMsg = "Starting the hotspot..."
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        Hub.ssid = c.ssid ?: ""
                        Hub.pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        Hub.ssid = (c?.SSID ?: "").trim('"')
                        Hub.pass = c?.preSharedKey ?: ""
                    }
                    Hub.hotspotMsg = ""
                }

                override fun onStopped() {
                    Hub.ssid = ""
                    Hub.pass = ""
                    Hub.hotspotMsg = "The hotspot stopped."
                }

                override fun onFailed(reason: Int) {
                    Hub.hotspotMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "No Wi-Fi channel is free right now. Try again."
                        ERROR_INCOMPATIBLE_MODE -> "Turn off your normal hotspot first, then try again."
                        ERROR_TETHERING_DISALLOWED -> "This phone does not allow apps to start a hotspot."
                        else -> "The hotspot could not start. Make sure Location is switched on."
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            Hub.hotspotMsg = "Allow the permission and switch Location on, then try again."
        } catch (e: Exception) {
            Hub.hotspotMsg = "The hotspot could not start on this phone."
        }
    }

    override fun onDestroy() {
        handler?.removeCallbacksAndMessages(null)
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { reservation?.close() } catch (e: Exception) { }
        reservation = null
        try { server?.stop() } catch (e: Exception) { }
        server = null
        try { thread?.quitSafely() } catch (e: Exception) { }
        thread = null
        try { cpuLock?.release() } catch (e: Exception) { }
        try { awakeLock?.release() } catch (e: Exception) { }
        cpuLock = null
        awakeLock = null
        Frames.reset()
        Hub.running = false
        Hub.ssid = ""
        Hub.pass = ""
        Hub.sentFps = 0
        Hub.clearSeen()
        super.onDestroy()
    }
}
